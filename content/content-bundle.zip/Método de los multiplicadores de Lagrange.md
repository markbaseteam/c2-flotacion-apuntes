[[Cosas que no ha preguntado y que sí ha preguntado el profe]]

- Las condiciones para realizar el ajuste del balance metalúrgico se logran planteando la función objetivo phi
- Esta función objetivo consiste en una sumatoria de las diferencias al cuadrado 
- Las diferencias son entre las variables medidas y las calculadas 
- Esta diferencia se pondera por un factor de peso Wi

- Para esto tiene que tener una función objetivo sujeta a restricciones de balance de nodos
- Las restricciones según el coeficiente de la j-ésima restricción en el flujo i, según el número de nodos. 
- La determinación de valores ajustados de flujo Fi se realiza resolviendo un sistema de ecuaciones lineales
- Ese método de ec. lineales sigue el método de los multiplicadores de lagrange.
- El método requiere de la definición de una nueva función objetivo
- Esta nueva función objetivo es la función objetivo original más las restricciones multiplicadas por un parámetro lambda (mult de lagrange).
- Para lograr que la diferencia de los valores medidos y ajustados sea mínima 
- Y para lograr que al mismo tiempo se cumplan las restricciones de balance de masa
- Se minimiza la función objetivo extendida.

[[Multiplicadores de Lagrange.excalidraw]]
