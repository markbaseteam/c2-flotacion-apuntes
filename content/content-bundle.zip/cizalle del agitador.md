"Se rompe el aire producto de la acción de cizalle del agitador en la celda mecánica".

[[Generación de burbujas en máquinas de flotación]]
