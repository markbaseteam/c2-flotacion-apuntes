![[Pasted image 20221206113844.png]]
- Cantidad de etapas de limpieza y la cantidad de espesadores.
- [[Hay un espesador de cabeza.]]
- [[Dónde va P5 espesador]]
- La moly se disemina en la matriz rocosa muuuy fina. "liberar para llevara leyes de concentrado."
- [[Segundo circuito de moly]]
- [[Tercer circuito de moly]]
- [[Cuarto circuito de moly]]