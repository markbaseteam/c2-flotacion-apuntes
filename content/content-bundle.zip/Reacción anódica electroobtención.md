La reacción anódica de la electroobtención es la del agua.
_El problema es que consume energía, pero pueden generarse reacciones parásitas_
[[reacciones parásitas]]

[[Generación de burbujas en máquinas de flotación]]