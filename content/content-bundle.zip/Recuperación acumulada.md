- Se define como la masa de cobre / Ley de cobre x alimentación. 
- O bien, como la Cc/Ff x 100

[[Datos de recuperación acumulada erróneos]]