Se utilizan en la etapas de limpieza, hay modelos tipo B y C:
Modelo Canadiense, las burbujas se generan mediante la inyección de aire a través de un medio poroso.

[[Concepto de estabilidad en celdas columnares]]

[[Clase flotación 25 Nov - Flotación Columnar]]

[[Celda Jameson]]
[[Celda Imhoflot-G Cell]]

[[Celdas neumáticas]]

[[Agua de lavado]]

[[Generación de burbujas en máquinas de flotación]]

[[Origen de las celdas columnares]]

[[Teoría Flotación Sulfuros]]