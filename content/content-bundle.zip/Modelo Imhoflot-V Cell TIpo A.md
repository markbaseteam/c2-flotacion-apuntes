- Hay un cono que provoca la restricción de aire "froth crowder" 
- conozco caudal y área de SC.
- Q/Sc si área disminuye entonces la ==Velocidad aumenta== [[velocidad en un tubo]]
- Si suben más rápido, la probabilidad 

[[Celda Imhoflot-G Cell]]