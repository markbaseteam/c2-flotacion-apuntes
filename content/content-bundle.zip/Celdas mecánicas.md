El elemento distintivo es que el aire ingresa por este eje, y dado que hay un impulsor o rotor, el aire se rompe y se generan burbujas de 1-5 mm. 
[[Celdas autoaspirantes]]
[[Celdas aireación forzada]]

[[Partes de una celda mecánica]]

[[Descripción de flotación en celda mecánica]]

[[Modelos de celda]]

