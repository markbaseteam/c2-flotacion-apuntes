- Pasar todos tus apuntes "a mano" y guardarlos en la aplicación
- Celular: Metaslip (android, iOS), Obsidian:PC
- Grabar las clases: 1 h 30 min

¿En qué creen ustedes que influirá la máquina o el reactor que se utiliza? ¿Qué parámetros?
Para el diseño del reactor, ¿cómo se distribuyen las burbujas dentro de la máquina? ¿qué conviene, que las burbujas estén bien distribuidas, o que cortocircuiten? las partículas hidrofóbicas están ávidas por encontrar burbujas. 

"El diseño del reactor influye en la distribución homogénea de burbujas y partículas dentro de la celda"
"Patrón fluidodinámico de la celda"
Variables de la pulpa, como el % de sólidos, que es variable importante que influye en la probabilidad de la colisión, de la reología, viscosidad de la pulpa, yield stress,

## Pregunta
### ¿Qué pasa con la probabilidad de choque si la viscosidad de la pulpa es mayor?
Si la [[viscosidad del medio]] es mayor, ¿cómo va a ser esa probabilidad? Si es más viscoso va a ralentizar el proceso, va a disminuir la [[probabilidad de colisión]], sobre qué tanto una partícula con una burbuja colisionen, muy importante. 

### ¿Para qué molemos en las plantas concentradoras?
Para liberar especies que están diseminadas en una matriz rocosa, por eso molemos. Es molienda genera una distribución de tamaño, hay un tamaño óptimo asociado al proceso de flotación Pc! "Probabilidad de colisión y adhesión"

[[Clase flotación 17 Nov]]
[[Clase flotación 25 Nov - Flotación Columnar]]