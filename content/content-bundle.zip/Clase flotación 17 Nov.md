¿Cuál es la máxima ley que puedo obtener de un concentrado de cobre? ¿De qué depende esa Ley?

La ley depende de la alimentación, en el sentido de que existe una máxima ley teórica en la alimentación que es propia de cada mineral, como es la ley de un mineral calcopirítico o la calcosina, que depende de la mineralogía de la mena, si es que hay un yacimiento que tenga sulfuros secundarios como la covelina Cu2S o calcosina CuS en donde puedo tener un 79.8% de cobre y 66.4% de cobre, debido a que estequiométricamente habrá mayor cantidad de cobre en esa molécula. La calcopirita tiene un 34% de cobre teórico estequiométrico. Si alguien pregunta ¿Cuál es la ley de un concentrado de cobre? Preguntar de vuelta, ¿De qué mineralogía se refiere? Si es un sulfuro primario o secundario.

Si uno analiza el caso de la flotación de laboratorio, se ve que cada variable está sujeta a un error experimental y existe varianza para cada una de ellas. Se puede hacer el cálculo de la ley de cabeza “Recalculada” para que el balance cuadre. Si la medición fue bien hecha, la ley de cabeza recalculada se debería acercar a la ley de cabeza medida, si la diferencia entre ellas es mayor a un 5% entonces se determina que la medición se debe hacer de nuevo.

Otro parámetro importante es la razón de enriquecimiento, que es la razón entre la ley de concentrado y la alimentación, la ley del mineral subió 50 veces para el cobre 0.6% a 30%, o bien subir 75 veces la ley desde una ley de cobre del 0.4%, si quiero elevar la razón de enriquecimiento, debo de subir la ley y por ende aumentar las etapas de limpieza. La molibdenita tiene un máximo de 60% de Molibdeno estequiométrico. En la planta de flotación selectiva de molibdeno entra un 1% de molibdeno y sale con 52%, es decir, que la razón de enriquecimiento fue de 52, en cambio, la razón global fue de 2600 al considerar una ley de entrada de 0.02% de Molibdeno en la Molibdenita (MoS2). Las planas de molibdeno tienen de 5 a 6 etapas de limpieza. 

¿Explicar por qué la ley de cobre en las fracciones más finas son mayores? ¿Cómo afecta a la eficiencia del proceso? ¿Qué pasaría si la calcopirita fuese más dura que el cuarzo?

 Esta pregunta se refiere a la dureza de los dos elementos, si la calcopirita fuese súper dura, entonces ¿dónde reportaría? ¿En finos o en gruesos? Como la calcopirita es menos dura que el cuarzo (3,5-4 en Mohs) v/s 7 en Mohs; entonces reporta en los finos, por ende, el cuarzo está en las fracciones más gruesas donde las leyes son menores. Finalmente, es cierto que las partículas con mayor ley son las más liberadas, pero, no tiene que ver con las fracciones del mineral, es una consecuencia.

La expresión de la flotación batch corresponde a un modelo cinético de primer orden, es una concentración que disminuye conforme a que pasa el tiempo, esa constante depende de muchas variables, en teoría varía y depende de los factores mineralógicos, depende de la granulometría, del Jg, del hold up, del tamaño de las burbujas que utilizamos, valores típicos de la constante K 0.2-0.6, como el cuarzo es tan duro, entonces las partículas quedan ocluidas en la matriz de cuarzo y van a las fracciones más gruesas.

$$ \frac{\mathrm{dC}}{\mathrm{d} t}=-kC $$
Resolviendo la integral con las condiciones iniciales $$ t_{1}=t_{0}=0; t_{2}=t;  $$ y, $$C_{2}=C;C_{1}=C_{0}$$
Resulta la expresión;
$$C=C_{0}e^{-kt} $$
En donde, se puede definir la expresión para la recuperación, en función de las concentraciones:
$$R=\frac{C_{0}-C}{C_{0}} $$
$$ln\left ( \frac{C}{C_{0}} \right )=-kt$$
En donde se despeja y se reemplaza por el término de las recuperaciones, para que quede de la forma final;
$$R=R_{\infty}(1-e^{-kt})$$
$$\frac{\mathrm{dC}}{\mathrm{d} t}=-k(C-C_{\infty})$$
[[Clase flotación 03 Nov]]


