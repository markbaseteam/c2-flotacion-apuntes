Celda Wemco, FLSmidth autoaspirante, el aire ingresa por succión.
_La presión atmosférica es menor en la cordillera en alturas._
La cantidad de energía por unidad de volumen de celda es mayor [[Rotor de flotación]]

- Tiene un doble estator, el rotor es de 2/3 la altura de la base; genera una circulación de la pulpa. 
- El diseño no es antojadizo, a través de modelos de CFD, por aquí ingresa la pulpa y el concentrado se concentra en las canaletas. 
- La succión depende del tipo de mineral en la autoaspirante, con alto contenido de finos, la viscosidad de la pulpa aumenta [[Transporte de pulpa]]
- El fondo falso sirve para evitar embancamientos, sedimentación de la pulpa. [[Partes de una celda mecánica]]

[[Celdas mecánicas]]

[[Celda Outotec_Aireación Forzada]]

[[Celda Dorr-Oliver Aireación Forzada FLSmith]]



