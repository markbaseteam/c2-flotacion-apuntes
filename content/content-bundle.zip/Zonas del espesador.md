1. Zona de agua clara
2. Zona de compactación o cama

### ¿Qué pasa si se modifica la altura de la cama de un espesador?
Si uno sube esta cama se estruja más y se eleva el Cp, porcentaje de sólidos. En el transiente si cierro la válvula entonces estrujamos mucho más y el Cp se eleva, tiene que haber una mayor altura en la zona de cama para que fluya el fluido.

_Sigue entrando lo mismo y el tiempo de residencia es constante ya que el volumen del espesador es el mismo (está diseñado) y el caudal es el mismo_

[[Transporte de pulpa]]

