Material que se va depositando en el tiempo que obstrue, cristales que precipitan desde la solución como el sulfato de calcio. 

[[Sistema de inyección de aire columnas]]