![[Pasted image 20221208184939.png]]
[[Diagrama del problema-ejercicio 4 ayudantía flota]]

[[Calcular ton de concentrado Ro producidos al día]]

[[Bibliografía de Flota]]