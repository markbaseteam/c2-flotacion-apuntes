Van a los espesadores de colas, NO a los filtros xD.

[[Objetivos máquina flotación y diseño]]
