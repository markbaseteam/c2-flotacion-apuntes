 De 5 a 6 millones de dólares 
- 100M SAG
- 40 línea de flotación
- Toda la planta de flotación unos 200 molinos de bolas 100M
- Solo la planta cuesta unos 1000 M de USD.
- Más las mantenciones periódicas, etc.
- Las partes internas se van manteniendo.
- El cascarón es el que perdura.
- Proyecto mediano cuesta unos 
- 5 a 10 años demora en recuperar una inversión.
- Proyecto minero 6,000 millones de Dólares

Reactivos de flotación:
Colector : 20 a 40 g/t.
Espumante: 30 a 50 g/t.
Cal: 2-5 kg/t. [[Clase Flotación 29 Nov-Depresión de la pirita]] (Es mucho)
Chile = 2.4 millones de toneladas
Producción = Ton x Ley x Recuperación =2.5 M ton de mineral al día, escondida 400 Mil.
Ley=2.82??
R=0.85
al día=12,500 kilos de cal.
Precio de cal=200-300 us/ton.
Negocio de : 4M de usd por día.

- Consumo de NaSH en flotación selectiva es de 2-5 kg/t.

[[Pregunta 1 de C1 Flotación]]


[[Comparación celdas mecánicas vs neumáticas]]