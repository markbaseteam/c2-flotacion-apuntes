- Realizar un gráfico en Excel con 3 variables, de recuperación acumulada en el eje Y con ley de concentrado en el eje Y2 y con el tiempo medio en el Eje X.
- Eso se pone con dar formato a la serie de datos, luego se coloca Segundo eje o eje secundario.
Me quedó así: pero me falta colocarle el segundo valor a el eje Y en la ley de concentrado. 
![[Pasted image 20221209003514.png]]
- La recuperación acumulada llega hasta el 1.14 así que estamos bien. 
- Finalmente agregué un segundo título al eje secundario y me quedó así:
 ![[Pasted image 20221209003950.png]]
