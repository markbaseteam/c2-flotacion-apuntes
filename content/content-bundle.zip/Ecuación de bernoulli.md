Era un balance de energía potencial y cinética, donde aparece la altura y la velocidad al cuadrado.
"En un sistema real aparece otro componente"
"No toda la energía potencial se transforma en cinética"
[[caso atmósfera muy viscosa]]

[[Zona de limpieza]]
