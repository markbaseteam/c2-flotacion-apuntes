- Slimes: lamas, depósito de finos, tranque de relaves, pero de lamas.
- Caudal alimentación disminuye el Cp es mayor, ganamos capacidad. 12:20
- ![[Pasted image 20221206104308.png]]
- Make up es reponer agua
- el agua se pierde para siempre en el tranque de relaves.
- En el área de tranques el área es grande y se produce evaporación.
- ¿[[Make up de agua en una planta concentradora]]? 
[[Circuito Planta Collahuasi]]

[[Flotación selectiva del Cu y Mo]]

[[Clase Flotación 29 Nov-Depresión de la pirita]]

[[Método de los multiplicadores de Lagrange]]
