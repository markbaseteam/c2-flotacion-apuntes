La distancia de nado de la partícula es constante.

[[Variables importantes de celdas mecánicas]]
