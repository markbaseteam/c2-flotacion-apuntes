- Primera operación minera q usó agua de mar sin desalar.
- Usan el metabisulfito de sodio como depresante de pirita. 
$$Na_{2}S_{2}O_{5}$$
[[Clase Flotación 29 Nov-Depresión de la pirita]]
