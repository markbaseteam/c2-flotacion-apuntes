Va arrastrando hacia abajo la ganga hidrofílica, y aumenta la ley.

[[Celdas columnares]]