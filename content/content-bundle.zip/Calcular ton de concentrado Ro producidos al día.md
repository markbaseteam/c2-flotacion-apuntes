
![[Pasted image 20221208190246.png]]

[[Relación entre recuperación en peso y leyes]]