- Flotación selectiva Sulfidrato de sodio NaSH, depresor de sulfuros de cobre, depresa la flotación de cobre. [[Clase Flotación 29 Nov-Depresión de la pirita]]
- Entonces, pasan a ser hidrofílicos y se van por colas de flotación selectiva
- Molibdenita flota sola porque es hidrofóbica naturalmente.
- Concentrado de Mo 52% y de Cu 30 %
- Consumo de NaSH no afecta a la flotabilidad de molibdenita. [[PIM Proyecto de Ing Metalúrgica]]
- Característica del sulfidrato de Sodio NaSH.
- Lo importante es el:
$$Na^{2+}+SH^{-}$$
- El control de pH en la flotación selectiva es crítico, ya que se genera el gas H2S que es letal. 
- menor Kps estabilidad mayor.
- [[Mecanismo de destrucción compuesto xantato metálico]]
- [[NaSH es un reductor]]
- [[Qué se hace con el agua disponible de la flotación selectiva]]
- [[Problema del NaSH]]
- [[Caracterización de Molibdenita]]
- [[Para qué se agrega ácido]]

[[Desarrollo de C2 de Flotación 2017]]