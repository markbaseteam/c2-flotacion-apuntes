- Se baja como a pH 8 xk si no se genera H2S tóxico.
 ![[Pasted image 20221206113346.png]]
