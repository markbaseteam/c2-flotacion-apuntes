El aire genera producto de la succión generada por el movimiento del impulsor, la presión atmosférica es mayor en el exterior que en el interior, por ende, entra por succión.

[[Celdas mecánicas]]
