Son canaletas que están dentro de la zona de espuma, aumentan la recuperación, entran a canaleta y se van a la periférica, para que no nade tanta distancia hacia la costa y disminuye probabilidad de que se "ahogue".

[[Variables importantes de celdas mecánicas]]