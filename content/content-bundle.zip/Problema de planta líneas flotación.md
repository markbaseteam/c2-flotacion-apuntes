Imaginar que hay 7 líneas de flotación, la celda pasa por gravedad por diferencia de cota. [[Clase de Flotación 02 Dic]]
### ¿Qué ocurre con la celda de flotación al tener una cañería en forma de curva?
No es producto del roce la acumulación de pulpa, es producto de la fuerza centrípeta y finalmente la partículas gruesas van a una línea de flotación y la otra línea van las partículas más finas.

[[Máquinas de Flotación]]

