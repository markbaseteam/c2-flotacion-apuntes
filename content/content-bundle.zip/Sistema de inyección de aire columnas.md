LAS BURBUJAS SE GENERAN DENTRO DE LA COLUMNA EN EL INTERNO, en el externo son inyectadas en un sistema de anillo que permiten que las burbujas ingresen en la columna de flotación.

Sistema externo: sistema de bombeo agua espumantes y aire a través de los inyectores,

- La desventaja es que distribución de burbujas en la parte interior no es tan homogénea, en las columnares externas.
- Permite generar burbujas pequeñas, se hace afuera el sistema para que no se mezcle con partículas. inspeccionar el inyector desde fuera.
- La densidad del cobre se parece mucho a la del cuarzo. A la etapa Rougher. [[Etapa Rougher]]
- Densidad de mineral que entra a una columna, si es calcopirita entonces se asemeja a la densidad de la calcopirita.  [[Densidad de la pulpa]] al 30% sólidos con 2.7 g/cm3, resulta 1.23
- Densidad tonelaje / volumen, 1.23 t/m3.
- 100 m3 de la columna [[toneladas de pulpa]]
Sistemas de inyección de aire:

![[Pasted image 20221125135907.png]]

- Son sistemas de tubos perforados, 

![[Pasted image 20221125140037.png]]

Que no existan [[incrustaciones]].

[[Sistema de adición de agua de lavado]]




[[Clase flotación 25 Nov - Flotación Columnar]]