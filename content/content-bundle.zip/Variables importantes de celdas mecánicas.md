1. Geometría: la mayoría tiene una geometría cilíndrica, ¿porqué?
_De manera que reduce la presencia de zonas muertas en la celda mejorando la homogeneidad de la distribución de pulpa en la máquina_.
Razones de porqué se usan geometrías cilíndricas:
[[celda rectangular de flotación]]
[[tiempo de residencia en cada celda]]
[[Distancia de nado de la partícula]]
[[Canaletas periféricas]]

2. Tamaño de la celda: 
![[Pasted image 20221122113107.png]]
En el año 60-70 teníamos celdas más pequeñas. 
### ¿Porqué se usan celdas de mayor tamaño?
_Pocas celdas grandes o muchas celdas chicas? celdas grandes, menos sistemas de control, menos operadores, simplicidad._ _Menor costo de mantención, ahorro de espacios, menos problemas._

[[Celdas columnares]]


[[Celdas mecánicas]]

