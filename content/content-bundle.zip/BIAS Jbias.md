Fracción neta de agua de lavado que fluye a través de la espuma. También se puede expresar como cm/s.

[[Clase flotación 25 Nov - Flotación Columnar]]