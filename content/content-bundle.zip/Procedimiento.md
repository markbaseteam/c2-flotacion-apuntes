- después de moler, se trasvasijó la pulpa a la celda de flotación (la pulpa fue trasvasijada a la celda de flotación), lavando tanto el molino como las bolas para no tener pérdidas de mineral
- Luego de vaciar toda la pulpa en la celda de flotación, se prepararon los reactivos a usar en la única prueba de flotación: Los colectores xantato y AERO MX 7017, ambos en dosis de 20 [g/t] y de espumante MIBC 15 [g/t], además de lechada de cal. El acondicionamiento de la pulpa fue de 2 minutos donde se dejó mezclar la pulpa y se calibro el pH con el CaO. Luego se abrió la válvula de aire y se paleteó cada 10 segundos hasta completar un tiempo máximo de flotación de 16 minutos.


[[Lab 4 de Flotación]]
[[Clase Flotación 29 Nov-Depresión de la pirita]]