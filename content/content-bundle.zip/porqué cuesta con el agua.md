- Por el tipo de enlace que tiene el agua

[[Impacto de la humedad en el concentrado]]