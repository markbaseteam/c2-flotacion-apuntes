---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.22",
	"elements": [
		{
			"type": "freedraw",
			"version": 42,
			"versionNonce": 1022870259,
			"isDeleted": false,
			"id": "mRWL0E_Px3MplT5mIQngD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1116.2916666666677,
			"y": -575.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 156,
			"seed": 1157874050,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359171,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					0
				],
				[
					0,
					-16
				],
				[
					4,
					-44
				],
				[
					8,
					-68
				],
				[
					12,
					-108
				],
				[
					20,
					-136
				],
				[
					24,
					-148
				],
				[
					24,
					-152
				],
				[
					36,
					-128
				],
				[
					44,
					-96
				],
				[
					48,
					-64
				],
				[
					52,
					-40
				],
				[
					56,
					-24
				],
				[
					60,
					-12
				],
				[
					60,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0107421875,
				0.1796875,
				0.2822265625,
				0.34765625,
				0.376953125,
				0.3857421875,
				0.37109375,
				0.36328125,
				0.3583984375,
				0.353515625,
				0.361328125,
				0.392578125,
				0.41015625,
				0.4208984375,
				0.3916015625,
				0.2919921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 26237373,
			"isDeleted": false,
			"id": "RPz9Vut0oF4awDlyvs6WM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1108.2916666666677,
			"y": -627.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 20,
			"seed": 1550671682,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359171,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					-4
				],
				[
					0,
					-8
				],
				[
					8,
					-8
				],
				[
					16,
					-12
				],
				[
					32,
					-20
				],
				[
					44,
					-20
				],
				[
					48,
					-20
				],
				[
					48,
					-20
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.041015625,
				0.140625,
				0.2734375,
				0.318359375,
				0.3310546875,
				0.333984375,
				0.2509765625,
				0.134765625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 38,
			"versionNonce": 1636363411,
			"isDeleted": false,
			"id": "3jrQrzldLSiGUTA6uC2aS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1036.2916666666677,
			"y": -671.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 120,
			"seed": 785269534,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359171,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					8
				],
				[
					0,
					20
				],
				[
					4,
					40
				],
				[
					4,
					60
				],
				[
					4,
					80
				],
				[
					4,
					100
				],
				[
					0,
					112
				],
				[
					-8,
					120
				],
				[
					-12,
					120
				],
				[
					-20,
					112
				],
				[
					-20,
					112
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1201171875,
				0.2841796875,
				0.3447265625,
				0.400390625,
				0.451171875,
				0.4833984375,
				0.513671875,
				0.5244140625,
				0.5029296875,
				0.388671875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 154671645,
			"isDeleted": false,
			"id": "6q97sQNldI29nWQ8I3B0B",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1056.2916666666677,
			"y": -663.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 12,
			"seed": 1911328990,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359171,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.099609375,
				0.2158203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 40,
			"versionNonce": 1501815347,
			"isDeleted": false,
			"id": "LcpPhdmbG0aDmXQgMg8gZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1012.2916666666677,
			"y": -663.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 64,
			"seed": 1559139742,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359171,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					12
				],
				[
					0,
					20
				],
				[
					4,
					40
				],
				[
					12,
					52
				],
				[
					20,
					64
				],
				[
					24,
					64
				],
				[
					36,
					60
				],
				[
					40,
					48
				],
				[
					40,
					32
				],
				[
					40,
					24
				],
				[
					40,
					20
				],
				[
					40,
					12
				],
				[
					40,
					12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0263671875,
				0.1728515625,
				0.2490234375,
				0.2900390625,
				0.326171875,
				0.345703125,
				0.3603515625,
				0.3642578125,
				0.365234375,
				0.373046875,
				0.3662109375,
				0.341796875,
				0.279296875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 43,
			"versionNonce": 1523109501,
			"isDeleted": false,
			"id": "zPNc1BaLKF-zErTD3Lz3t",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -932.2916666666677,
			"y": -667.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 64,
			"seed": 954767262,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359171,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					0
				],
				[
					-12,
					4
				],
				[
					-16,
					8
				],
				[
					-20,
					12
				],
				[
					-20,
					20
				],
				[
					-12,
					36
				],
				[
					-4,
					44
				],
				[
					-4,
					52
				],
				[
					-4,
					56
				],
				[
					-4,
					60
				],
				[
					-12,
					64
				],
				[
					-24,
					64
				],
				[
					-32,
					64
				],
				[
					-36,
					60
				],
				[
					-40,
					52
				],
				[
					-40,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0185546875,
				0.1318359375,
				0.216796875,
				0.279296875,
				0.3076171875,
				0.3203125,
				0.3212890625,
				0.3310546875,
				0.357421875,
				0.40234375,
				0.4287109375,
				0.4462890625,
				0.4697265625,
				0.4443359375,
				0.40234375,
				0.359375,
				0.1181640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 768549843,
			"isDeleted": false,
			"id": "atqeKxWotu3QZGkjgYN90",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -920.2916666666677,
			"y": -687.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 88,
			"seed": 1835900674,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359171,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					0,
					36
				],
				[
					4,
					52
				],
				[
					4,
					68
				],
				[
					8,
					80
				],
				[
					8,
					88
				],
				[
					8,
					88
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.33984375,
				0.4345703125,
				0.4658203125,
				0.47265625,
				0.4482421875,
				0.349609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 53,
			"versionNonce": 889452253,
			"isDeleted": false,
			"id": "OoXKqg3jO1HOZb4gEh9Ai",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -932.2916666666677,
			"y": -623.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 92,
			"height": 56,
			"seed": 525617950,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					-4
				],
				[
					-8,
					-8
				],
				[
					0,
					-12
				],
				[
					8,
					-20
				],
				[
					20,
					-20
				],
				[
					32,
					-24
				],
				[
					36,
					-28
				],
				[
					40,
					-28
				],
				[
					40,
					-24
				],
				[
					40,
					-20
				],
				[
					36,
					-4
				],
				[
					32,
					8
				],
				[
					36,
					16
				],
				[
					40,
					28
				],
				[
					48,
					28
				],
				[
					56,
					28
				],
				[
					64,
					16
				],
				[
					68,
					4
				],
				[
					68,
					0
				],
				[
					64,
					-8
				],
				[
					64,
					-4
				],
				[
					64,
					12
				],
				[
					72,
					24
				],
				[
					76,
					28
				],
				[
					84,
					24
				],
				[
					84,
					24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0458984375,
				0.1865234375,
				0.2548828125,
				0.310546875,
				0.314453125,
				0.2841796875,
				0.216796875,
				0.1591796875,
				0.1328125,
				0.2548828125,
				0.2900390625,
				0.3642578125,
				0.416015625,
				0.4345703125,
				0.447265625,
				0.443359375,
				0.4326171875,
				0.419921875,
				0.4033203125,
				0.40625,
				0.41796875,
				0.435546875,
				0.4384765625,
				0.4013671875,
				0.3037109375,
				0.126953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 40,
			"versionNonce": 109130099,
			"isDeleted": false,
			"id": "A_7aPDdqTBjyteR51FAUs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -840.2916666666677,
			"y": -639.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 36,
			"seed": 1586586178,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					-4,
					20
				],
				[
					-4,
					28
				],
				[
					-4,
					32
				],
				[
					-4,
					36
				],
				[
					-8,
					28
				],
				[
					-8,
					16
				],
				[
					-4,
					8
				],
				[
					0,
					8
				],
				[
					8,
					16
				],
				[
					16,
					24
				],
				[
					20,
					28
				],
				[
					20,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.21484375,
				0.2578125,
				0.3193359375,
				0.359375,
				0.3720703125,
				0.3955078125,
				0.4208984375,
				0.4091796875,
				0.4150390625,
				0.4140625,
				0.408203125,
				0.35546875,
				0.26953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 62,
			"versionNonce": 41620285,
			"isDeleted": false,
			"id": "U2xghgCG6dmBZwEITFem9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -804.2916666666677,
			"y": -651.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 120,
			"height": 80,
			"seed": 1798930498,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					8
				],
				[
					-12,
					20
				],
				[
					-16,
					36
				],
				[
					-12,
					48
				],
				[
					-8,
					48
				],
				[
					0,
					52
				],
				[
					12,
					44
				],
				[
					20,
					32
				],
				[
					24,
					20
				],
				[
					20,
					-8
				],
				[
					16,
					-24
				],
				[
					12,
					-28
				],
				[
					8,
					-12
				],
				[
					12,
					12
				],
				[
					20,
					32
				],
				[
					32,
					44
				],
				[
					44,
					44
				],
				[
					52,
					40
				],
				[
					56,
					28
				],
				[
					56,
					16
				],
				[
					52,
					4
				],
				[
					56,
					16
				],
				[
					60,
					28
				],
				[
					72,
					44
				],
				[
					84,
					48
				],
				[
					96,
					48
				],
				[
					104,
					40
				],
				[
					104,
					28
				],
				[
					100,
					12
				],
				[
					92,
					0
				],
				[
					84,
					-4
				],
				[
					72,
					0
				],
				[
					64,
					8
				],
				[
					60,
					8
				],
				[
					60,
					8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.021484375,
				0.23046875,
				0.3779296875,
				0.4423828125,
				0.470703125,
				0.4853515625,
				0.4873046875,
				0.48828125,
				0.490234375,
				0.4892578125,
				0.494140625,
				0.4736328125,
				0.4697265625,
				0.478515625,
				0.5078125,
				0.505859375,
				0.5078125,
				0.501953125,
				0.484375,
				0.466796875,
				0.4326171875,
				0.408203125,
				0.4013671875,
				0.4326171875,
				0.453125,
				0.466796875,
				0.474609375,
				0.4814453125,
				0.4833984375,
				0.490234375,
				0.5068359375,
				0.544921875,
				0.564453125,
				0.55078125,
				0.4130859375,
				0.2177734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1155566355,
			"isDeleted": false,
			"id": "FcmcMmeLfiIvrBxacqLkS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -584.2916666666677,
			"y": -707.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 108,
			"seed": 8866690,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-8,
					32
				],
				[
					-8,
					56
				],
				[
					-8,
					84
				],
				[
					0,
					100
				],
				[
					8,
					108
				],
				[
					12,
					108
				],
				[
					12,
					108
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.2841796875,
				0.3701171875,
				0.4072265625,
				0.4130859375,
				0.3388671875,
				0.203125,
				0.0986328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 46,
			"versionNonce": 1603249053,
			"isDeleted": false,
			"id": "39hgg0f-mrXW6pMoTdNYY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -548.2916666666677,
			"y": -647.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 64,
			"seed": 1178458690,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-8
				],
				[
					-8,
					-16
				],
				[
					-16,
					-12
				],
				[
					-24,
					0
				],
				[
					-28,
					20
				],
				[
					-28,
					36
				],
				[
					-24,
					44
				],
				[
					-16,
					48
				],
				[
					-4,
					44
				],
				[
					4,
					36
				],
				[
					8,
					20
				],
				[
					4,
					4
				],
				[
					4,
					0
				],
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					0,
					28
				],
				[
					4,
					40
				],
				[
					16,
					48
				],
				[
					20,
					48
				],
				[
					20,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0849609375,
				0.1748046875,
				0.2919921875,
				0.3671875,
				0.4033203125,
				0.419921875,
				0.423828125,
				0.42578125,
				0.423828125,
				0.41796875,
				0.3984375,
				0.376953125,
				0.3720703125,
				0.3701171875,
				0.3837890625,
				0.3818359375,
				0.3388671875,
				0.1357421875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 47,
			"versionNonce": 1566814387,
			"isDeleted": false,
			"id": "1dYKb3lS6NyHUbfUN5mwI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -476.29166666666765,
			"y": -651.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 60,
			"seed": 2076116866,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-8,
					0
				],
				[
					-8,
					4
				],
				[
					-4,
					12
				],
				[
					0,
					16
				],
				[
					12,
					16
				],
				[
					24,
					12
				],
				[
					32,
					4
				],
				[
					32,
					-4
				],
				[
					32,
					-16
				],
				[
					20,
					-24
				],
				[
					8,
					-24
				],
				[
					0,
					-16
				],
				[
					-8,
					0
				],
				[
					-8,
					16
				],
				[
					-8,
					24
				],
				[
					0,
					32
				],
				[
					16,
					36
				],
				[
					28,
					32
				],
				[
					32,
					32
				],
				[
					32,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.130859375,
				0.287109375,
				0.310546875,
				0.3525390625,
				0.3603515625,
				0.369140625,
				0.375,
				0.3828125,
				0.3857421875,
				0.3818359375,
				0.3896484375,
				0.419921875,
				0.4521484375,
				0.4853515625,
				0.4970703125,
				0.5009765625,
				0.494140625,
				0.3515625,
				0.2333984375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 1618159613,
			"isDeleted": false,
			"id": "ZmngGUoznKogs_AdFNA2U",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -420.29166666666765,
			"y": -671.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 56,
			"seed": 1301129310,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					4
				],
				[
					-16,
					20
				],
				[
					-16,
					36
				],
				[
					-16,
					44
				],
				[
					-12,
					52
				],
				[
					-8,
					56
				],
				[
					0,
					56
				],
				[
					12,
					52
				],
				[
					16,
					44
				],
				[
					16,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.2744140625,
				0.41015625,
				0.47265625,
				0.4990234375,
				0.5146484375,
				0.51953125,
				0.4638671875,
				0.3310546875,
				0.1279296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 50,
			"versionNonce": 1907434067,
			"isDeleted": false,
			"id": "J71W3DiU7uWnjG6okT3FK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1216.2916666666677,
			"y": -403.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 120,
			"seed": 1169639902,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-12
				],
				[
					8,
					-24
				],
				[
					20,
					-40
				],
				[
					32,
					-44
				],
				[
					44,
					-44
				],
				[
					56,
					-32
				],
				[
					60,
					-16
				],
				[
					56,
					8
				],
				[
					48,
					28
				],
				[
					32,
					44
				],
				[
					24,
					48
				],
				[
					16,
					52
				],
				[
					8,
					52
				],
				[
					8,
					44
				],
				[
					12,
					40
				],
				[
					20,
					40
				],
				[
					32,
					44
				],
				[
					44,
					52
				],
				[
					52,
					64
				],
				[
					60,
					68
				],
				[
					64,
					72
				],
				[
					68,
					76
				],
				[
					68,
					76
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2646484375,
				0.26953125,
				0.271484375,
				0.26953125,
				0.2705078125,
				0.275390625,
				0.2880859375,
				0.3125,
				0.3310546875,
				0.3369140625,
				0.333984375,
				0.32421875,
				0.3212890625,
				0.3173828125,
				0.31640625,
				0.32421875,
				0.3447265625,
				0.390625,
				0.41015625,
				0.41796875,
				0.412109375,
				0.3310546875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 53,
			"versionNonce": 388440157,
			"isDeleted": false,
			"id": "4R7eW5JRtLzuHqiPYc1oI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1032.2916666666677,
			"y": -431.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 80,
			"height": 112,
			"seed": 785375518,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					8
				],
				[
					-16,
					16
				],
				[
					-24,
					24
				],
				[
					-36,
					32
				],
				[
					-44,
					40
				],
				[
					-52,
					44
				],
				[
					-52,
					48
				],
				[
					-40,
					48
				],
				[
					-28,
					48
				],
				[
					-24,
					44
				],
				[
					-16,
					44
				],
				[
					-12,
					44
				],
				[
					-12,
					48
				],
				[
					-28,
					64
				],
				[
					-44,
					76
				],
				[
					-60,
					88
				],
				[
					-72,
					100
				],
				[
					-80,
					104
				],
				[
					-80,
					108
				],
				[
					-72,
					112
				],
				[
					-60,
					108
				],
				[
					-44,
					108
				],
				[
					-28,
					104
				],
				[
					-16,
					104
				],
				[
					-8,
					100
				],
				[
					-4,
					100
				],
				[
					-4,
					100
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0029296875,
				0.2509765625,
				0.2890625,
				0.3076171875,
				0.328125,
				0.3369140625,
				0.34375,
				0.34375,
				0.34375,
				0.3427734375,
				0.3447265625,
				0.3466796875,
				0.357421875,
				0.3642578125,
				0.3623046875,
				0.3466796875,
				0.33984375,
				0.3427734375,
				0.34765625,
				0.3486328125,
				0.37109375,
				0.38671875,
				0.3955078125,
				0.40234375,
				0.4013671875,
				0.3359375,
				0.3017578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 50,
			"versionNonce": 715087859,
			"isDeleted": false,
			"id": "5APOhp88Vug8kMPdJDZKa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1088.2916666666677,
			"y": -479.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 40,
			"seed": 79211586,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					20
				],
				[
					4,
					28
				],
				[
					4,
					32
				],
				[
					4,
					36
				],
				[
					0,
					36
				],
				[
					4,
					20
				],
				[
					8,
					12
				],
				[
					12,
					8
				],
				[
					16,
					12
				],
				[
					20,
					20
				],
				[
					24,
					32
				],
				[
					28,
					36
				],
				[
					28,
					40
				],
				[
					28,
					36
				],
				[
					32,
					28
				],
				[
					36,
					12
				],
				[
					40,
					8
				],
				[
					44,
					12
				],
				[
					48,
					24
				],
				[
					52,
					28
				],
				[
					56,
					36
				],
				[
					56,
					40
				],
				[
					56,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.150390625,
				0.2265625,
				0.2607421875,
				0.2763671875,
				0.298828125,
				0.353515625,
				0.3525390625,
				0.3525390625,
				0.357421875,
				0.373046875,
				0.3984375,
				0.4130859375,
				0.4169921875,
				0.419921875,
				0.416015625,
				0.396484375,
				0.375,
				0.37109375,
				0.40234375,
				0.4208984375,
				0.4228515625,
				0.328125,
				0.2373046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1501367485,
			"isDeleted": false,
			"id": "fwIn42o35vNrqhc6rXD7r",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1104.2916666666677,
			"y": -267.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 36,
			"seed": 208019714,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					36
				],
				[
					4,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.3876953125,
				0.412109375,
				0.4169921875,
				0.3505859375,
				0.2578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1379199379,
			"isDeleted": false,
			"id": "Y9Z8cn2b1GHGxc1f36cQm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1112.2916666666677,
			"y": -279.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 133468162,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-8
				],
				[
					0,
					-12
				],
				[
					4,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0029296875,
				0.2314453125,
				0.2412109375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1192652061,
			"isDeleted": false,
			"id": "oMvBMr9LFyHBKsLl44fzE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1072.2916666666677,
			"y": -267.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 4,
			"seed": 1139004894,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					8,
					0
				],
				[
					12,
					0
				],
				[
					16,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3095703125,
				0.3466796875,
				0.359375,
				0.3388671875,
				0.2734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 766000947,
			"isDeleted": false,
			"id": "XapypcLNNwjKNvdIKl5uX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1076.2916666666677,
			"y": -251.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 4,
			"seed": 4386306,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					8,
					4
				],
				[
					16,
					4
				],
				[
					20,
					4
				],
				[
					24,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.162109375,
				0.33984375,
				0.3662109375,
				0.3828125,
				0.3720703125,
				0.32421875,
				0.1904296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 258261373,
			"isDeleted": false,
			"id": "fqzuuySBnJ_qNnc7-mCyg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1028.2916666666677,
			"y": -283.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 48,
			"seed": 1915730014,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					8,
					28
				],
				[
					8,
					40
				],
				[
					12,
					44
				],
				[
					12,
					48
				],
				[
					12,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.35546875,
				0.408203125,
				0.4384765625,
				0.4453125,
				0.423828125,
				0.353515625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 50,
			"versionNonce": 392159443,
			"isDeleted": false,
			"id": "xS6xbSb2LbqSE3XJ8lgUS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -988.2916666666677,
			"y": -403.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 80,
			"height": 60,
			"seed": 424522626,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					20
				],
				[
					4,
					40
				],
				[
					12,
					48
				],
				[
					16,
					56
				],
				[
					20,
					56
				],
				[
					28,
					56
				],
				[
					32,
					48
				],
				[
					36,
					32
				],
				[
					36,
					16
				],
				[
					36,
					4
				],
				[
					32,
					4
				],
				[
					36,
					20
				],
				[
					36,
					32
				],
				[
					44,
					48
				],
				[
					52,
					56
				],
				[
					56,
					56
				],
				[
					68,
					48
				],
				[
					72,
					36
				],
				[
					76,
					24
				],
				[
					72,
					8
				],
				[
					72,
					0
				],
				[
					68,
					-4
				],
				[
					68,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.12890625,
				0.2724609375,
				0.3212890625,
				0.3486328125,
				0.36328125,
				0.3740234375,
				0.3798828125,
				0.38671875,
				0.388671875,
				0.3759765625,
				0.369140625,
				0.37890625,
				0.39453125,
				0.4072265625,
				0.421875,
				0.4287109375,
				0.4326171875,
				0.455078125,
				0.4697265625,
				0.4873046875,
				0.4853515625,
				0.4697265625,
				0.36328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 2007599581,
			"isDeleted": false,
			"id": "mlDdz689OoNEKu-BcC2Yq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -892.2916666666677,
			"y": -391.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 44,
			"seed": 583753794,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					4,
					32
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0234375,
				0.3310546875,
				0.4130859375,
				0.4404296875,
				0.451171875,
				0.4599609375,
				0.4482421875,
				0.3359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1492274803,
			"isDeleted": false,
			"id": "kliCrf8P-Cc4mdgrdxpOZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -900.2916666666677,
			"y": -403.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 16,
			"seed": 194836226,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					0,
					-12
				],
				[
					0,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.119140625,
				0.197265625,
				0.322265625,
				0.365234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 553010749,
			"isDeleted": false,
			"id": "hEONnMMx0C4hmu33U2cW4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -848.2916666666677,
			"y": -419.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 4,
			"seed": 34629122,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359172,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					20,
					4
				],
				[
					32,
					0
				],
				[
					40,
					0
				],
				[
					44,
					0
				],
				[
					48,
					0
				],
				[
					48,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2646484375,
				0.3369140625,
				0.3642578125,
				0.4111328125,
				0.4189453125,
				0.396484375,
				0.3671875,
				0.3037109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1160120339,
			"isDeleted": false,
			"id": "GrpmuSZ_KflM8b9b9ODuZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -828.2916666666677,
			"y": -423.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 64,
			"seed": 1062256734,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					8
				],
				[
					-4,
					20
				],
				[
					0,
					36
				],
				[
					0,
					48
				],
				[
					0,
					56
				],
				[
					0,
					60
				],
				[
					0,
					64
				],
				[
					0,
					64
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1865234375,
				0.2490234375,
				0.3330078125,
				0.3857421875,
				0.404296875,
				0.39453125,
				0.3603515625,
				0.2099609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 40,
			"versionNonce": 237794973,
			"isDeleted": false,
			"id": "jz5tw5Xqq0aqe5U1fxmrc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -844.2916666666677,
			"y": -375.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 36,
			"seed": 775449410,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					12,
					-8
				],
				[
					20,
					-12
				],
				[
					28,
					-12
				],
				[
					32,
					-8
				],
				[
					40,
					-4
				],
				[
					44,
					0
				],
				[
					44,
					8
				],
				[
					48,
					16
				],
				[
					48,
					20
				],
				[
					52,
					24
				],
				[
					52,
					24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1669921875,
				0.2587890625,
				0.302734375,
				0.3212890625,
				0.32421875,
				0.2783203125,
				0.2509765625,
				0.2529296875,
				0.296875,
				0.3291015625,
				0.349609375,
				0.357421875,
				0.318359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 301043123,
			"isDeleted": false,
			"id": "c5IYnDj-bPnpFnV9xWHHs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -800.2916666666677,
			"y": -383.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 20,
			"seed": 1283950914,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					-8
				],
				[
					-4,
					-16
				],
				[
					-4,
					-20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0068359375,
				0.1064453125,
				0.17578125,
				0.2763671875,
				0.3271484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1778227965,
			"isDeleted": false,
			"id": "MHCTnaEXGLttEaniCXezY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -732.2916666666677,
			"y": -367.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 12,
			"seed": 486529090,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8,
					-4
				],
				[
					20,
					-4
				],
				[
					36,
					-8
				],
				[
					44,
					-8
				],
				[
					48,
					-8
				],
				[
					52,
					-8
				],
				[
					52,
					-12
				],
				[
					52,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3125,
				0.3583984375,
				0.3876953125,
				0.3955078125,
				0.390625,
				0.359375,
				0.248046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1920687955,
			"isDeleted": false,
			"id": "TZkAaIocg-0eMoeJbRvd0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -704.2916666666677,
			"y": -403.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 56,
			"seed": 1040609026,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					-4,
					12
				],
				[
					-4,
					24
				],
				[
					0,
					36
				],
				[
					0,
					48
				],
				[
					0,
					52
				],
				[
					0,
					56
				],
				[
					0,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3076171875,
				0.396484375,
				0.4501953125,
				0.47265625,
				0.482421875,
				0.478515625,
				0.3671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 55,
			"versionNonce": 216740701,
			"isDeleted": false,
			"id": "jeqR8_QVoaoPV214xbkVs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -576.2916666666677,
			"y": -431.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76,
			"height": 112,
			"seed": 777440706,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-12,
					12
				],
				[
					-28,
					24
				],
				[
					-40,
					36
				],
				[
					-48,
					44
				],
				[
					-52,
					48
				],
				[
					-52,
					52
				],
				[
					-48,
					56
				],
				[
					-40,
					56
				],
				[
					-24,
					56
				],
				[
					-8,
					52
				],
				[
					4,
					52
				],
				[
					8,
					52
				],
				[
					8,
					56
				],
				[
					0,
					64
				],
				[
					-16,
					76
				],
				[
					-32,
					84
				],
				[
					-44,
					92
				],
				[
					-48,
					100
				],
				[
					-52,
					104
				],
				[
					-48,
					108
				],
				[
					-36,
					112
				],
				[
					-20,
					112
				],
				[
					-4,
					112
				],
				[
					12,
					112
				],
				[
					16,
					112
				],
				[
					20,
					112
				],
				[
					24,
					108
				],
				[
					24,
					108
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.115234375,
				0.1962890625,
				0.2578125,
				0.287109375,
				0.2998046875,
				0.306640625,
				0.3056640625,
				0.2978515625,
				0.2998046875,
				0.3046875,
				0.3271484375,
				0.3525390625,
				0.3642578125,
				0.3876953125,
				0.39453125,
				0.396484375,
				0.404296875,
				0.4140625,
				0.4248046875,
				0.4326171875,
				0.4404296875,
				0.4521484375,
				0.45703125,
				0.4609375,
				0.4580078125,
				0.4365234375,
				0.3251953125,
				0.15234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 44,
			"versionNonce": 1897528563,
			"isDeleted": false,
			"id": "ooohRo9u8oUJcsTqFiq46",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -624.2916666666677,
			"y": -479.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 36,
			"seed": 1324318494,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					0,
					20
				],
				[
					0,
					24
				],
				[
					0,
					32
				],
				[
					0,
					36
				],
				[
					0,
					32
				],
				[
					0,
					20
				],
				[
					0,
					12
				],
				[
					4,
					4
				],
				[
					8,
					4
				],
				[
					12,
					8
				],
				[
					16,
					12
				],
				[
					20,
					20
				],
				[
					24,
					24
				],
				[
					28,
					32
				],
				[
					28,
					36
				],
				[
					28,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2919921875,
				0.32421875,
				0.3486328125,
				0.3564453125,
				0.3740234375,
				0.4033203125,
				0.419921875,
				0.3984375,
				0.39453125,
				0.388671875,
				0.39453125,
				0.4130859375,
				0.4267578125,
				0.431640625,
				0.412109375,
				0.212890625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 1128710077,
			"isDeleted": false,
			"id": "UkEqh5MacrzjuWlmj-fmW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -648.2916666666677,
			"y": -259.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 68,
			"seed": 133484958,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					8,
					12
				],
				[
					8,
					24
				],
				[
					8,
					40
				],
				[
					4,
					52
				],
				[
					4,
					60
				],
				[
					0,
					68
				],
				[
					-4,
					68
				],
				[
					-8,
					68
				],
				[
					-12,
					56
				],
				[
					-12,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.2548828125,
				0.40625,
				0.490234375,
				0.5625,
				0.60546875,
				0.6181640625,
				0.57421875,
				0.5361328125,
				0.3671875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 156493459,
			"isDeleted": false,
			"id": "g_0rXiQT-RRUbNFjXTv8v",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -668.2916666666677,
			"y": -255.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 20,
			"seed": 670385602,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-12
				],
				[
					4,
					-16
				],
				[
					8,
					-20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0908203125,
				0.20703125,
				0.2431640625,
				0.275390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1395769373,
			"isDeleted": false,
			"id": "wpJJiIbl15RmZfY7mNOIi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -624.2916666666677,
			"y": -259.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 4,
			"seed": 795563202,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					12,
					4
				],
				[
					24,
					4
				],
				[
					28,
					4
				],
				[
					32,
					4
				],
				[
					32,
					4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.1123046875,
				0.3603515625,
				0.4140625,
				0.4677734375,
				0.46484375,
				0.41796875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 31431731,
			"isDeleted": false,
			"id": "blTlajSEtMWiLlEmZ-m96",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -612.2916666666677,
			"y": -243.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 8,
			"seed": 1651552606,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					-4,
					4
				],
				[
					-4,
					8
				],
				[
					4,
					8
				],
				[
					12,
					4
				],
				[
					16,
					4
				],
				[
					20,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.10546875,
				0.1943359375,
				0.3310546875,
				0.3671875,
				0.322265625,
				0.2822265625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1117631613,
			"isDeleted": false,
			"id": "urrECILnN7y4vsZHpmcHp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -572.2916666666677,
			"y": -267.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 44,
			"seed": 786999874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					8,
					32
				],
				[
					8,
					36
				],
				[
					8,
					40
				],
				[
					8,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.16796875,
				0.412109375,
				0.4765625,
				0.5126953125,
				0.5126953125,
				0.4970703125,
				0.4736328125,
				0.400390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 111386067,
			"isDeleted": false,
			"id": "5VHNqKSJ87PXrG1FD1Xr1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -504.29166666666765,
			"y": -407.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 72,
			"seed": 1599211550,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					20,
					8
				],
				[
					28,
					24
				],
				[
					36,
					40
				],
				[
					40,
					56
				],
				[
					40,
					64
				],
				[
					44,
					64
				],
				[
					44,
					68
				],
				[
					44,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.216796875,
				0.314453125,
				0.396484375,
				0.4716796875,
				0.5234375,
				0.55078125,
				0.5634765625,
				0.513671875,
				0.455078125,
				0.353515625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 1565269213,
			"isDeleted": false,
			"id": "esREgEcjpeFdHxOdvYnbf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -476.29166666666765,
			"y": -363.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 52,
			"seed": 1814665026,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-8,
					-4
				],
				[
					-12,
					0
				],
				[
					-16,
					8
				],
				[
					-24,
					20
				],
				[
					-24,
					36
				],
				[
					-28,
					44
				],
				[
					-24,
					48
				],
				[
					-20,
					48
				],
				[
					-20,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.1689453125,
				0.263671875,
				0.3974609375,
				0.458984375,
				0.5068359375,
				0.5263671875,
				0.49609375,
				0.3447265625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 38,
			"versionNonce": 45509491,
			"isDeleted": false,
			"id": "n6WFakIHAQPa0rPAFkJ9j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -420.29166666666765,
			"y": -351.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 68,
			"seed": 1907604930,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					24
				],
				[
					0,
					32
				],
				[
					-4,
					48
				],
				[
					-8,
					56
				],
				[
					-12,
					64
				],
				[
					-16,
					68
				],
				[
					-24,
					68
				],
				[
					-28,
					60
				],
				[
					-28,
					56
				],
				[
					-28,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2607421875,
				0.3046875,
				0.3974609375,
				0.4287109375,
				0.49609375,
				0.517578125,
				0.5361328125,
				0.5244140625,
				0.4208984375,
				0.2412109375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 2060351805,
			"isDeleted": false,
			"id": "pQur0Uz9e04EQejnKs0mI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -440.29166666666765,
			"y": -367.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 1642671106,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0888671875,
				0.185546875,
				0.28125,
				0.3212890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 53,
			"versionNonce": 979272979,
			"isDeleted": false,
			"id": "xWFYH7p7ZXOLj8x9YWwZz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -340.29166666666765,
			"y": -443.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 88,
			"height": 116,
			"seed": 1511660290,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					-8,
					12
				],
				[
					-16,
					24
				],
				[
					-24,
					32
				],
				[
					-36,
					40
				],
				[
					-40,
					48
				],
				[
					-40,
					52
				],
				[
					-36,
					52
				],
				[
					-24,
					56
				],
				[
					-12,
					52
				],
				[
					4,
					56
				],
				[
					8,
					56
				],
				[
					8,
					60
				],
				[
					0,
					68
				],
				[
					-12,
					80
				],
				[
					-28,
					88
				],
				[
					-40,
					100
				],
				[
					-40,
					104
				],
				[
					-44,
					112
				],
				[
					-36,
					116
				],
				[
					-20,
					116
				],
				[
					-4,
					116
				],
				[
					24,
					116
				],
				[
					36,
					116
				],
				[
					40,
					112
				],
				[
					44,
					112
				],
				[
					44,
					112
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1376953125,
				0.236328125,
				0.2802734375,
				0.310546875,
				0.3486328125,
				0.3623046875,
				0.3671875,
				0.3681640625,
				0.37109375,
				0.3681640625,
				0.375,
				0.3837890625,
				0.39453125,
				0.3974609375,
				0.3994140625,
				0.390625,
				0.4033203125,
				0.408203125,
				0.431640625,
				0.439453125,
				0.4453125,
				0.4443359375,
				0.451171875,
				0.419921875,
				0.37890625,
				0.1474609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 52,
			"versionNonce": 75909533,
			"isDeleted": false,
			"id": "hrctQXpJRoTaUb0-s_UCJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -376.29166666666765,
			"y": -479.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 40,
			"seed": 707584414,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					12
				],
				[
					4,
					20
				],
				[
					4,
					24
				],
				[
					4,
					28
				],
				[
					0,
					24
				],
				[
					0,
					20
				],
				[
					4,
					8
				],
				[
					8,
					-4
				],
				[
					12,
					-8
				],
				[
					16,
					-8
				],
				[
					24,
					4
				],
				[
					28,
					12
				],
				[
					32,
					20
				],
				[
					32,
					24
				],
				[
					32,
					20
				],
				[
					36,
					12
				],
				[
					36,
					8
				],
				[
					40,
					0
				],
				[
					44,
					0
				],
				[
					52,
					4
				],
				[
					56,
					12
				],
				[
					60,
					20
				],
				[
					64,
					28
				],
				[
					68,
					32
				],
				[
					68,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0068359375,
				0.1904296875,
				0.2724609375,
				0.3173828125,
				0.3505859375,
				0.361328125,
				0.4052734375,
				0.4052734375,
				0.3994140625,
				0.4013671875,
				0.3984375,
				0.3994140625,
				0.4150390625,
				0.4228515625,
				0.4296875,
				0.4365234375,
				0.4228515625,
				0.40234375,
				0.39453125,
				0.3828125,
				0.37890625,
				0.3857421875,
				0.388671875,
				0.3818359375,
				0.2890625,
				0.1552734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 621963955,
			"isDeleted": false,
			"id": "jrEp48CG0COLlU1Ccn9S7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -360.29166666666765,
			"y": -271.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 44,
			"seed": 2121209118,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					8
				],
				[
					-8,
					20
				],
				[
					-8,
					28
				],
				[
					-4,
					36
				],
				[
					-4,
					44
				],
				[
					-4,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0263671875,
				0.3115234375,
				0.4267578125,
				0.4814453125,
				0.4990234375,
				0.4580078125,
				0.2998046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1000672765,
			"isDeleted": false,
			"id": "inuY5PVnCQ6GQEfD6zymZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -368.29166666666765,
			"y": -275.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 1926095554,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					-4,
					-16
				],
				[
					0,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.142578125,
				0.1865234375,
				0.2265625,
				0.19140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 125344851,
			"isDeleted": false,
			"id": "iALDCkd3-dhMJ4sHd4vZF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -336.29166666666765,
			"y": -279.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 4,
			"seed": 1049457090,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					20,
					0
				],
				[
					24,
					4
				],
				[
					28,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2353515625,
				0.2841796875,
				0.259765625,
				0.2119140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1059866205,
			"isDeleted": false,
			"id": "HdEPCEb66W8-2zg8gDUnT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -332.29166666666765,
			"y": -255.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 0,
			"seed": 311263426,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					16,
					0
				],
				[
					20,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2333984375,
				0.23046875,
				0.1376953125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1298635251,
			"isDeleted": false,
			"id": "EKaRNLrq2hIB8HMeb5q-f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -288.29166666666765,
			"y": -279.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 48,
			"seed": 177082306,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					4,
					28
				],
				[
					4,
					40
				],
				[
					4,
					48
				],
				[
					4,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.306640625,
				0.3994140625,
				0.4248046875,
				0.427734375,
				0.3564453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 42,
			"versionNonce": 1374515901,
			"isDeleted": false,
			"id": "3DJVYsocWrF7xeZWsX02f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -240.29166666666765,
			"y": -427.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 92,
			"seed": 1649352386,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					24
				],
				[
					0,
					48
				],
				[
					4,
					64
				],
				[
					4,
					80
				],
				[
					4,
					88
				],
				[
					8,
					88
				],
				[
					8,
					92
				],
				[
					8,
					88
				],
				[
					12,
					72
				],
				[
					20,
					52
				],
				[
					28,
					36
				],
				[
					36,
					24
				],
				[
					40,
					20
				],
				[
					40,
					16
				],
				[
					40,
					16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1630859375,
				0.3408203125,
				0.3974609375,
				0.4326171875,
				0.4521484375,
				0.4580078125,
				0.466796875,
				0.48828125,
				0.5400390625,
				0.5419921875,
				0.53125,
				0.4951171875,
				0.41796875,
				0.3623046875,
				0.236328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 602268563,
			"isDeleted": false,
			"id": "vZCsnn_O-4jUFpY7dG6Re",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -204.29166666666765,
			"y": -403.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 72,
			"seed": 1709298818,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					8
				],
				[
					-8,
					20
				],
				[
					-12,
					32
				],
				[
					-12,
					44
				],
				[
					-8,
					56
				],
				[
					0,
					64
				],
				[
					4,
					68
				],
				[
					8,
					72
				],
				[
					16,
					72
				],
				[
					20,
					72
				],
				[
					20,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.1025390625,
				0.2412109375,
				0.361328125,
				0.4384765625,
				0.4775390625,
				0.4931640625,
				0.484375,
				0.4541015625,
				0.2177734375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 38,
			"versionNonce": 1619661597,
			"isDeleted": false,
			"id": "Ob-DbD5-6iy402NAtun3t",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -168.29166666666765,
			"y": -379.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 80,
			"seed": 1233034782,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359173,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					4,
					28
				],
				[
					4,
					44
				],
				[
					4,
					56
				],
				[
					0,
					68
				],
				[
					-8,
					76
				],
				[
					-12,
					80
				],
				[
					-16,
					80
				],
				[
					-24,
					76
				],
				[
					-24,
					72
				],
				[
					-24,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.001953125,
				0.271484375,
				0.3544921875,
				0.4365234375,
				0.5048828125,
				0.560546875,
				0.5830078125,
				0.5966796875,
				0.572265625,
				0.458984375,
				0.1962890625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1395259699,
			"isDeleted": false,
			"id": "Prp65m2RlJWR4Ybl5E0hs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -192.29166666666765,
			"y": -387.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 12,
			"seed": 1117866974,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					12,
					-12
				],
				[
					16,
					-12
				],
				[
					20,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.033203125,
				0.091796875,
				0.2529296875,
				0.3466796875,
				0.3681640625,
				0.248046875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1198761853,
			"isDeleted": false,
			"id": "TlZimRL93IVwl-2jERX28",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.29166666666765,
			"y": -375.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 48,
			"seed": 1472209182,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					20
				],
				[
					0,
					28
				],
				[
					0,
					32
				],
				[
					0,
					40
				],
				[
					0,
					44
				],
				[
					0,
					48
				],
				[
					0,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0439453125,
				0.2939453125,
				0.4169921875,
				0.5302734375,
				0.5537109375,
				0.5595703125,
				0.49609375,
				0.3916015625,
				0.146484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1486510803,
			"isDeleted": false,
			"id": "_iftAhQJNin3HWG0Hx3GC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -136.29166666666765,
			"y": -383.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 12,
			"seed": 592277122,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					0,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.009765625,
				0.203125,
				0.2822265625,
				0.1162109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1491840989,
			"isDeleted": false,
			"id": "9QXEWYDD5pQUxGlhNCcdT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -80.29166666666765,
			"y": -383.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 4,
			"seed": 1116770142,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8,
					0
				],
				[
					16,
					-4
				],
				[
					20,
					-4
				],
				[
					24,
					-4
				],
				[
					28,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.41015625,
				0.4404296875,
				0.443359375,
				0.4287109375,
				0.361328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1087211635,
			"isDeleted": false,
			"id": "5j5XHmU3eRYYsCe3Snsw0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -76.29166666666765,
			"y": -375.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 8,
			"seed": 636832898,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					8
				],
				[
					4,
					8
				],
				[
					16,
					4
				],
				[
					20,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.1474609375,
				0.36328125,
				0.3818359375,
				0.3515625,
				0.2607421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 50,
			"versionNonce": 587443261,
			"isDeleted": false,
			"id": "yQvV5fktaM0rdQ545MBRU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -16.291666666667652,
			"y": -403.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76,
			"height": 100,
			"seed": 2046752158,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					-8
				],
				[
					4,
					-16
				],
				[
					12,
					-24
				],
				[
					32,
					-32
				],
				[
					44,
					-24
				],
				[
					48,
					-12
				],
				[
					48,
					4
				],
				[
					40,
					28
				],
				[
					32,
					40
				],
				[
					20,
					48
				],
				[
					8,
					56
				],
				[
					4,
					56
				],
				[
					0,
					56
				],
				[
					4,
					52
				],
				[
					12,
					48
				],
				[
					32,
					48
				],
				[
					44,
					56
				],
				[
					52,
					60
				],
				[
					60,
					64
				],
				[
					64,
					64
				],
				[
					68,
					68
				],
				[
					72,
					68
				],
				[
					72,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0341796875,
				0.0888671875,
				0.2685546875,
				0.310546875,
				0.337890625,
				0.390625,
				0.41796875,
				0.4453125,
				0.45703125,
				0.46875,
				0.46875,
				0.4697265625,
				0.4697265625,
				0.470703125,
				0.46875,
				0.462890625,
				0.4638671875,
				0.484375,
				0.5068359375,
				0.51171875,
				0.5107421875,
				0.4404296875,
				0.3291015625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 53,
			"versionNonce": 1099563539,
			"isDeleted": false,
			"id": "sJS90r0HnkIKCOIdJf-Oq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 127.70833333333235,
			"y": -459.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 88,
			"height": 128,
			"seed": 2041869534,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					-16,
					16
				],
				[
					-28,
					32
				],
				[
					-40,
					40
				],
				[
					-44,
					44
				],
				[
					-48,
					48
				],
				[
					-44,
					52
				],
				[
					-36,
					52
				],
				[
					-24,
					48
				],
				[
					-4,
					52
				],
				[
					20,
					60
				],
				[
					16,
					64
				],
				[
					8,
					72
				],
				[
					-8,
					80
				],
				[
					-24,
					88
				],
				[
					-32,
					96
				],
				[
					-36,
					96
				],
				[
					-40,
					104
				],
				[
					-32,
					108
				],
				[
					-16,
					112
				],
				[
					0,
					116
				],
				[
					16,
					120
				],
				[
					28,
					124
				],
				[
					32,
					128
				],
				[
					36,
					128
				],
				[
					40,
					128
				],
				[
					40,
					128
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.166015625,
				0.2509765625,
				0.2958984375,
				0.3369140625,
				0.34765625,
				0.3583984375,
				0.375,
				0.3818359375,
				0.3798828125,
				0.3837890625,
				0.4033203125,
				0.408203125,
				0.4013671875,
				0.396484375,
				0.40625,
				0.423828125,
				0.42578125,
				0.4443359375,
				0.4501953125,
				0.4658203125,
				0.474609375,
				0.478515625,
				0.474609375,
				0.451171875,
				0.3515625,
				0.1376953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 51,
			"versionNonce": 1973230749,
			"isDeleted": false,
			"id": "McE69mh_kz7bNO2zP9xy5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 79.70833333333235,
			"y": -503.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 36,
			"seed": 573097090,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					8
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					4,
					28
				],
				[
					4,
					24
				],
				[
					4,
					20
				],
				[
					8,
					8
				],
				[
					12,
					-4
				],
				[
					20,
					-8
				],
				[
					24,
					-4
				],
				[
					28,
					4
				],
				[
					32,
					12
				],
				[
					32,
					16
				],
				[
					32,
					20
				],
				[
					32,
					16
				],
				[
					36,
					8
				],
				[
					40,
					0
				],
				[
					44,
					-4
				],
				[
					48,
					-4
				],
				[
					52,
					4
				],
				[
					52,
					8
				],
				[
					56,
					20
				],
				[
					56,
					24
				],
				[
					56,
					24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2451171875,
				0.27734375,
				0.3037109375,
				0.32421875,
				0.337890625,
				0.3896484375,
				0.388671875,
				0.3857421875,
				0.384765625,
				0.38671875,
				0.3896484375,
				0.3916015625,
				0.392578125,
				0.396484375,
				0.4072265625,
				0.40234375,
				0.3876953125,
				0.3779296875,
				0.3740234375,
				0.3798828125,
				0.384765625,
				0.3837890625,
				0.2880859375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 51,
			"versionNonce": 331761587,
			"isDeleted": false,
			"id": "xwsExz5vBQ-O6HQaSB11f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 171.70833333333235,
			"y": -447.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 88,
			"height": 64,
			"seed": 90659806,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					20
				],
				[
					4,
					36
				],
				[
					8,
					44
				],
				[
					16,
					52
				],
				[
					24,
					56
				],
				[
					32,
					52
				],
				[
					40,
					40
				],
				[
					44,
					28
				],
				[
					44,
					12
				],
				[
					44,
					8
				],
				[
					44,
					4
				],
				[
					40,
					4
				],
				[
					40,
					20
				],
				[
					44,
					40
				],
				[
					48,
					52
				],
				[
					60,
					60
				],
				[
					68,
					64
				],
				[
					76,
					60
				],
				[
					84,
					48
				],
				[
					84,
					32
				],
				[
					84,
					16
				],
				[
					84,
					4
				],
				[
					84,
					0
				],
				[
					84,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.306640625,
				0.396484375,
				0.4443359375,
				0.4580078125,
				0.4599609375,
				0.4599609375,
				0.4609375,
				0.45703125,
				0.4541015625,
				0.455078125,
				0.4619140625,
				0.46484375,
				0.46484375,
				0.4658203125,
				0.470703125,
				0.4658203125,
				0.4638671875,
				0.4658203125,
				0.4736328125,
				0.4873046875,
				0.4921875,
				0.4951171875,
				0.4658203125,
				0.423828125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 678002941,
			"isDeleted": false,
			"id": "6U84OlgZpnnXmM2hkvoa0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 283.70833333333235,
			"y": -395.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 36,
			"seed": 340530626,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					0,
					20
				],
				[
					0,
					32
				],
				[
					0,
					36
				],
				[
					0,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.35546875,
				0.462890625,
				0.5048828125,
				0.4716796875,
				0.3623046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 229169491,
			"isDeleted": false,
			"id": "QGj3LPIDC6nfoqs-ECy8_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 287.70833333333235,
			"y": -415.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 299508930,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					-4,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.048828125,
				0.1796875,
				0.2119140625,
				0.1875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 552229213,
			"isDeleted": false,
			"id": "FQfg2Sx6I1JO4Xq6KicOG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 347.70833333333235,
			"y": -451.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 72,
			"seed": 2087236546,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-12,
					-4
				],
				[
					-20,
					4
				],
				[
					-24,
					16
				],
				[
					-28,
					32
				],
				[
					-28,
					44
				],
				[
					-24,
					56
				],
				[
					-24,
					60
				],
				[
					-24,
					68
				],
				[
					-24,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0380859375,
				0.181640625,
				0.40625,
				0.5,
				0.544921875,
				0.5625,
				0.568359375,
				0.498046875,
				0.40625,
				0.150390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 2089301747,
			"isDeleted": false,
			"id": "ybKkolEHyjiZQJrxpo9uI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 303.70833333333235,
			"y": -399.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 36,
			"seed": 2081651266,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-8
				],
				[
					16,
					-8
				],
				[
					24,
					-4
				],
				[
					32,
					4
				],
				[
					36,
					12
				],
				[
					40,
					16
				],
				[
					40,
					24
				],
				[
					40,
					28
				],
				[
					40,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.2197265625,
				0.3017578125,
				0.3486328125,
				0.380859375,
				0.3974609375,
				0.39453125,
				0.34375,
				0.2451171875,
				0.1083984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 410068413,
			"isDeleted": false,
			"id": "oEFORifK1EQRRtnWsJXz8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 347.70833333333235,
			"y": -407.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 20,
			"seed": 1066885314,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-8
				],
				[
					-4,
					-16
				],
				[
					-4,
					-20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0234375,
				0.1357421875,
				0.236328125,
				0.271484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1055580307,
			"isDeleted": false,
			"id": "Vgejt1qRnipfTRfSPInRm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 71.70833333333235,
			"y": -271.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 40,
			"seed": 1409956126,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					12
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					40
				],
				[
					4,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2431640625,
				0.3349609375,
				0.37109375,
				0.37890625,
				0.322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 572483101,
			"isDeleted": false,
			"id": "Rv8VXAo2Ei-C-M8aQDbwX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 75.70833333333235,
			"y": -275.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 4,
			"seed": 988658206,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1025390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 512185907,
			"isDeleted": false,
			"id": "R_cVtX2KvYNhNXjy1wkht",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 111.70833333333235,
			"y": -263.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 0,
			"seed": 565556802,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					16,
					0
				],
				[
					20,
					0
				],
				[
					24,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2646484375,
				0.30078125,
				0.3271484375,
				0.3330078125,
				0.2890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1894161021,
			"isDeleted": false,
			"id": "M-Gr679wsLHSMLSlUjSJ5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 119.70833333333235,
			"y": -251.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 4,
			"seed": 426239966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					12,
					0
				],
				[
					20,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1435546875,
				0.244140625,
				0.263671875,
				0.24609375,
				0.1025390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1782847443,
			"isDeleted": false,
			"id": "Xpd1erW1qF16UJbfShCT_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 167.70833333333235,
			"y": -283.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 52,
			"seed": 1674181634,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					16
				],
				[
					0,
					28
				],
				[
					0,
					40
				],
				[
					0,
					48
				],
				[
					0,
					52
				],
				[
					0,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0390625,
				0.447265625,
				0.470703125,
				0.4609375,
				0.37890625,
				0.1513671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 49,
			"versionNonce": 1569211101,
			"isDeleted": false,
			"id": "q_h9gr20jWCk4c4W-Fb7u",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1468.2916666666677,
			"y": -415.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 80,
			"seed": 1024649986,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-16
				],
				[
					12,
					-16
				],
				[
					20,
					-20
				],
				[
					36,
					-8
				],
				[
					36,
					-4
				],
				[
					36,
					4
				],
				[
					36,
					12
				],
				[
					28,
					24
				],
				[
					20,
					36
				],
				[
					16,
					36
				],
				[
					12,
					40
				],
				[
					8,
					36
				],
				[
					12,
					32
				],
				[
					16,
					32
				],
				[
					24,
					32
				],
				[
					32,
					40
				],
				[
					36,
					48
				],
				[
					40,
					56
				],
				[
					44,
					60
				],
				[
					44,
					60
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0048828125,
				0.1552734375,
				0.2041015625,
				0.220703125,
				0.25390625,
				0.26171875,
				0.2744140625,
				0.326171875,
				0.3408203125,
				0.3505859375,
				0.3603515625,
				0.365234375,
				0.3671875,
				0.3681640625,
				0.3681640625,
				0.365234375,
				0.3662109375,
				0.38671875,
				0.4248046875,
				0.447265625,
				0.44921875,
				0.4296875,
				0.2822265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1345824115,
			"isDeleted": false,
			"id": "Y5pnNOkofJCZ7Z1gi8z9k",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1420.2916666666677,
			"y": -367.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 959987998,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0302734375,
				0.15625,
				0.2822265625,
				0.3740234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 748019517,
			"isDeleted": false,
			"id": "ojlOcDIWD_HZeluXzn3IX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1388.2916666666677,
			"y": -431.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 60,
			"seed": 492545794,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					8,
					32
				],
				[
					8,
					44
				],
				[
					8,
					52
				],
				[
					8,
					60
				],
				[
					8,
					60
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.248046875,
				0.34375,
				0.4296875,
				0.466796875,
				0.4794921875,
				0.4365234375,
				0.2939453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 41,
			"versionNonce": 2007531283,
			"isDeleted": false,
			"id": "doPWBZlG3btSa8vflPyFI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1372.2916666666677,
			"y": -407.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 48,
			"seed": 963184066,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					20
				],
				[
					4,
					32
				],
				[
					8,
					44
				],
				[
					16,
					48
				],
				[
					20,
					48
				],
				[
					32,
					40
				],
				[
					32,
					36
				],
				[
					36,
					24
				],
				[
					32,
					12
				],
				[
					20,
					4
				],
				[
					12,
					4
				],
				[
					4,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.03125,
				0.1884765625,
				0.314453125,
				0.3759765625,
				0.4130859375,
				0.4345703125,
				0.4423828125,
				0.470703125,
				0.48046875,
				0.4921875,
				0.4921875,
				0.4736328125,
				0.4033203125,
				0.25,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 342945693,
			"isDeleted": false,
			"id": "7OKLkAbXFCSIoIFNWizmY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1340.2916666666677,
			"y": -455.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 104,
			"seed": 1188622686,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					8,
					12
				],
				[
					16,
					32
				],
				[
					24,
					52
				],
				[
					28,
					68
				],
				[
					28,
					84
				],
				[
					28,
					92
				],
				[
					20,
					104
				],
				[
					20,
					104
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.001953125,
				0.2626953125,
				0.3330078125,
				0.416015625,
				0.4521484375,
				0.4599609375,
				0.41796875,
				0.3388671875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1527588019,
			"isDeleted": false,
			"id": "wO5tDUohOgcRH-0FMuQ6P",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1476.2916666666677,
			"y": -435.9010416666665,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 112,
			"seed": 1456237122,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					-8,
					32
				],
				[
					-8,
					52
				],
				[
					-4,
					72
				],
				[
					0,
					84
				],
				[
					12,
					100
				],
				[
					24,
					112
				],
				[
					24,
					112
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0263671875,
				0.1455078125,
				0.26171875,
				0.3232421875,
				0.3486328125,
				0.357421875,
				0.2958984375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 64,
			"versionNonce": 55243773,
			"isDeleted": false,
			"id": "hcydng-2Jwgfqn38aMA6R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1308.2916666666677,
			"y": -143.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 80,
			"height": 88,
			"seed": 733462786,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					-4
				],
				[
					-12,
					0
				],
				[
					-20,
					8
				],
				[
					-20,
					24
				],
				[
					-20,
					40
				],
				[
					-16,
					48
				],
				[
					-12,
					52
				],
				[
					-4,
					52
				],
				[
					8,
					44
				],
				[
					16,
					28
				],
				[
					20,
					12
				],
				[
					20,
					-4
				],
				[
					16,
					-20
				],
				[
					8,
					-28
				],
				[
					4,
					-32
				],
				[
					4,
					-36
				],
				[
					0,
					-28
				],
				[
					4,
					-12
				],
				[
					8,
					4
				],
				[
					16,
					16
				],
				[
					28,
					20
				],
				[
					40,
					24
				],
				[
					48,
					20
				],
				[
					56,
					12
				],
				[
					60,
					8
				],
				[
					60,
					-4
				],
				[
					56,
					-12
				],
				[
					48,
					-16
				],
				[
					36,
					-12
				],
				[
					28,
					0
				],
				[
					28,
					12
				],
				[
					28,
					28
				],
				[
					32,
					40
				],
				[
					40,
					44
				],
				[
					48,
					48
				],
				[
					56,
					48
				],
				[
					56,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.00390625,
				0.1279296875,
				0.205078125,
				0.2744140625,
				0.345703125,
				0.3837890625,
				0.4052734375,
				0.41015625,
				0.4111328125,
				0.41015625,
				0.41015625,
				0.412109375,
				0.4130859375,
				0.40625,
				0.3798828125,
				0.3681640625,
				0.3681640625,
				0.365234375,
				0.37890625,
				0.40234375,
				0.416015625,
				0.421875,
				0.4189453125,
				0.4189453125,
				0.4169921875,
				0.404296875,
				0.4013671875,
				0.3857421875,
				0.359375,
				0.3505859375,
				0.369140625,
				0.404296875,
				0.42578125,
				0.43359375,
				0.4306640625,
				0.4130859375,
				0.296875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 39,
			"versionNonce": 1644959315,
			"isDeleted": false,
			"id": "rOP0q_89JvI89f_jL7LLF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1192.2916666666677,
			"y": -183.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 92,
			"seed": 806677506,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					0
				],
				[
					-12,
					0
				],
				[
					-24,
					8
				],
				[
					-28,
					24
				],
				[
					-32,
					40
				],
				[
					-32,
					56
				],
				[
					-32,
					68
				],
				[
					-32,
					80
				],
				[
					-32,
					84
				],
				[
					-32,
					88
				],
				[
					-32,
					92
				],
				[
					-36,
					88
				],
				[
					-36,
					88
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1845703125,
				0.279296875,
				0.365234375,
				0.439453125,
				0.4853515625,
				0.49609375,
				0.5,
				0.4853515625,
				0.423828125,
				0.333984375,
				0.205078125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 623209565,
			"isDeleted": false,
			"id": "GwEv9TNfZMB59DCVIDaQ1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1236.2916666666677,
			"y": -135.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 32,
			"seed": 1338956510,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					12,
					4
				],
				[
					20,
					12
				],
				[
					24,
					20
				],
				[
					28,
					28
				],
				[
					28,
					32
				],
				[
					28,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.1015625,
				0.1982421875,
				0.2900390625,
				0.3359375,
				0.349609375,
				0.271484375,
				0.2109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 47,
			"versionNonce": 997970931,
			"isDeleted": false,
			"id": "JrToZMgyargprwcb86af_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1208.2916666666677,
			"y": -123.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 40,
			"seed": 194269214,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-12
				],
				[
					-4,
					-20
				],
				[
					-4,
					-24
				],
				[
					0,
					-20
				],
				[
					8,
					-12
				],
				[
					12,
					0
				],
				[
					20,
					8
				],
				[
					20,
					12
				],
				[
					24,
					16
				],
				[
					20,
					12
				],
				[
					20,
					0
				],
				[
					20,
					-12
				],
				[
					20,
					-16
				],
				[
					24,
					-20
				],
				[
					32,
					-12
				],
				[
					36,
					0
				],
				[
					40,
					4
				],
				[
					44,
					8
				],
				[
					48,
					8
				],
				[
					48,
					8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0146484375,
				0.052734375,
				0.1318359375,
				0.1923828125,
				0.2001953125,
				0.201171875,
				0.208984375,
				0.22265625,
				0.25390625,
				0.265625,
				0.3193359375,
				0.3671875,
				0.3515625,
				0.3310546875,
				0.3232421875,
				0.322265625,
				0.3291015625,
				0.333984375,
				0.330078125,
				0.2958984375,
				0.2431640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 61,
			"versionNonce": 701618365,
			"isDeleted": false,
			"id": "I-RSJococ5llhviqeMlWg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1156.2916666666677,
			"y": -131.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 44,
			"seed": 963773954,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					8
				],
				[
					12,
					12
				],
				[
					16,
					12
				],
				[
					24,
					12
				],
				[
					28,
					8
				],
				[
					32,
					0
				],
				[
					36,
					-4
				],
				[
					36,
					-12
				],
				[
					32,
					-16
				],
				[
					24,
					-12
				],
				[
					20,
					-4
				],
				[
					16,
					4
				],
				[
					20,
					16
				],
				[
					28,
					20
				],
				[
					40,
					20
				],
				[
					48,
					16
				],
				[
					56,
					12
				],
				[
					60,
					8
				],
				[
					60,
					0
				],
				[
					60,
					-4
				],
				[
					56,
					4
				],
				[
					56,
					12
				],
				[
					52,
					20
				],
				[
					52,
					24
				],
				[
					52,
					20
				],
				[
					52,
					12
				],
				[
					52,
					4
				],
				[
					56,
					0
				],
				[
					60,
					0
				],
				[
					68,
					8
				],
				[
					76,
					20
				],
				[
					80,
					24
				],
				[
					84,
					28
				],
				[
					84,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0107421875,
				0.1552734375,
				0.212890625,
				0.2421875,
				0.2548828125,
				0.2607421875,
				0.2626953125,
				0.2705078125,
				0.2802734375,
				0.3408203125,
				0.3857421875,
				0.44140625,
				0.46484375,
				0.47265625,
				0.4677734375,
				0.439453125,
				0.3427734375,
				0.279296875,
				0.21875,
				0.1845703125,
				0.19921875,
				0.2392578125,
				0.3955078125,
				0.4326171875,
				0.447265625,
				0.4599609375,
				0.48828125,
				0.4951171875,
				0.4951171875,
				0.4970703125,
				0.4990234375,
				0.5009765625,
				0.4111328125,
				0.3388671875,
				0.2001953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 65,
			"versionNonce": 2002967955,
			"isDeleted": false,
			"id": "oPZxJDLAStXDaU59Or5eZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1056.2916666666677,
			"y": -135.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 64,
			"seed": 1412507550,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					-4,
					-8
				],
				[
					-12,
					0
				],
				[
					-12,
					8
				],
				[
					-12,
					20
				],
				[
					-12,
					24
				],
				[
					-8,
					28
				],
				[
					-4,
					28
				],
				[
					8,
					20
				],
				[
					16,
					8
				],
				[
					16,
					-8
				],
				[
					12,
					-24
				],
				[
					8,
					-28
				],
				[
					8,
					-32
				],
				[
					4,
					-20
				],
				[
					8,
					-4
				],
				[
					12,
					12
				],
				[
					20,
					24
				],
				[
					28,
					28
				],
				[
					36,
					24
				],
				[
					40,
					20
				],
				[
					44,
					16
				],
				[
					44,
					12
				],
				[
					44,
					16
				],
				[
					48,
					24
				],
				[
					56,
					28
				],
				[
					60,
					32
				],
				[
					68,
					28
				],
				[
					72,
					20
				],
				[
					72,
					12
				],
				[
					68,
					0
				],
				[
					56,
					-4
				],
				[
					48,
					-8
				],
				[
					40,
					-8
				],
				[
					32,
					-4
				],
				[
					28,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0068359375,
				0.1025390625,
				0.181640625,
				0.28125,
				0.44921875,
				0.470703125,
				0.4951171875,
				0.5,
				0.5048828125,
				0.49609375,
				0.4921875,
				0.4892578125,
				0.4794921875,
				0.47265625,
				0.4814453125,
				0.4921875,
				0.5126953125,
				0.5341796875,
				0.5322265625,
				0.5234375,
				0.4873046875,
				0.453125,
				0.4306640625,
				0.4248046875,
				0.4375,
				0.4521484375,
				0.45703125,
				0.458984375,
				0.462890625,
				0.48828125,
				0.5302734375,
				0.56640625,
				0.5791015625,
				0.58203125,
				0.5654296875,
				0.474609375,
				0.2021484375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1257355549,
			"isDeleted": false,
			"id": "6qtlR0Fi2aNyQnHhcpevb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1152.2916666666677,
			"y": -155.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 0,
			"seed": 337359938,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.052734375,
				0.23828125,
				0.3837890625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1626846003,
			"isDeleted": false,
			"id": "UiH_rFjfymdugEgx7laQ7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -888.2916666666677,
			"y": -183.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 84,
			"seed": 27471262,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					16
				],
				[
					-4,
					36
				],
				[
					0,
					56
				],
				[
					4,
					72
				],
				[
					8,
					80
				],
				[
					12,
					84
				],
				[
					12,
					84
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2138671875,
				0.3896484375,
				0.47265625,
				0.505859375,
				0.4345703125,
				0.2978515625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 43,
			"versionNonce": 301370749,
			"isDeleted": false,
			"id": "76bH88bbaODzy29dcRWR2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -852.2916666666677,
			"y": -131.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 56,
			"seed": 681372382,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-8
				],
				[
					-8,
					-12
				],
				[
					-20,
					0
				],
				[
					-24,
					12
				],
				[
					-20,
					28
				],
				[
					-16,
					36
				],
				[
					-4,
					36
				],
				[
					0,
					32
				],
				[
					8,
					24
				],
				[
					12,
					12
				],
				[
					12,
					0
				],
				[
					12,
					4
				],
				[
					16,
					12
				],
				[
					20,
					24
				],
				[
					28,
					36
				],
				[
					36,
					44
				],
				[
					36,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.1513671875,
				0.2578125,
				0.447265625,
				0.48828125,
				0.509765625,
				0.513671875,
				0.5166015625,
				0.5166015625,
				0.515625,
				0.50390625,
				0.484375,
				0.4931640625,
				0.4921875,
				0.4697265625,
				0.3525390625,
				0.1611328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 53,
			"versionNonce": 413193427,
			"isDeleted": false,
			"id": "x0Wxf5jNSX8QOLrfxxsEu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -768.2916666666677,
			"y": -143.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 48,
			"seed": 1909999554,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					8
				],
				[
					4,
					12
				],
				[
					8,
					24
				],
				[
					16,
					40
				],
				[
					20,
					44
				],
				[
					20,
					48
				],
				[
					20,
					44
				],
				[
					28,
					32
				],
				[
					32,
					16
				],
				[
					36,
					8
				],
				[
					36,
					4
				],
				[
					40,
					8
				],
				[
					36,
					24
				],
				[
					40,
					36
				],
				[
					44,
					44
				],
				[
					48,
					44
				],
				[
					60,
					40
				],
				[
					64,
					32
				],
				[
					68,
					24
				],
				[
					68,
					16
				],
				[
					64,
					12
				],
				[
					64,
					16
				],
				[
					68,
					28
				],
				[
					72,
					36
				],
				[
					80,
					40
				],
				[
					84,
					44
				],
				[
					84,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3203125,
				0.3623046875,
				0.40625,
				0.4482421875,
				0.458984375,
				0.466796875,
				0.4716796875,
				0.4521484375,
				0.4013671875,
				0.375,
				0.359375,
				0.400390625,
				0.48046875,
				0.515625,
				0.5380859375,
				0.546875,
				0.5478515625,
				0.53125,
				0.4990234375,
				0.4765625,
				0.4677734375,
				0.4833984375,
				0.478515625,
				0.4404296875,
				0.330078125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 42,
			"versionNonce": 1579275741,
			"isDeleted": false,
			"id": "kRnlME0cOvu6DmFvtHXwe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -672.2916666666677,
			"y": -147.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 44,
			"seed": 748237022,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					16
				],
				[
					8,
					32
				],
				[
					8,
					40
				],
				[
					12,
					44
				],
				[
					12,
					40
				],
				[
					8,
					32
				],
				[
					12,
					20
				],
				[
					12,
					12
				],
				[
					16,
					12
				],
				[
					24,
					24
				],
				[
					32,
					36
				],
				[
					36,
					44
				],
				[
					40,
					44
				],
				[
					40,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.03125,
				0.30859375,
				0.34765625,
				0.3955078125,
				0.4501953125,
				0.46484375,
				0.4873046875,
				0.5107421875,
				0.5048828125,
				0.4912109375,
				0.4833984375,
				0.484375,
				0.48828125,
				0.4521484375,
				0.33203125,
				0.248046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 70,
			"versionNonce": 1844757107,
			"isDeleted": false,
			"id": "fnGCtV2_sZmKcypM64c9d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -616.2916666666677,
			"y": -131.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 88,
			"height": 80,
			"seed": 1087235870,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					-8
				],
				[
					-12,
					-8
				],
				[
					-16,
					0
				],
				[
					-20,
					8
				],
				[
					-20,
					24
				],
				[
					-12,
					28
				],
				[
					-8,
					32
				],
				[
					0,
					28
				],
				[
					4,
					20
				],
				[
					8,
					12
				],
				[
					12,
					8
				],
				[
					12,
					4
				],
				[
					8,
					4
				],
				[
					8,
					16
				],
				[
					12,
					28
				],
				[
					20,
					40
				],
				[
					28,
					40
				],
				[
					40,
					32
				],
				[
					44,
					28
				],
				[
					44,
					12
				],
				[
					44,
					-8
				],
				[
					36,
					-28
				],
				[
					36,
					-36
				],
				[
					36,
					-40
				],
				[
					36,
					-32
				],
				[
					36,
					-16
				],
				[
					40,
					4
				],
				[
					44,
					12
				],
				[
					44,
					24
				],
				[
					44,
					28
				],
				[
					44,
					24
				],
				[
					44,
					8
				],
				[
					52,
					-4
				],
				[
					56,
					-12
				],
				[
					64,
					-8
				],
				[
					68,
					0
				],
				[
					68,
					12
				],
				[
					68,
					20
				],
				[
					64,
					24
				],
				[
					60,
					28
				],
				[
					56,
					24
				],
				[
					56,
					20
				],
				[
					56,
					20
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.09375,
				0.1806640625,
				0.4287109375,
				0.4921875,
				0.5390625,
				0.591796875,
				0.6015625,
				0.5986328125,
				0.5927734375,
				0.576171875,
				0.5576171875,
				0.5576171875,
				0.5537109375,
				0.548828125,
				0.5400390625,
				0.51953125,
				0.4482421875,
				0.3271484375,
				0.2314453125,
				0.1806640625,
				0.1572265625,
				0.16796875,
				0.2294921875,
				0.3046875,
				0.359375,
				0.46484375,
				0.52734375,
				0.5693359375,
				0.5810546875,
				0.59375,
				0.5986328125,
				0.609375,
				0.5888671875,
				0.5732421875,
				0.56640625,
				0.5732421875,
				0.5810546875,
				0.591796875,
				0.5927734375,
				0.568359375,
				0.447265625,
				0.236328125,
				0.1494140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 48,
			"versionNonce": 713364029,
			"isDeleted": false,
			"id": "aJ0SuhUBxr1TD1wJf9NTT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -556.2916666666677,
			"y": -163.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 68,
			"seed": 523778270,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					12,
					4
				],
				[
					16,
					24
				],
				[
					24,
					36
				],
				[
					28,
					48
				],
				[
					32,
					52
				],
				[
					40,
					48
				],
				[
					48,
					36
				],
				[
					48,
					28
				],
				[
					48,
					20
				],
				[
					44,
					16
				],
				[
					40,
					20
				],
				[
					32,
					24
				],
				[
					32,
					40
				],
				[
					32,
					48
				],
				[
					40,
					60
				],
				[
					44,
					64
				],
				[
					52,
					64
				],
				[
					56,
					60
				],
				[
					60,
					56
				],
				[
					60,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.048828125,
				0.19140625,
				0.3837890625,
				0.4814453125,
				0.521484375,
				0.53125,
				0.53515625,
				0.5283203125,
				0.5224609375,
				0.517578125,
				0.517578125,
				0.517578125,
				0.5283203125,
				0.5380859375,
				0.556640625,
				0.5634765625,
				0.5712890625,
				0.560546875,
				0.5068359375,
				0.3876953125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 2042231827,
			"isDeleted": false,
			"id": "JHD1oo0ExXDXtEdEQEqRz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -632.2916666666677,
			"y": -151.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 0,
			"seed": 461347806,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0869140625,
				0.3671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 335659677,
			"isDeleted": false,
			"id": "sr7Jd9pt42e8mFAclPWE1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -360.29166666666765,
			"y": -179.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 64,
			"seed": 896155778,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-8
				],
				[
					16,
					0
				],
				[
					28,
					16
				],
				[
					36,
					28
				],
				[
					40,
					40
				],
				[
					40,
					48
				],
				[
					44,
					52
				],
				[
					44,
					56
				],
				[
					44,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1162109375,
				0.3154296875,
				0.3662109375,
				0.4482421875,
				0.4951171875,
				0.51953125,
				0.5244140625,
				0.521484375,
				0.4375,
				0.3359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 2011627955,
			"isDeleted": false,
			"id": "p0gbehgYVakwU5Y9iHlXr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -332.29166666666765,
			"y": -151.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 52,
			"seed": 330560030,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-8,
					-4
				],
				[
					-16,
					4
				],
				[
					-24,
					16
				],
				[
					-28,
					28
				],
				[
					-28,
					36
				],
				[
					-28,
					40
				],
				[
					-24,
					44
				],
				[
					-24,
					48
				],
				[
					-24,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.10546875,
				0.3056640625,
				0.4306640625,
				0.4921875,
				0.5205078125,
				0.51953125,
				0.4501953125,
				0.388671875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 524904189,
			"isDeleted": false,
			"id": "HFBUsCA6kqsENIf_quUSz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -312.29166666666765,
			"y": -195.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 44,
			"seed": 109790110,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					16
				],
				[
					0,
					24
				],
				[
					0,
					28
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.3271484375,
				0.384765625,
				0.44921875,
				0.4853515625,
				0.494140625,
				0.490234375,
				0.361328125,
				0.166015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1638028115,
			"isDeleted": false,
			"id": "M5RZdkBUED43z0oEJyOml",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -252.29166666666765,
			"y": -151.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 12,
			"seed": 591475038,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					12,
					-4
				],
				[
					28,
					-8
				],
				[
					36,
					-8
				],
				[
					44,
					-12
				],
				[
					44,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.220703125,
				0.4853515625,
				0.498046875,
				0.521484375,
				0.5390625,
				0.52734375,
				0.4306640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1054703453,
			"isDeleted": false,
			"id": "DjCMwQ6jJMgMpbzms5Kx7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -244.29166666666765,
			"y": -143.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 4,
			"seed": 1279301278,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					12,
					4
				],
				[
					16,
					4
				],
				[
					24,
					4
				],
				[
					28,
					4
				],
				[
					32,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.1142578125,
				0.3798828125,
				0.3974609375,
				0.416015625,
				0.419921875,
				0.3662109375,
				0.314453125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1195536627,
			"isDeleted": false,
			"id": "8mJdheiPiegjaH0LQh1ZW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -160.29166666666765,
			"y": -187.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 64,
			"seed": 1400014878,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					12,
					4
				],
				[
					20,
					12
				],
				[
					28,
					28
				],
				[
					36,
					40
				],
				[
					40,
					52
				],
				[
					40,
					56
				],
				[
					40,
					60
				],
				[
					40,
					60
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0322265625,
				0.07421875,
				0.2978515625,
				0.3974609375,
				0.4482421875,
				0.49609375,
				0.51953125,
				0.4931640625,
				0.4501953125,
				0.287109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 420449213,
			"isDeleted": false,
			"id": "sC0RndvgKP6f6DPQxlhQY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -120.29166666666765,
			"y": -155.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 56,
			"seed": 669079966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-8,
					-12
				],
				[
					-16,
					-8
				],
				[
					-24,
					0
				],
				[
					-36,
					12
				],
				[
					-40,
					28
				],
				[
					-44,
					36
				],
				[
					-44,
					44
				],
				[
					-44,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0341796875,
				0.2021484375,
				0.36328125,
				0.4560546875,
				0.5087890625,
				0.5244140625,
				0.5126953125,
				0.4306640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1783487123,
			"isDeleted": false,
			"id": "fyOQBCoPPlSZIMEWXLbvF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -96.29166666666765,
			"y": -195.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 84,
			"seed": 336612866,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					0,
					28
				],
				[
					-4,
					44
				],
				[
					-4,
					64
				],
				[
					-4,
					72
				],
				[
					-4,
					80
				],
				[
					-4,
					84
				],
				[
					-4,
					84
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2724609375,
				0.34375,
				0.4677734375,
				0.5302734375,
				0.5478515625,
				0.4990234375,
				0.3359375,
				0.1767578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 46,
			"versionNonce": 234949661,
			"isDeleted": false,
			"id": "tnh_skr7CUHSGXa36GOaJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -84.29166666666765,
			"y": -135.90104166666652,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76,
			"height": 68,
			"seed": 1023694942,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-16
				],
				[
					20,
					-28
				],
				[
					36,
					-32
				],
				[
					48,
					-28
				],
				[
					56,
					-20
				],
				[
					56,
					-8
				],
				[
					52,
					4
				],
				[
					40,
					16
				],
				[
					32,
					24
				],
				[
					28,
					28
				],
				[
					24,
					28
				],
				[
					28,
					28
				],
				[
					36,
					28
				],
				[
					52,
					32
				],
				[
					60,
					36
				],
				[
					68,
					36
				],
				[
					72,
					36
				],
				[
					76,
					36
				],
				[
					76,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.060546875,
				0.1259765625,
				0.2001953125,
				0.296875,
				0.365234375,
				0.4150390625,
				0.4482421875,
				0.482421875,
				0.49609375,
				0.50390625,
				0.5068359375,
				0.5263671875,
				0.5419921875,
				0.5498046875,
				0.5478515625,
				0.5478515625,
				0.5390625,
				0.498046875,
				0.4677734375,
				0.396484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 45,
			"versionNonce": 393941043,
			"isDeleted": false,
			"id": "Yf1moiOssBO-qGf79KD-h",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1464.2916666666677,
			"y": 116.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 64,
			"seed": 445020610,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359175,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-12
				],
				[
					12,
					-24
				],
				[
					24,
					-32
				],
				[
					28,
					-32
				],
				[
					36,
					-32
				],
				[
					44,
					-20
				],
				[
					44,
					0
				],
				[
					40,
					16
				],
				[
					32,
					24
				],
				[
					28,
					28
				],
				[
					24,
					28
				],
				[
					20,
					24
				],
				[
					20,
					20
				],
				[
					28,
					20
				],
				[
					32,
					24
				],
				[
					36,
					24
				],
				[
					44,
					28
				],
				[
					48,
					32
				],
				[
					48,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.115234375,
				0.2080078125,
				0.248046875,
				0.287109375,
				0.3125,
				0.3564453125,
				0.4130859375,
				0.4619140625,
				0.4873046875,
				0.5029296875,
				0.517578125,
				0.5224609375,
				0.5302734375,
				0.5400390625,
				0.5458984375,
				0.54296875,
				0.5244140625,
				0.3447265625,
				0.18359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 2107867261,
			"isDeleted": false,
			"id": "wnpJ1Tr6e6bKuPUaFtgFA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1396.2916666666677,
			"y": 152.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 1268406018,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.029296875,
				0.271484375,
				0.3505859375,
				0.3916015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1085313491,
			"isDeleted": false,
			"id": "AGDboLGL6tr5okh5iJWgu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1372.2916666666677,
			"y": 92.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 68,
			"seed": 939957982,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					4
				],
				[
					8,
					24
				],
				[
					8,
					40
				],
				[
					12,
					52
				],
				[
					16,
					64
				],
				[
					16,
					68
				],
				[
					16,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3564453125,
				0.416015625,
				0.5107421875,
				0.53125,
				0.5302734375,
				0.40234375,
				0.3154296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1303931101,
			"isDeleted": false,
			"id": "6D_x1eEX2Ry7Ull8WZwoO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1344.2916666666677,
			"y": 104.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 56,
			"seed": 74552350,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					4
				],
				[
					8,
					16
				],
				[
					12,
					32
				],
				[
					12,
					40
				],
				[
					16,
					44
				],
				[
					16,
					48
				],
				[
					16,
					52
				],
				[
					16,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.138671875,
				0.357421875,
				0.453125,
				0.486328125,
				0.4931640625,
				0.45703125,
				0.404296875,
				0.1435546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1459937139,
			"isDeleted": false,
			"id": "m9KWBO8vNztBpJJ-VY_H8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1308.2916666666677,
			"y": 72.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 96,
			"seed": 909806466,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					16,
					20
				],
				[
					24,
					44
				],
				[
					28,
					60
				],
				[
					28,
					76
				],
				[
					28,
					84
				],
				[
					28,
					92
				],
				[
					28,
					96
				],
				[
					28,
					96
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.2333984375,
				0.33203125,
				0.4072265625,
				0.419921875,
				0.4248046875,
				0.380859375,
				0.25390625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 802243901,
			"isDeleted": false,
			"id": "Q395MIhH3UerOeGiEO36L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1440.2916666666677,
			"y": 76.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 104,
			"seed": 511582942,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-12,
					0
				],
				[
					-20,
					12
				],
				[
					-24,
					28
				],
				[
					-28,
					48
				],
				[
					-24,
					68
				],
				[
					-20,
					84
				],
				[
					-16,
					92
				],
				[
					-8,
					104
				],
				[
					-8,
					104
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.056640625,
				0.1865234375,
				0.2578125,
				0.3095703125,
				0.349609375,
				0.3681640625,
				0.3671875,
				0.337890625,
				0.154296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 46,
			"versionNonce": 1690204435,
			"isDeleted": false,
			"id": "cUI1pitIFjH8BDUDgUWe0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1392.2916666666677,
			"y": 388.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 60,
			"seed": 531227742,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-12
				],
				[
					-4,
					-20
				],
				[
					8,
					-32
				],
				[
					16,
					-36
				],
				[
					20,
					-32
				],
				[
					28,
					-24
				],
				[
					28,
					-12
				],
				[
					28,
					0
				],
				[
					20,
					12
				],
				[
					12,
					20
				],
				[
					4,
					20
				],
				[
					0,
					24
				],
				[
					-4,
					20
				],
				[
					0,
					16
				],
				[
					4,
					16
				],
				[
					8,
					16
				],
				[
					12,
					20
				],
				[
					20,
					20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0478515625,
				0.21875,
				0.24609375,
				0.2841796875,
				0.3212890625,
				0.359375,
				0.390625,
				0.421875,
				0.435546875,
				0.4365234375,
				0.44140625,
				0.44140625,
				0.4423828125,
				0.4443359375,
				0.5009765625,
				0.5224609375,
				0.5283203125,
				0.5205078125,
				0.2529296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 659527069,
			"isDeleted": false,
			"id": "uUIMMhPjmuUIEvQxJr0dd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1356.2916666666677,
			"y": 400.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 4,
			"seed": 645410242,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.201171875,
				0.2822265625,
				0.2822265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1733549747,
			"isDeleted": false,
			"id": "WAFjWG9Svbn_TX7TmLCP5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1324.2916666666677,
			"y": 344.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 72,
			"seed": 108239902,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					20
				],
				[
					4,
					36
				],
				[
					8,
					48
				],
				[
					8,
					60
				],
				[
					12,
					68
				],
				[
					12,
					72
				],
				[
					12,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1962890625,
				0.41015625,
				0.48046875,
				0.5029296875,
				0.50390625,
				0.43359375,
				0.359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 44,
			"versionNonce": 1332009469,
			"isDeleted": false,
			"id": "h90uhQPr3FQPiEBdGNBc7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1296.2916666666677,
			"y": 380.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 56,
			"seed": 81283422,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-12
				],
				[
					8,
					-16
				],
				[
					12,
					-20
				],
				[
					24,
					-24
				],
				[
					32,
					-20
				],
				[
					36,
					-12
				],
				[
					36,
					-4
				],
				[
					32,
					12
				],
				[
					24,
					24
				],
				[
					20,
					28
				],
				[
					16,
					32
				],
				[
					20,
					32
				],
				[
					28,
					32
				],
				[
					36,
					32
				],
				[
					44,
					32
				],
				[
					48,
					32
				],
				[
					52,
					32
				],
				[
					52,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.080078125,
				0.1484375,
				0.1865234375,
				0.21484375,
				0.265625,
				0.294921875,
				0.3330078125,
				0.3564453125,
				0.3798828125,
				0.4052734375,
				0.416015625,
				0.4375,
				0.4501953125,
				0.451171875,
				0.4462890625,
				0.400390625,
				0.3515625,
				0.1376953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1768656979,
			"isDeleted": false,
			"id": "bbAV3n5Oru2Uj5zBpk_2-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1252.2916666666677,
			"y": 340.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 80,
			"seed": 2095573250,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					4
				],
				[
					16,
					12
				],
				[
					24,
					28
				],
				[
					28,
					48
				],
				[
					32,
					60
				],
				[
					28,
					64
				],
				[
					28,
					76
				],
				[
					28,
					80
				],
				[
					28,
					80
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.130859375,
				0.2587890625,
				0.3583984375,
				0.423828125,
				0.453125,
				0.416015625,
				0.396484375,
				0.23046875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1628607069,
			"isDeleted": false,
			"id": "62qThg_z_vLKoWfpgaa7z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1412.2916666666677,
			"y": 352.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 96,
			"seed": 2105130882,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					16
				],
				[
					-8,
					44
				],
				[
					-4,
					64
				],
				[
					0,
					76
				],
				[
					8,
					88
				],
				[
					16,
					96
				],
				[
					16,
					96
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.021484375,
				0.1748046875,
				0.271484375,
				0.30078125,
				0.3076171875,
				0.2685546875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 47,
			"versionNonce": 1557925363,
			"isDeleted": false,
			"id": "p0iULdzWFwCvp8g-bbyx-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1108.2916666666677,
			"y": 48.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 452,
			"seed": 216576670,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					12,
					8
				],
				[
					20,
					36
				],
				[
					20,
					84
				],
				[
					12,
					148
				],
				[
					12,
					160
				],
				[
					4,
					184
				],
				[
					0,
					196
				],
				[
					-4,
					200
				],
				[
					16,
					232
				],
				[
					20,
					260
				],
				[
					28,
					312
				],
				[
					32,
					360
				],
				[
					40,
					396
				],
				[
					44,
					416
				],
				[
					52,
					432
				],
				[
					60,
					440
				],
				[
					68,
					444
				],
				[
					76,
					448
				],
				[
					80,
					444
				],
				[
					80,
					444
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0732421875,
				0.2119140625,
				0.3046875,
				0.3818359375,
				0.4296875,
				0.4501953125,
				0.4482421875,
				0.4580078125,
				0.453125,
				0.4287109375,
				0.4140625,
				0.4287109375,
				0.4697265625,
				0.5,
				0.5283203125,
				0.5390625,
				0.515625,
				0.4619140625,
				0.359375,
				0.244140625,
				0.12890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 52,
			"versionNonce": 2032811709,
			"isDeleted": false,
			"id": "E16NK9kQG8qgPiqPJMx4n",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -880.2916666666677,
			"y": 44.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 96,
			"height": 128,
			"seed": 1153398174,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-12,
					12
				],
				[
					-28,
					28
				],
				[
					-40,
					40
				],
				[
					-48,
					52
				],
				[
					-56,
					56
				],
				[
					-56,
					60
				],
				[
					-52,
					64
				],
				[
					-48,
					60
				],
				[
					-36,
					60
				],
				[
					-28,
					60
				],
				[
					-20,
					60
				],
				[
					-20,
					68
				],
				[
					-28,
					76
				],
				[
					-44,
					92
				],
				[
					-56,
					100
				],
				[
					-68,
					112
				],
				[
					-68,
					116
				],
				[
					-72,
					120
				],
				[
					-68,
					124
				],
				[
					-52,
					128
				],
				[
					-28,
					124
				],
				[
					-4,
					124
				],
				[
					12,
					124
				],
				[
					20,
					120
				],
				[
					24,
					120
				],
				[
					24,
					120
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1669921875,
				0.2412109375,
				0.28515625,
				0.318359375,
				0.337890625,
				0.34765625,
				0.3505859375,
				0.3544921875,
				0.3544921875,
				0.35546875,
				0.357421875,
				0.369140625,
				0.3857421875,
				0.392578125,
				0.3916015625,
				0.3984375,
				0.419921875,
				0.4287109375,
				0.447265625,
				0.4736328125,
				0.4990234375,
				0.5205078125,
				0.5361328125,
				0.5302734375,
				0.45703125,
				0.3623046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 46,
			"versionNonce": 883677075,
			"isDeleted": false,
			"id": "74RlmY36X2o8QemLqnB5a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -944.2916666666677,
			"y": -11.901041666666515,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 32,
			"seed": 1396867010,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					4
				],
				[
					4,
					12
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					4,
					20
				],
				[
					4,
					12
				],
				[
					8,
					4
				],
				[
					12,
					0
				],
				[
					16,
					0
				],
				[
					24,
					12
				],
				[
					24,
					16
				],
				[
					28,
					24
				],
				[
					32,
					16
				],
				[
					36,
					4
				],
				[
					40,
					0
				],
				[
					48,
					8
				],
				[
					48,
					12
				],
				[
					56,
					24
				],
				[
					60,
					24
				],
				[
					60,
					24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0107421875,
				0.0615234375,
				0.3076171875,
				0.35546875,
				0.3857421875,
				0.41015625,
				0.4765625,
				0.4736328125,
				0.47265625,
				0.4716796875,
				0.47265625,
				0.4765625,
				0.4775390625,
				0.4853515625,
				0.5,
				0.4951171875,
				0.5146484375,
				0.5244140625,
				0.5263671875,
				0.2890625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 51,
			"versionNonce": 508387101,
			"isDeleted": false,
			"id": "l_l8KcRjHH67XmO80uXiy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -816.2916666666677,
			"y": 44.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 88,
			"seed": 357652674,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					20
				],
				[
					0,
					44
				],
				[
					4,
					64
				],
				[
					12,
					76
				],
				[
					16,
					88
				],
				[
					24,
					88
				],
				[
					32,
					80
				],
				[
					36,
					72
				],
				[
					40,
					56
				],
				[
					40,
					36
				],
				[
					40,
					20
				],
				[
					40,
					16
				],
				[
					36,
					20
				],
				[
					36,
					36
				],
				[
					40,
					60
				],
				[
					48,
					76
				],
				[
					56,
					88
				],
				[
					60,
					88
				],
				[
					68,
					88
				],
				[
					76,
					76
				],
				[
					80,
					56
				],
				[
					80,
					40
				],
				[
					80,
					24
				],
				[
					76,
					16
				],
				[
					76,
					12
				],
				[
					76,
					12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2099609375,
				0.3203125,
				0.3837890625,
				0.427734375,
				0.451171875,
				0.4609375,
				0.466796875,
				0.470703125,
				0.4716796875,
				0.4677734375,
				0.4560546875,
				0.44921875,
				0.44921875,
				0.458984375,
				0.4765625,
				0.49609375,
				0.5087890625,
				0.513671875,
				0.5185546875,
				0.5341796875,
				0.5537109375,
				0.5498046875,
				0.5322265625,
				0.521484375,
				0.4638671875,
				0.373046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1058106675,
			"isDeleted": false,
			"id": "ejTfd6rko-P5mChqlI2Bp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -712.2916666666677,
			"y": 104.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 20,
			"seed": 2006675422,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					8
				],
				[
					4,
					12
				],
				[
					4,
					16
				],
				[
					4,
					20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1005859375,
				0.1865234375,
				0.404296875,
				0.4931640625,
				0.333984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 116224893,
			"isDeleted": false,
			"id": "8W8Fw_wJtpaKOzDRuFn9U",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -716.2916666666677,
			"y": 76.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 574026754,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					-4,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.076171875,
				0.140625,
				0.2255859375,
				0.25,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 51,
			"versionNonce": 1064521427,
			"isDeleted": false,
			"id": "muHf-vbS9fIaWDT-JUHge",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -636.2916666666677,
			"y": 52.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76,
			"height": 12,
			"seed": 1094968066,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					-8,
					-12
				],
				[
					-12,
					-12
				],
				[
					-8,
					-12
				],
				[
					0,
					-12
				],
				[
					4,
					-8
				],
				[
					12,
					-8
				],
				[
					16,
					-8
				],
				[
					4,
					-8
				],
				[
					-16,
					-4
				],
				[
					-32,
					-4
				],
				[
					-40,
					-4
				],
				[
					-44,
					-4
				],
				[
					-40,
					-4
				],
				[
					-36,
					-4
				],
				[
					-20,
					-4
				],
				[
					-4,
					-8
				],
				[
					0,
					-8
				],
				[
					8,
					-8
				],
				[
					16,
					-12
				],
				[
					20,
					-12
				],
				[
					24,
					-12
				],
				[
					28,
					-12
				],
				[
					32,
					-12
				],
				[
					32,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1728515625,
				0.3134765625,
				0.3486328125,
				0.3896484375,
				0.4296875,
				0.46484375,
				0.46875,
				0.466796875,
				0.4580078125,
				0.4365234375,
				0.3759765625,
				0.3662109375,
				0.373046875,
				0.390625,
				0.3974609375,
				0.4140625,
				0.42578125,
				0.4521484375,
				0.470703125,
				0.4765625,
				0.4794921875,
				0.4853515625,
				0.486328125,
				0.4873046875,
				0.482421875,
				0.439453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 525073373,
			"isDeleted": false,
			"id": "fSeznmD1CcJ-ruN9dHacu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -660.2916666666677,
			"y": 52.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 72,
			"seed": 1556191646,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					16
				],
				[
					-4,
					32
				],
				[
					-4,
					44
				],
				[
					-4,
					52
				],
				[
					0,
					64
				],
				[
					0,
					68
				],
				[
					0,
					72
				],
				[
					0,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.09375,
				0.3056640625,
				0.4296875,
				0.4892578125,
				0.521484375,
				0.529296875,
				0.5283203125,
				0.41796875,
				0.224609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1214774387,
			"isDeleted": false,
			"id": "GKYuTkIeawIFiKRPiNRK1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -676.2916666666677,
			"y": 96.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 8,
			"seed": 1310018334,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					8,
					-4
				],
				[
					16,
					-4
				],
				[
					24,
					-8
				],
				[
					36,
					-8
				],
				[
					40,
					-8
				],
				[
					44,
					-8
				],
				[
					44,
					-8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.30078125,
				0.3818359375,
				0.412109375,
				0.423828125,
				0.3837890625,
				0.2421875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1333426237,
			"isDeleted": false,
			"id": "HfrwoY5U7w20INOGvxiDI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -620.2916666666677,
			"y": 92.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 32,
			"seed": 1183619166,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					8
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					8,
					32
				],
				[
					8,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.1123046875,
				0.1884765625,
				0.34375,
				0.384765625,
				0.3662109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1437988371,
			"isDeleted": false,
			"id": "kd6Ok1_ZQzoNwUYzB5kAB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -612.2916666666677,
			"y": 96.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 28,
			"seed": 447117662,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-12
				],
				[
					-4,
					-20
				],
				[
					-4,
					-24
				],
				[
					-4,
					-28
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1474609375,
				0.298828125,
				0.34375,
				0.3447265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 22702237,
			"isDeleted": false,
			"id": "BrRwGxHPOcQyuKRM5F7xQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -952.2916666666677,
			"y": 228.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 36,
			"seed": 910678622,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					36
				],
				[
					4,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0390625,
				0.2978515625,
				0.3544921875,
				0.3740234375,
				0.3056640625,
				0.1416015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 643021747,
			"isDeleted": false,
			"id": "GdXct_XoQ1KCmM_TUNETR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -956.2916666666677,
			"y": 228.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 1504754526,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-8
				],
				[
					-4,
					-12
				],
				[
					0,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0107421875,
				0.1298828125,
				0.2158203125,
				0.2451171875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1721584893,
			"isDeleted": false,
			"id": "kENBFQfJSw4uY9z33ViXJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -920.2916666666677,
			"y": 228.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 4,
			"seed": 819349698,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8,
					-4
				],
				[
					16,
					-4
				],
				[
					24,
					-4
				],
				[
					28,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.2451171875,
				0.2802734375,
				0.28515625,
				0.1728515625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1449643347,
			"isDeleted": false,
			"id": "vbXtjiF3JVb1ZOfVmsaHi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -916.2916666666677,
			"y": 248.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 8,
			"seed": 2050152386,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359176,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					4
				],
				[
					8,
					0
				],
				[
					20,
					0
				],
				[
					28,
					-4
				],
				[
					32,
					-4
				],
				[
					32,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.142578125,
				0.3095703125,
				0.3603515625,
				0.359375,
				0.26171875,
				0.185546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 2126816605,
			"isDeleted": false,
			"id": "S5Ed21MNWX-82dSZb7R0g",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -872.2916666666677,
			"y": 224.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 40,
			"seed": 353918558,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.4990234375,
				0.4423828125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 961063667,
			"isDeleted": false,
			"id": "Yo73rmYV8reboT8x9ZJhB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -536.2916666666677,
			"y": 96.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 56,
			"seed": 524912130,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					4,
					28
				],
				[
					4,
					36
				],
				[
					4,
					48
				],
				[
					4,
					52
				],
				[
					4,
					56
				],
				[
					4,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0107421875,
				0.1865234375,
				0.3115234375,
				0.423828125,
				0.44140625,
				0.4560546875,
				0.4111328125,
				0.3095703125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1562505661,
			"isDeleted": false,
			"id": "xEx5EKbtzG0EbeBT3jOov",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -564.2916666666677,
			"y": 136.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 12,
			"seed": 1338737858,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					12,
					-4
				],
				[
					24,
					-8
				],
				[
					36,
					-8
				],
				[
					44,
					-8
				],
				[
					52,
					-12
				],
				[
					56,
					-12
				],
				[
					60,
					-12
				],
				[
					60,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.001953125,
				0.224609375,
				0.2734375,
				0.3564453125,
				0.427734375,
				0.462890625,
				0.4736328125,
				0.4814453125,
				0.36328125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 52,
			"versionNonce": 1937560723,
			"isDeleted": false,
			"id": "l6qWJrftCSg09jBcI2pQy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -376.29166666666765,
			"y": 68.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 92,
			"height": 124,
			"seed": 1701153602,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-8,
					12
				],
				[
					-24,
					24
				],
				[
					-40,
					32
				],
				[
					-52,
					40
				],
				[
					-56,
					44
				],
				[
					-60,
					48
				],
				[
					-64,
					52
				],
				[
					-56,
					56
				],
				[
					-48,
					56
				],
				[
					-32,
					56
				],
				[
					-24,
					56
				],
				[
					-12,
					60
				],
				[
					-12,
					64
				],
				[
					-20,
					72
				],
				[
					-36,
					80
				],
				[
					-52,
					92
				],
				[
					-64,
					104
				],
				[
					-72,
					108
				],
				[
					-72,
					112
				],
				[
					-68,
					116
				],
				[
					-56,
					120
				],
				[
					-36,
					120
				],
				[
					-16,
					120
				],
				[
					8,
					124
				],
				[
					16,
					124
				],
				[
					20,
					124
				],
				[
					20,
					124
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.234375,
				0.287109375,
				0.33203125,
				0.3583984375,
				0.3720703125,
				0.376953125,
				0.380859375,
				0.3837890625,
				0.392578125,
				0.3955078125,
				0.41015625,
				0.4169921875,
				0.4306640625,
				0.4287109375,
				0.4267578125,
				0.4248046875,
				0.421875,
				0.4189453125,
				0.4248046875,
				0.4326171875,
				0.455078125,
				0.46875,
				0.4765625,
				0.49609375,
				0.5009765625,
				0.455078125,
				0.29296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 40,
			"versionNonce": 785822237,
			"isDeleted": false,
			"id": "Lw79ANV71mmgHxR5WNSla",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -436.29166666666765,
			"y": 16.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 44,
			"seed": 1789790082,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					0,
					24
				],
				[
					0,
					32
				],
				[
					0,
					40
				],
				[
					0,
					44
				],
				[
					0,
					40
				],
				[
					4,
					24
				],
				[
					8,
					12
				],
				[
					12,
					8
				],
				[
					16,
					8
				],
				[
					24,
					12
				],
				[
					28,
					24
				],
				[
					32,
					28
				],
				[
					36,
					36
				],
				[
					40,
					44
				],
				[
					40,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.275390625,
				0.33203125,
				0.3701171875,
				0.3935546875,
				0.408203125,
				0.4599609375,
				0.458984375,
				0.4599609375,
				0.466796875,
				0.4697265625,
				0.4775390625,
				0.4814453125,
				0.4794921875,
				0.4296875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 1421527603,
			"isDeleted": false,
			"id": "sXE8DVZA2i5kHSP-Kch8C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -460.29166666666765,
			"y": 236.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 72,
			"seed": 309912898,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					0
				],
				[
					8,
					12
				],
				[
					8,
					28
				],
				[
					8,
					40
				],
				[
					4,
					52
				],
				[
					0,
					60
				],
				[
					-4,
					64
				],
				[
					-12,
					68
				],
				[
					-16,
					64
				],
				[
					-24,
					60
				],
				[
					-24,
					52
				],
				[
					-24,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1328125,
				0.2822265625,
				0.390625,
				0.451171875,
				0.5068359375,
				0.55078125,
				0.572265625,
				0.5791015625,
				0.546875,
				0.419921875,
				0.2265625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 13919869,
			"isDeleted": false,
			"id": "C-4zQcSk9nQP-xAnhzqeT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -472.29166666666765,
			"y": 228.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 1583590814,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-8
				],
				[
					4,
					-12
				],
				[
					8,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0439453125,
				0.1904296875,
				0.349609375,
				0.3984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1911098323,
			"isDeleted": false,
			"id": "0VnjpTtbG8aQd-JF39W0i",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -428.29166666666765,
			"y": 252.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 4,
			"seed": 1045885570,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					20,
					0
				],
				[
					28,
					-4
				],
				[
					32,
					-4
				],
				[
					32,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.029296875,
				0.46875,
				0.5009765625,
				0.4736328125,
				0.32421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1172082397,
			"isDeleted": false,
			"id": "P0Wz0maOfo-0bjlwQQUk6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -420.29166666666765,
			"y": 264.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 4,
			"seed": 2117782366,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					12,
					4
				],
				[
					24,
					0
				],
				[
					32,
					0
				],
				[
					36,
					0
				],
				[
					36,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0234375,
				0.3623046875,
				0.3779296875,
				0.3603515625,
				0.2705078125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 2132679027,
			"isDeleted": false,
			"id": "i9x6ntrS7sD1AYNJ7XLIO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -368.29166666666765,
			"y": 232.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 52,
			"seed": 1814244446,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					4,
					24
				],
				[
					4,
					36
				],
				[
					8,
					44
				],
				[
					8,
					48
				],
				[
					8,
					52
				],
				[
					8,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.4892578125,
				0.51953125,
				0.5322265625,
				0.53125,
				0.5107421875,
				0.427734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 478194493,
			"isDeleted": false,
			"id": "L-uAEXylYkaumhgAQJ26L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -296.29166666666765,
			"y": 108.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 84,
			"seed": 104169346,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-8
				],
				[
					4,
					-12
				],
				[
					20,
					0
				],
				[
					32,
					20
				],
				[
					40,
					36
				],
				[
					48,
					52
				],
				[
					48,
					64
				],
				[
					52,
					68
				],
				[
					52,
					72
				],
				[
					52,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.021484375,
				0.146484375,
				0.236328125,
				0.3076171875,
				0.408203125,
				0.501953125,
				0.5341796875,
				0.54296875,
				0.544921875,
				0.5478515625,
				0.53515625,
				0.4248046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1772122899,
			"isDeleted": false,
			"id": "Lf0_882TJRfSSOXhSRpoJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -260.29166666666765,
			"y": 152.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 60,
			"seed": 134899138,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					-4
				],
				[
					-12,
					8
				],
				[
					-16,
					24
				],
				[
					-20,
					36
				],
				[
					-24,
					40
				],
				[
					-24,
					52
				],
				[
					-20,
					56
				],
				[
					-20,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.021484375,
				0.2021484375,
				0.32421875,
				0.4560546875,
				0.5126953125,
				0.541015625,
				0.546875,
				0.4765625,
				0.251953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 1428306845,
			"isDeleted": false,
			"id": "BmmunwlNKMzKiaKLpdabs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -208.29166666666765,
			"y": 152.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 80,
			"seed": 582349982,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					16
				],
				[
					0,
					40
				],
				[
					-4,
					56
				],
				[
					-8,
					68
				],
				[
					-16,
					76
				],
				[
					-20,
					80
				],
				[
					-24,
					80
				],
				[
					-28,
					76
				],
				[
					-32,
					68
				],
				[
					-36,
					60
				],
				[
					-36,
					60
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.4453125,
				0.525390625,
				0.642578125,
				0.7109375,
				0.748046875,
				0.76171875,
				0.734375,
				0.6962890625,
				0.53515625,
				0.33203125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 837195955,
			"isDeleted": false,
			"id": "HM7l3C5mNvu8s_azp2zcn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -224.29166666666765,
			"y": 148.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 1781723742,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-8
				],
				[
					8,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.044921875,
				0.1806640625,
				0.380859375,
				0.4306640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 938655741,
			"isDeleted": false,
			"id": "nkik7tBNYXAAXGcrJ8Vt6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -244.29166666666765,
			"y": 52.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 44,
			"seed": 749052354,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					12
				],
				[
					8,
					24
				],
				[
					8,
					36
				],
				[
					12,
					44
				],
				[
					12,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.009765625,
				0.2763671875,
				0.4384765625,
				0.48828125,
				0.51953125,
				0.3037109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 50,
			"versionNonce": 93784659,
			"isDeleted": false,
			"id": "8WiN8KPZviSA-m4V7TNgs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -92.29166666666765,
			"y": 72.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 136,
			"seed": 1527623874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					4
				],
				[
					-20,
					16
				],
				[
					-44,
					40
				],
				[
					-48,
					44
				],
				[
					-40,
					48
				],
				[
					-36,
					48
				],
				[
					-20,
					48
				],
				[
					-8,
					48
				],
				[
					-4,
					48
				],
				[
					0,
					44
				],
				[
					0,
					48
				],
				[
					-8,
					60
				],
				[
					-28,
					76
				],
				[
					-44,
					92
				],
				[
					-56,
					108
				],
				[
					-60,
					120
				],
				[
					-60,
					128
				],
				[
					-52,
					136
				],
				[
					-36,
					136
				],
				[
					-20,
					136
				],
				[
					0,
					136
				],
				[
					8,
					136
				],
				[
					16,
					136
				],
				[
					24,
					136
				],
				[
					24,
					132
				],
				[
					24,
					132
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0185546875,
				0.23828125,
				0.2734375,
				0.32421875,
				0.3271484375,
				0.3427734375,
				0.34375,
				0.345703125,
				0.3466796875,
				0.3466796875,
				0.349609375,
				0.361328125,
				0.3701171875,
				0.37109375,
				0.3896484375,
				0.4150390625,
				0.4384765625,
				0.458984375,
				0.474609375,
				0.4794921875,
				0.484375,
				0.5009765625,
				0.50390625,
				0.447265625,
				0.294921875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 51,
			"versionNonce": 183744605,
			"isDeleted": false,
			"id": "ioUln1tUv7vl-0L15rx1v",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.29166666666765,
			"y": 24.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 40,
			"seed": 1046074690,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					12
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					32
				],
				[
					4,
					16
				],
				[
					8,
					8
				],
				[
					12,
					4
				],
				[
					20,
					0
				],
				[
					24,
					8
				],
				[
					28,
					20
				],
				[
					32,
					28
				],
				[
					32,
					32
				],
				[
					36,
					28
				],
				[
					36,
					24
				],
				[
					40,
					16
				],
				[
					40,
					8
				],
				[
					44,
					4
				],
				[
					48,
					4
				],
				[
					52,
					12
				],
				[
					56,
					20
				],
				[
					60,
					24
				],
				[
					64,
					32
				],
				[
					64,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.236328125,
				0.2685546875,
				0.298828125,
				0.357421875,
				0.3759765625,
				0.40625,
				0.4423828125,
				0.4541015625,
				0.4423828125,
				0.4365234375,
				0.435546875,
				0.4375,
				0.4423828125,
				0.451171875,
				0.4521484375,
				0.458984375,
				0.474609375,
				0.4697265625,
				0.462890625,
				0.466796875,
				0.4677734375,
				0.478515625,
				0.4931640625,
				0.4892578125,
				0.4765625,
				0.357421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 428361715,
			"isDeleted": false,
			"id": "TWFJVWyXPC2YkWoMuM2GU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.29166666666765,
			"y": 268.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 32,
			"seed": 709155678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					4,
					32
				],
				[
					4,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.3544921875,
				0.4130859375,
				0.4384765625,
				0.41796875,
				0.359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1475781821,
			"isDeleted": false,
			"id": "HfbkpR0n7bS-GebtGLNsV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.29166666666765,
			"y": 248.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 2057649246,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0146484375,
				0.1533203125,
				0.189453125,
				0.216796875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1136710035,
			"isDeleted": false,
			"id": "n8ZcqV3s8vu_nAmufF8C6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -104.29166666666765,
			"y": 260.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 4,
			"seed": 2068651358,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					12,
					0
				],
				[
					16,
					-4
				],
				[
					24,
					-4
				],
				[
					28,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.248046875,
				0.294921875,
				0.302734375,
				0.2490234375,
				0.1171875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1922893085,
			"isDeleted": false,
			"id": "1j7prS8cmDV5lFxzmZgbI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -100.29166666666765,
			"y": 272.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 8,
			"seed": 1717018242,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					8,
					4
				],
				[
					16,
					0
				],
				[
					24,
					0
				],
				[
					28,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.00390625,
				0.1259765625,
				0.3056640625,
				0.3369140625,
				0.3447265625,
				0.2958984375,
				0.119140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1433872179,
			"isDeleted": false,
			"id": "WjZqEFcnfcs0Q6JkhcGJf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -52.29166666666765,
			"y": 236.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 48,
			"seed": 1081756994,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					4,
					8
				],
				[
					4,
					16
				],
				[
					4,
					28
				],
				[
					8,
					32
				],
				[
					8,
					40
				],
				[
					8,
					44
				],
				[
					8,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.2119140625,
				0.373046875,
				0.4541015625,
				0.4794921875,
				0.4990234375,
				0.4853515625,
				0.36328125,
				0.234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 49,
			"versionNonce": 1045977469,
			"isDeleted": false,
			"id": "tSrQg6F8OFwyrMEScARIr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -12.291666666667652,
			"y": 104.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 96,
			"seed": 938997022,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					8
				],
				[
					-4,
					28
				],
				[
					-4,
					48
				],
				[
					-8,
					64
				],
				[
					-8,
					76
				],
				[
					-8,
					84
				],
				[
					-8,
					88
				],
				[
					-8,
					92
				],
				[
					0,
					80
				],
				[
					8,
					64
				],
				[
					16,
					48
				],
				[
					28,
					32
				],
				[
					36,
					20
				],
				[
					44,
					12
				],
				[
					36,
					20
				],
				[
					28,
					36
				],
				[
					20,
					52
				],
				[
					20,
					64
				],
				[
					20,
					72
				],
				[
					24,
					84
				],
				[
					32,
					88
				],
				[
					36,
					92
				],
				[
					40,
					96
				],
				[
					48,
					92
				],
				[
					48,
					92
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1796875,
				0.2958984375,
				0.359375,
				0.3828125,
				0.419921875,
				0.4443359375,
				0.4619140625,
				0.5048828125,
				0.5400390625,
				0.5400390625,
				0.537109375,
				0.5302734375,
				0.478515625,
				0.361328125,
				0.20703125,
				0.3251953125,
				0.412109375,
				0.466796875,
				0.501953125,
				0.5380859375,
				0.5458984375,
				0.5244140625,
				0.501953125,
				0.2705078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 890357971,
			"isDeleted": false,
			"id": "FfV_WwfFTmNYvK9yFsFT0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 59.70833333333235,
			"y": 124.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 100,
			"seed": 1678063746,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					0,
					24
				],
				[
					0,
					44
				],
				[
					4,
					64
				],
				[
					0,
					72
				],
				[
					-4,
					88
				],
				[
					-8,
					96
				],
				[
					-16,
					100
				],
				[
					-24,
					100
				],
				[
					-28,
					92
				],
				[
					-32,
					84
				],
				[
					-32,
					84
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.04296875,
				0.3681640625,
				0.439453125,
				0.5068359375,
				0.5830078125,
				0.6630859375,
				0.7060546875,
				0.728515625,
				0.7373046875,
				0.6845703125,
				0.5234375,
				0.298828125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 879370717,
			"isDeleted": false,
			"id": "HaYtAwzNRM2PMX3Z9LcG6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 43.70833333333235,
			"y": 128.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 12,
			"seed": 1191544414,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					8,
					-12
				],
				[
					12,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0439453125,
				0.22265625,
				0.333984375,
				0.361328125,
				0.3408203125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 942093939,
			"isDeleted": false,
			"id": "bAdnGP3un_wt8pJomIFhg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 95.70833333333235,
			"y": 152.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 44,
			"seed": 1399506306,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359177,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					0,
					24
				],
				[
					-4,
					36
				],
				[
					0,
					40
				],
				[
					0,
					44
				],
				[
					0,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0419921875,
				0.5634765625,
				0.595703125,
				0.5703125,
				0.435546875,
				0.2939453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 702799421,
			"isDeleted": false,
			"id": "FPGdh4DFlqYpJRjBuDnNb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 95.70833333333235,
			"y": 140.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 24,
			"seed": 792917122,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-12
				],
				[
					-4,
					-16
				],
				[
					-4,
					-24
				],
				[
					-4,
					-20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1435546875,
				0.2587890625,
				0.365234375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1031663635,
			"isDeleted": false,
			"id": "2PTz1Vrtoxpe_erCSOPry",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 143.70833333333235,
			"y": 144.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 4,
			"seed": 1913365378,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					12,
					-4
				],
				[
					24,
					-4
				],
				[
					32,
					-4
				],
				[
					32,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.404296875,
				0.4306640625,
				0.4228515625,
				0.3017578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1437011613,
			"isDeleted": false,
			"id": "u4oLAYoQY5XoY_U4L_rBl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 151.70833333333235,
			"y": 156.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 8,
			"seed": 519965278,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-8,
					4
				],
				[
					-4,
					8
				],
				[
					0,
					8
				],
				[
					8,
					8
				],
				[
					16,
					8
				],
				[
					24,
					8
				],
				[
					32,
					4
				],
				[
					32,
					4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.169921875,
				0.2890625,
				0.369140625,
				0.4091796875,
				0.4267578125,
				0.412109375,
				0.310546875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 55,
			"versionNonce": 118257075,
			"isDeleted": false,
			"id": "R4KMdYMlPLLfNLeAtcTSz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 291.70833333333235,
			"y": 76.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76,
			"height": 144,
			"seed": 1390870850,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					0,
					4
				],
				[
					-4,
					4
				],
				[
					-16,
					12
				],
				[
					-32,
					24
				],
				[
					-48,
					36
				],
				[
					-60,
					48
				],
				[
					-68,
					56
				],
				[
					-72,
					60
				],
				[
					-72,
					64
				],
				[
					-68,
					64
				],
				[
					-56,
					64
				],
				[
					-40,
					64
				],
				[
					-16,
					64
				],
				[
					-8,
					64
				],
				[
					0,
					68
				],
				[
					-4,
					72
				],
				[
					-12,
					84
				],
				[
					-32,
					96
				],
				[
					-56,
					116
				],
				[
					-64,
					124
				],
				[
					-72,
					132
				],
				[
					-72,
					140
				],
				[
					-64,
					140
				],
				[
					-52,
					144
				],
				[
					-32,
					144
				],
				[
					-12,
					140
				],
				[
					-4,
					140
				],
				[
					0,
					136
				],
				[
					0,
					132
				],
				[
					0,
					132
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.13671875,
				0.2626953125,
				0.2861328125,
				0.3271484375,
				0.3681640625,
				0.404296875,
				0.4296875,
				0.44140625,
				0.4453125,
				0.4482421875,
				0.4501953125,
				0.4501953125,
				0.4501953125,
				0.451171875,
				0.451171875,
				0.453125,
				0.4423828125,
				0.4375,
				0.4384765625,
				0.458984375,
				0.4638671875,
				0.466796875,
				0.478515625,
				0.48046875,
				0.4814453125,
				0.482421875,
				0.4677734375,
				0.412109375,
				0.291015625,
				0.1962890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 48,
			"versionNonce": 375730941,
			"isDeleted": false,
			"id": "uE1Ig0wnh0EyOc4LG6S_k",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 203.70833333333235,
			"y": 56.098958333333485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 36,
			"seed": 1127460830,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					16
				],
				[
					0,
					24
				],
				[
					0,
					28
				],
				[
					0,
					32
				],
				[
					0,
					24
				],
				[
					4,
					16
				],
				[
					8,
					4
				],
				[
					12,
					0
				],
				[
					16,
					0
				],
				[
					20,
					4
				],
				[
					20,
					12
				],
				[
					24,
					20
				],
				[
					24,
					24
				],
				[
					28,
					24
				],
				[
					28,
					16
				],
				[
					36,
					4
				],
				[
					44,
					-4
				],
				[
					52,
					0
				],
				[
					60,
					8
				],
				[
					64,
					20
				],
				[
					64,
					28
				],
				[
					64,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.244140625,
				0.279296875,
				0.330078125,
				0.361328125,
				0.3837890625,
				0.412109375,
				0.44921875,
				0.4375,
				0.419921875,
				0.4150390625,
				0.4150390625,
				0.4189453125,
				0.4287109375,
				0.451171875,
				0.458984375,
				0.5,
				0.5,
				0.4931640625,
				0.486328125,
				0.4873046875,
				0.482421875,
				0.380859375,
				0.1533203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 50,
			"versionNonce": 1408845651,
			"isDeleted": false,
			"id": "_BYYVvTlJh-Ym1r9eUU-p",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 307.70833333333235,
			"y": 104.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 80,
			"height": 68,
			"seed": 1346799390,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					16
				],
				[
					0,
					36
				],
				[
					4,
					52
				],
				[
					12,
					56
				],
				[
					20,
					56
				],
				[
					32,
					52
				],
				[
					40,
					44
				],
				[
					44,
					36
				],
				[
					44,
					8
				],
				[
					44,
					-4
				],
				[
					44,
					-12
				],
				[
					40,
					-4
				],
				[
					36,
					8
				],
				[
					40,
					24
				],
				[
					44,
					36
				],
				[
					52,
					44
				],
				[
					60,
					48
				],
				[
					68,
					44
				],
				[
					72,
					32
				],
				[
					76,
					20
				],
				[
					76,
					8
				],
				[
					76,
					0
				],
				[
					76,
					-4
				],
				[
					76,
					0
				],
				[
					76,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2646484375,
				0.322265625,
				0.3662109375,
				0.3857421875,
				0.3955078125,
				0.3916015625,
				0.3984375,
				0.4111328125,
				0.42578125,
				0.4228515625,
				0.427734375,
				0.439453125,
				0.455078125,
				0.462890625,
				0.462890625,
				0.4560546875,
				0.4521484375,
				0.4599609375,
				0.4775390625,
				0.4921875,
				0.498046875,
				0.4921875,
				0.4501953125,
				0.3740234375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 2023738205,
			"isDeleted": false,
			"id": "9enSD1V0zyZc3r9FJw-PH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 395.70833333333235,
			"y": 144.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 24,
			"seed": 561060510,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					0,
					16
				],
				[
					0,
					20
				],
				[
					0,
					24
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.005859375,
				0.24609375,
				0.3359375,
				0.3681640625,
				0.3896484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 983229683,
			"isDeleted": false,
			"id": "MCOauGfOBBb0_BffRLPcj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 395.70833333333235,
			"y": 116.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 16,
			"seed": 1259854750,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					0,
					-12
				],
				[
					0,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.12109375,
				0.2080078125,
				0.2939453125,
				0.287109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 2091407293,
			"isDeleted": false,
			"id": "XijBYU8SBJ2bToVN-OY1w",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 463.70833333333235,
			"y": 84.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 92,
			"seed": 517348510,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					-8
				],
				[
					-8,
					-12
				],
				[
					-12,
					-8
				],
				[
					-16,
					0
				],
				[
					-20,
					12
				],
				[
					-24,
					32
				],
				[
					-24,
					56
				],
				[
					-24,
					68
				],
				[
					-24,
					76
				],
				[
					-24,
					80
				],
				[
					-24,
					80
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.00390625,
				0.2197265625,
				0.3369140625,
				0.421875,
				0.466796875,
				0.5048828125,
				0.5244140625,
				0.5380859375,
				0.5458984375,
				0.517578125,
				0.4248046875,
				0.34765625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1115147923,
			"isDeleted": false,
			"id": "MteVoJU5NcC7iNCgU-gSA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 419.70833333333235,
			"y": 148.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 36,
			"seed": 2073041502,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					8,
					-8
				],
				[
					16,
					-8
				],
				[
					24,
					-8
				],
				[
					32,
					-4
				],
				[
					36,
					4
				],
				[
					40,
					16
				],
				[
					40,
					24
				],
				[
					40,
					28
				],
				[
					40,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.142578125,
				0.3837890625,
				0.4228515625,
				0.4404296875,
				0.44921875,
				0.4453125,
				0.40234375,
				0.3232421875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 480270365,
			"isDeleted": false,
			"id": "CFJ_dQuLRR2uhOqutcZHd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 471.70833333333235,
			"y": 132.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 1606171614,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-8
				],
				[
					0,
					-12
				],
				[
					-4,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.037109375,
				0.1953125,
				0.2509765625,
				0.2607421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1044808755,
			"isDeleted": false,
			"id": "JTjR6MN6wWvJrok0dlIuv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 175.70833333333235,
			"y": 272.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 40,
			"seed": 1894531138,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					8
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					40
				],
				[
					8,
					40
				],
				[
					8,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.2626953125,
				0.306640625,
				0.3505859375,
				0.376953125,
				0.37890625,
				0.3115234375,
				0.2060546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 309939325,
			"isDeleted": false,
			"id": "4CAQb5Ar4DaCaTmjNuV8G",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 183.70833333333235,
			"y": 264.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 154261250,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					-4,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.1533203125,
				0.2216796875,
				0.26953125,
				0.30859375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1710065107,
			"isDeleted": false,
			"id": "8Wivr9u8avC0flkhqhHAC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 207.70833333333235,
			"y": 268.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 0,
			"seed": 506807810,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					12,
					0
				],
				[
					28,
					0
				],
				[
					36,
					0
				],
				[
					40,
					0
				],
				[
					44,
					0
				],
				[
					44,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.154296875,
				0.2587890625,
				0.298828125,
				0.2890625,
				0.2568359375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1576318173,
			"isDeleted": false,
			"id": "jGZDia7kIkbZKBpadHfil",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 219.70833333333235,
			"y": 288.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 4,
			"seed": 630330398,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					16,
					-4
				],
				[
					24,
					-4
				],
				[
					32,
					-4
				],
				[
					32,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.234375,
				0.26953125,
				0.244140625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 813912947,
			"isDeleted": false,
			"id": "-Uz_QsSMfFOMpX45k_YI6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 283.70833333333235,
			"y": 252.09895833333348,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 48,
			"seed": 1642963970,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					-4,
					24
				],
				[
					0,
					36
				],
				[
					0,
					44
				],
				[
					0,
					48
				],
				[
					0,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.4326171875,
				0.458984375,
				0.44140625,
				0.345703125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 54,
			"versionNonce": 178524477,
			"isDeleted": false,
			"id": "JatfvWUdow9CYY1OA2l3G",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -820.2916666666677,
			"y": 336.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 88,
			"height": 156,
			"seed": 1478660866,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-8,
					12
				],
				[
					-24,
					28
				],
				[
					-40,
					40
				],
				[
					-56,
					56
				],
				[
					-68,
					64
				],
				[
					-72,
					68
				],
				[
					-72,
					72
				],
				[
					-68,
					72
				],
				[
					-44,
					72
				],
				[
					-24,
					72
				],
				[
					-8,
					72
				],
				[
					0,
					76
				],
				[
					0,
					80
				],
				[
					-8,
					88
				],
				[
					-20,
					96
				],
				[
					-36,
					104
				],
				[
					-56,
					116
				],
				[
					-72,
					128
				],
				[
					-80,
					136
				],
				[
					-80,
					140
				],
				[
					-76,
					148
				],
				[
					-64,
					152
				],
				[
					-44,
					156
				],
				[
					-20,
					156
				],
				[
					-8,
					156
				],
				[
					0,
					156
				],
				[
					8,
					156
				],
				[
					8,
					152
				],
				[
					8,
					152
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.216796875,
				0.265625,
				0.3125,
				0.34765625,
				0.3779296875,
				0.392578125,
				0.3984375,
				0.4013671875,
				0.4033203125,
				0.404296875,
				0.4033203125,
				0.404296875,
				0.4072265625,
				0.4140625,
				0.412109375,
				0.4130859375,
				0.416015625,
				0.4208984375,
				0.44140625,
				0.4599609375,
				0.4775390625,
				0.50390625,
				0.513671875,
				0.5126953125,
				0.5185546875,
				0.51171875,
				0.478515625,
				0.3359375,
				0.1611328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 42,
			"versionNonce": 1850633491,
			"isDeleted": false,
			"id": "e4iGmsaWnVi0z16AriDRw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -884.2916666666677,
			"y": 328.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 36,
			"seed": 1343966978,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					12
				],
				[
					4,
					16
				],
				[
					4,
					20
				],
				[
					8,
					16
				],
				[
					8,
					8
				],
				[
					12,
					-4
				],
				[
					16,
					-12
				],
				[
					24,
					-16
				],
				[
					28,
					-12
				],
				[
					36,
					-4
				],
				[
					40,
					4
				],
				[
					40,
					12
				],
				[
					44,
					16
				],
				[
					44,
					20
				],
				[
					44,
					20
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0341796875,
				0.23046875,
				0.3017578125,
				0.3486328125,
				0.3642578125,
				0.3984375,
				0.4404296875,
				0.4423828125,
				0.439453125,
				0.439453125,
				0.4423828125,
				0.4560546875,
				0.462890625,
				0.4619140625,
				0.3818359375,
				0.2890625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 52,
			"versionNonce": 904454557,
			"isDeleted": false,
			"id": "NS9eHQ-qmyEKaqAhorXXo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -676.2916666666677,
			"y": 364.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 80,
			"height": 116,
			"seed": 1716573314,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-12,
					4
				],
				[
					-24,
					16
				],
				[
					-36,
					24
				],
				[
					-48,
					32
				],
				[
					-52,
					36
				],
				[
					-52,
					40
				],
				[
					-44,
					44
				],
				[
					-24,
					44
				],
				[
					-12,
					44
				],
				[
					0,
					44
				],
				[
					8,
					44
				],
				[
					8,
					48
				],
				[
					-4,
					60
				],
				[
					-20,
					72
				],
				[
					-44,
					84
				],
				[
					-56,
					96
				],
				[
					-60,
					96
				],
				[
					-60,
					100
				],
				[
					-60,
					108
				],
				[
					-48,
					108
				],
				[
					-32,
					112
				],
				[
					-12,
					112
				],
				[
					0,
					116
				],
				[
					8,
					116
				],
				[
					12,
					116
				],
				[
					20,
					112
				],
				[
					20,
					112
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0322265625,
				0.2412109375,
				0.2978515625,
				0.349609375,
				0.376953125,
				0.3994140625,
				0.4052734375,
				0.4072265625,
				0.4130859375,
				0.4140625,
				0.4140625,
				0.416015625,
				0.4228515625,
				0.435546875,
				0.4365234375,
				0.4365234375,
				0.443359375,
				0.462890625,
				0.4677734375,
				0.4873046875,
				0.5,
				0.5078125,
				0.5078125,
				0.5126953125,
				0.5185546875,
				0.5068359375,
				0.47265625,
				0.294921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 46,
			"versionNonce": 583357107,
			"isDeleted": false,
			"id": "PmnTznpzzt2ihlOlMc5Mh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -720.2916666666677,
			"y": 324.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 32,
			"seed": 1106180290,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					16
				],
				[
					0,
					20
				],
				[
					0,
					24
				],
				[
					0,
					20
				],
				[
					4,
					16
				],
				[
					4,
					12
				],
				[
					8,
					4
				],
				[
					12,
					0
				],
				[
					16,
					0
				],
				[
					24,
					8
				],
				[
					28,
					16
				],
				[
					32,
					20
				],
				[
					32,
					24
				],
				[
					36,
					24
				],
				[
					36,
					16
				],
				[
					44,
					4
				],
				[
					56,
					16
				],
				[
					60,
					24
				],
				[
					64,
					32
				],
				[
					64,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.2998046875,
				0.33984375,
				0.3994140625,
				0.423828125,
				0.4482421875,
				0.5087890625,
				0.49609375,
				0.486328125,
				0.4755859375,
				0.4697265625,
				0.4716796875,
				0.474609375,
				0.4853515625,
				0.490234375,
				0.4912109375,
				0.4912109375,
				0.4755859375,
				0.466796875,
				0.5107421875,
				0.51953125,
				0.330078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1425319421,
			"isDeleted": false,
			"id": "Kt8LH0dFotWsnKYFbKD23",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -900.2916666666677,
			"y": 536.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 76,
			"seed": 897459650,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					20
				],
				[
					4,
					56
				],
				[
					0,
					60
				],
				[
					-4,
					76
				],
				[
					-8,
					76
				],
				[
					-12,
					76
				],
				[
					-16,
					72
				],
				[
					-16,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.021484375,
				0.3828125,
				0.5166015625,
				0.521484375,
				0.5244140625,
				0.48046875,
				0.2666015625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 512656467,
			"isDeleted": false,
			"id": "PtKITigLLr0ZgHjD39696",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -924.2916666666677,
			"y": 552.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 20,
			"seed": 711216258,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-16
				],
				[
					8,
					-20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.21484375,
				0.28515625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 986242653,
			"isDeleted": false,
			"id": "GVQITRSfRoAORKxC8wDve",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -864.2916666666677,
			"y": 540.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 4,
			"seed": 1049281474,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					36,
					-4
				],
				[
					36,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0048828125,
				0.2236328125,
				0.26171875,
				0.2744140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1501594099,
			"isDeleted": false,
			"id": "ewtAYkdBZchwKgokSKqym",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -852.2916666666677,
			"y": 552.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 4,
			"seed": 238387970,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					8,
					4
				],
				[
					16,
					0
				],
				[
					24,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.0537109375,
				0.25390625,
				0.2587890625,
				0.2197265625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1580665533,
			"isDeleted": false,
			"id": "H8KS_rpYiHHx2EYecfjYo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -808.2916666666677,
			"y": 528.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 48,
			"seed": 1834919710,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					20
				],
				[
					0,
					28
				],
				[
					4,
					36
				],
				[
					4,
					44
				],
				[
					4,
					48
				],
				[
					4,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.404296875,
				0.4462890625,
				0.458984375,
				0.4169921875,
				0.294921875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 211930003,
			"isDeleted": false,
			"id": "hqKESSCDRYLUDAenL4L2A",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -732.2916666666677,
			"y": 536.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 48,
			"seed": 1361146050,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					20
				],
				[
					4,
					28
				],
				[
					8,
					40
				],
				[
					12,
					44
				],
				[
					16,
					48
				],
				[
					16,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.3310546875,
				0.384765625,
				0.4375,
				0.4716796875,
				0.4775390625,
				0.4033203125,
				0.150390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1608559389,
			"isDeleted": false,
			"id": "gbvGJ9fdlKIdnA_q2FWhf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -724.2916666666677,
			"y": 532.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 2140714882,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359178,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					0,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.02734375,
				0.1826171875,
				0.0966796875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 204005683,
			"isDeleted": false,
			"id": "aYEI8b0MdKEyOgSHv-8nJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -700.2916666666677,
			"y": 544.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 4,
			"seed": 1509101250,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					8,
					4
				],
				[
					16,
					4
				],
				[
					24,
					4
				],
				[
					28,
					4
				],
				[
					32,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0419921875,
				0.21875,
				0.29296875,
				0.3154296875,
				0.2939453125,
				0.2548828125,
				0.109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1345798013,
			"isDeleted": false,
			"id": "brkEMUNW8VZ1rbp-2T-Ft",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -688.2916666666677,
			"y": 560.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 4,
			"seed": 610794398,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					8,
					4
				],
				[
					16,
					0
				],
				[
					20,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0029296875,
				0.0927734375,
				0.2802734375,
				0.216796875,
				0.111328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1635533523,
			"isDeleted": false,
			"id": "8ThP1xgHgcG_VxZjQiSsB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -640.2916666666677,
			"y": 528.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 44,
			"seed": 1058421918,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					0,
					24
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.25390625,
				0.4140625,
				0.439453125,
				0.4521484375,
				0.4306640625,
				0.361328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 897337309,
			"isDeleted": false,
			"id": "Yxi2LPkad30J28NvoQ5Lx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -588.2916666666677,
			"y": 380.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 88,
			"seed": 1508029250,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					28
				],
				[
					4,
					56
				],
				[
					8,
					72
				],
				[
					8,
					80
				],
				[
					8,
					88
				],
				[
					12,
					88
				],
				[
					16,
					72
				],
				[
					24,
					60
				],
				[
					40,
					36
				],
				[
					52,
					16
				],
				[
					56,
					8
				],
				[
					56,
					8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0322265625,
				0.259765625,
				0.333984375,
				0.400390625,
				0.427734375,
				0.4375,
				0.458984375,
				0.5126953125,
				0.5166015625,
				0.5205078125,
				0.5126953125,
				0.427734375,
				0.3134765625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 624062579,
			"isDeleted": false,
			"id": "NzCOOEGGCYuyfa-JeWCbB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -540.2916666666677,
			"y": 400.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 68,
			"seed": 1311637406,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-8,
					20
				],
				[
					-12,
					28
				],
				[
					-12,
					36
				],
				[
					-12,
					52
				],
				[
					-4,
					60
				],
				[
					4,
					64
				],
				[
					12,
					68
				],
				[
					20,
					68
				],
				[
					24,
					64
				],
				[
					24,
					64
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0302734375,
				0.1689453125,
				0.2314453125,
				0.2880859375,
				0.3681640625,
				0.44921875,
				0.482421875,
				0.4892578125,
				0.4482421875,
				0.2841796875,
				0.142578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1371620413,
			"isDeleted": false,
			"id": "6tNZ1go6rTMHVdk_pfgsE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -500.29166666666765,
			"y": 428.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 68,
			"seed": 503347138,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					20
				],
				[
					8,
					36
				],
				[
					8,
					44
				],
				[
					8,
					56
				],
				[
					4,
					64
				],
				[
					-4,
					68
				],
				[
					-8,
					68
				],
				[
					-8,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.029296875,
				0.3525390625,
				0.3759765625,
				0.4521484375,
				0.509765625,
				0.5263671875,
				0.54296875,
				0.5302734375,
				0.3857421875,
				0.232421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 420604435,
			"isDeleted": false,
			"id": "rchheIpmR_4Ay_GUmDKEq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -512.2916666666677,
			"y": 424.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 570965570,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 686273693,
			"isDeleted": false,
			"id": "jcxVOLZRjkRcw-QKeiTO8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -460.29166666666765,
			"y": 424.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 48,
			"seed": 1897635678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					12
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					8,
					40
				],
				[
					8,
					44
				],
				[
					8,
					48
				],
				[
					8,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0029296875,
				0.2705078125,
				0.40625,
				0.4794921875,
				0.5009765625,
				0.49609375,
				0.453125,
				0.3408203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 34680755,
			"isDeleted": false,
			"id": "ue2avfscY7_agh3JH-cWH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -464.29166666666765,
			"y": 416.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 1037452446,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-12
				],
				[
					-4,
					-16
				],
				[
					0,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1533203125,
				0.244140625,
				0.1669921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1184962813,
			"isDeleted": false,
			"id": "RBoTEybL-ZNmL7oonxQFR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -412.29166666666765,
			"y": 404.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 12,
			"seed": 256895874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					16,
					-8
				],
				[
					36,
					-12
				],
				[
					52,
					-12
				],
				[
					60,
					-12
				],
				[
					60,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0263671875,
				0.16015625,
				0.4375,
				0.45703125,
				0.470703125,
				0.49609375,
				0.4716796875,
				0.380859375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1112981843,
			"isDeleted": false,
			"id": "x0TGg25piWucyIiO3kV-0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -392.29166666666765,
			"y": 392.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 84,
			"seed": 1671592514,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					8
				],
				[
					-4,
					20
				],
				[
					-4,
					40
				],
				[
					-4,
					60
				],
				[
					0,
					72
				],
				[
					0,
					80
				],
				[
					0,
					84
				],
				[
					0,
					84
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.044921875,
				0.0986328125,
				0.271484375,
				0.3955078125,
				0.46484375,
				0.505859375,
				0.4921875,
				0.3828125,
				0.3056640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1148121437,
			"isDeleted": false,
			"id": "xL1ZGoP4vM6lODOgGj7mf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -416.29166666666765,
			"y": 456.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 40,
			"seed": 450836510,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					8,
					-16
				],
				[
					24,
					-20
				],
				[
					36,
					-16
				],
				[
					44,
					-12
				],
				[
					52,
					-4
				],
				[
					56,
					8
				],
				[
					60,
					16
				],
				[
					60,
					20
				],
				[
					60,
					20
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.08984375,
				0.1884765625,
				0.3125,
				0.3857421875,
				0.423828125,
				0.4482421875,
				0.4638671875,
				0.484375,
				0.478515625,
				0.439453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 859381491,
			"isDeleted": false,
			"id": "k7b1nKjD5YZWKbA9bPSDZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -360.29166666666765,
			"y": 432.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 44787522,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-8
				],
				[
					-4,
					-12
				],
				[
					0,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.205078125,
				0.255859375,
				0.2373046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 262323645,
			"isDeleted": false,
			"id": "qZe-UHuWqF1ikujw8VzvZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -316.29166666666765,
			"y": 420.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 4,
			"seed": 1279347358,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					20,
					0
				],
				[
					28,
					0
				],
				[
					36,
					-4
				],
				[
					40,
					-4
				],
				[
					40,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.3837890625,
				0.4287109375,
				0.4609375,
				0.4580078125,
				0.3779296875,
				0.267578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1061079187,
			"isDeleted": false,
			"id": "D-1SNFoCaTqf5BDUyviJ6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -312.29166666666765,
			"y": 436.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 8,
			"seed": 20874562,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					8
				],
				[
					0,
					8
				],
				[
					20,
					8
				],
				[
					36,
					8
				],
				[
					40,
					4
				],
				[
					40,
					4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.240234375,
				0.3291015625,
				0.3125,
				0.1865234375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 42,
			"versionNonce": 1868430877,
			"isDeleted": false,
			"id": "ovNphkUkEEfgg2YNu-Knn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -244.29166666666765,
			"y": 412.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 68,
			"seed": 1884869698,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					4
				],
				[
					-8,
					16
				],
				[
					-8,
					28
				],
				[
					0,
					44
				],
				[
					8,
					52
				],
				[
					20,
					48
				],
				[
					32,
					44
				],
				[
					40,
					32
				],
				[
					44,
					16
				],
				[
					36,
					-4
				],
				[
					24,
					-12
				],
				[
					12,
					-16
				],
				[
					-4,
					-12
				],
				[
					-8,
					-4
				],
				[
					-16,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1103515625,
				0.2958984375,
				0.35546875,
				0.396484375,
				0.4287109375,
				0.4404296875,
				0.447265625,
				0.458984375,
				0.484375,
				0.529296875,
				0.576171875,
				0.58984375,
				0.5830078125,
				0.5087890625,
				0.361328125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1008614963,
			"isDeleted": false,
			"id": "9_wWgo44z25bmBm6RF_dF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1348.2916666666677,
			"y": 796.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 84,
			"seed": 1575274946,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					16,
					-80
				],
				[
					16,
					-84
				],
				[
					20,
					-80
				],
				[
					28,
					-60
				],
				[
					32,
					-40
				],
				[
					32,
					-28
				],
				[
					36,
					-16
				],
				[
					36,
					-12
				],
				[
					40,
					-8
				],
				[
					40,
					-8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.279296875,
				0.2890625,
				0.33203125,
				0.3544921875,
				0.365234375,
				0.369140625,
				0.3662109375,
				0.3291015625,
				0.2841796875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1251095165,
			"isDeleted": false,
			"id": "8kLNbNxtICxloVMN3e1yB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1340.2916666666677,
			"y": 756.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 16,
			"seed": 856100930,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					16,
					-12
				],
				[
					28,
					-12
				],
				[
					40,
					-16
				],
				[
					48,
					-16
				],
				[
					48,
					-16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.23828125,
				0.3037109375,
				0.3388671875,
				0.353515625,
				0.2978515625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 79560659,
			"isDeleted": false,
			"id": "_3xMU8P8GPmCYoBHTP5fI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1288.2916666666677,
			"y": 748.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 4,
			"seed": 1243491806,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					16,
					0
				],
				[
					24,
					-4
				],
				[
					28,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.255859375,
				0.27734375,
				0.2998046875,
				0.302734375,
				0.2060546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 771807965,
			"isDeleted": false,
			"id": "XcBDcu5oqtmCPe0cO60s4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1284.2916666666677,
			"y": 768.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 4,
			"seed": 178656770,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					12,
					0
				],
				[
					20,
					0
				],
				[
					28,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.025390625,
				0.1376953125,
				0.302734375,
				0.353515625,
				0.3681640625,
				0.3466796875,
				0.1328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 52,
			"versionNonce": 1395953011,
			"isDeleted": false,
			"id": "54dCKhkgITKsk-fEqNk0L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1224.2916666666677,
			"y": 736.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 44,
			"seed": 1062081730,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					12
				],
				[
					8,
					20
				],
				[
					12,
					28
				],
				[
					12,
					40
				],
				[
					12,
					44
				],
				[
					8,
					40
				],
				[
					8,
					32
				],
				[
					8,
					20
				],
				[
					12,
					16
				],
				[
					16,
					8
				],
				[
					20,
					8
				],
				[
					28,
					12
				],
				[
					32,
					24
				],
				[
					36,
					32
				],
				[
					36,
					36
				],
				[
					36,
					40
				],
				[
					36,
					44
				],
				[
					36,
					36
				],
				[
					40,
					28
				],
				[
					40,
					20
				],
				[
					44,
					16
				],
				[
					52,
					20
				],
				[
					56,
					28
				],
				[
					60,
					36
				],
				[
					64,
					40
				],
				[
					68,
					44
				],
				[
					68,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.208984375,
				0.232421875,
				0.2587890625,
				0.2822265625,
				0.30859375,
				0.3466796875,
				0.390625,
				0.388671875,
				0.384765625,
				0.3837890625,
				0.380859375,
				0.3798828125,
				0.3759765625,
				0.380859375,
				0.384765625,
				0.38671875,
				0.3984375,
				0.42578125,
				0.42578125,
				0.4228515625,
				0.4169921875,
				0.412109375,
				0.412109375,
				0.412109375,
				0.3681640625,
				0.25,
				0.1298828125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 305887037,
			"isDeleted": false,
			"id": "Fe_wuWwxCHLw972pSn68-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1124.2916666666677,
			"y": 732.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 44,
			"seed": 31899906,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					4,
					40
				],
				[
					8,
					40
				],
				[
					8,
					44
				],
				[
					8,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.259765625,
				0.3056640625,
				0.357421875,
				0.37890625,
				0.3740234375,
				0.3369140625,
				0.234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1523083027,
			"isDeleted": false,
			"id": "HbmMruft3HZHeoKKIDsXV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1140.2916666666677,
			"y": 760.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 8,
			"seed": 566484930,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					16,
					-4
				],
				[
					20,
					-4
				],
				[
					32,
					-8
				],
				[
					32,
					-8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.220703125,
				0.333984375,
				0.3505859375,
				0.330078125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 41,
			"versionNonce": 1638107037,
			"isDeleted": false,
			"id": "FII0bFRqOemRPQOAtBdB9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1096.2916666666677,
			"y": 736.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 48,
			"seed": 136113858,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359179,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					16
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					4,
					36
				],
				[
					4,
					44
				],
				[
					4,
					40
				],
				[
					4,
					32
				],
				[
					4,
					20
				],
				[
					8,
					12
				],
				[
					8,
					8
				],
				[
					16,
					12
				],
				[
					24,
					24
				],
				[
					28,
					36
				],
				[
					32,
					44
				],
				[
					36,
					44
				],
				[
					36,
					48
				],
				[
					36,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3603515625,
				0.376953125,
				0.412109375,
				0.4384765625,
				0.4697265625,
				0.4892578125,
				0.474609375,
				0.4521484375,
				0.4453125,
				0.439453125,
				0.4462890625,
				0.44921875,
				0.451171875,
				0.380859375,
				0.3125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 569380019,
			"isDeleted": false,
			"id": "QqAMgyOYIV5w8348xZjP8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1072.2916666666677,
			"y": 708.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 88,
			"seed": 1029069982,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					8,
					4
				],
				[
					16,
					16
				],
				[
					24,
					36
				],
				[
					28,
					52
				],
				[
					28,
					68
				],
				[
					32,
					76
				],
				[
					28,
					84
				],
				[
					28,
					84
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0322265625,
				0.19140625,
				0.3232421875,
				0.404296875,
				0.451171875,
				0.46875,
				0.4072265625,
				0.3203125,
				0.1328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1047170045,
			"isDeleted": false,
			"id": "mtRryUbG2lcfmhb22Ryeq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1220.2916666666677,
			"y": 708.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 104,
			"seed": 227859202,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-8,
					20
				],
				[
					-12,
					36
				],
				[
					-12,
					56
				],
				[
					-12,
					72
				],
				[
					-4,
					88
				],
				[
					4,
					100
				],
				[
					8,
					104
				],
				[
					8,
					104
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.18359375,
				0.220703125,
				0.3076171875,
				0.3740234375,
				0.396484375,
				0.3759765625,
				0.2353515625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 475135571,
			"isDeleted": false,
			"id": "HYK2yjbItUp4tp7g_u4Ea",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -980.2916666666677,
			"y": 728.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 48,
			"seed": 1342258014,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					0,
					8
				],
				[
					-4,
					20
				],
				[
					-8,
					28
				],
				[
					-16,
					40
				],
				[
					-20,
					44
				],
				[
					-20,
					48
				],
				[
					-20,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0224609375,
				0.19140625,
				0.236328125,
				0.3095703125,
				0.330078125,
				0.328125,
				0.220703125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 143787101,
			"isDeleted": false,
			"id": "u6CvAGbdYMprj_YEztQo0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1008.2916666666677,
			"y": 740.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 36,
			"seed": 230318238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					0
				],
				[
					12,
					4
				],
				[
					20,
					16
				],
				[
					28,
					24
				],
				[
					32,
					28
				],
				[
					36,
					32
				],
				[
					36,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0048828125,
				0.1630859375,
				0.2626953125,
				0.3466796875,
				0.3955078125,
				0.4150390625,
				0.3984375,
				0.2958984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 80002035,
			"isDeleted": false,
			"id": "dH3_myx_u-ZyClGxjEmL1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -944.2916666666677,
			"y": 704.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 84,
			"seed": 550780382,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					-4,
					12
				],
				[
					-8,
					28
				],
				[
					-8,
					40
				],
				[
					-8,
					56
				],
				[
					-4,
					72
				],
				[
					4,
					76
				],
				[
					8,
					80
				],
				[
					16,
					84
				],
				[
					16,
					84
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.20703125,
				0.2978515625,
				0.392578125,
				0.4560546875,
				0.5009765625,
				0.5302734375,
				0.4755859375,
				0.375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 46,
			"versionNonce": 602632381,
			"isDeleted": false,
			"id": "ConvdQNbbCAmrPIavSjMt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -916.2916666666677,
			"y": 732.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 48,
			"seed": 1601159006,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					8,
					32
				],
				[
					8,
					40
				],
				[
					8,
					44
				],
				[
					4,
					40
				],
				[
					4,
					32
				],
				[
					4,
					24
				],
				[
					8,
					16
				],
				[
					12,
					8
				],
				[
					16,
					16
				],
				[
					20,
					32
				],
				[
					24,
					36
				],
				[
					20,
					36
				],
				[
					20,
					20
				],
				[
					32,
					8
				],
				[
					40,
					16
				],
				[
					44,
					28
				],
				[
					48,
					36
				],
				[
					48,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0400390625,
				0.205078125,
				0.283203125,
				0.337890625,
				0.39453125,
				0.419921875,
				0.4267578125,
				0.4638671875,
				0.4501953125,
				0.4423828125,
				0.4365234375,
				0.423828125,
				0.4248046875,
				0.43359375,
				0.4462890625,
				0.4599609375,
				0.4521484375,
				0.4443359375,
				0.4677734375,
				0.4599609375,
				0.251953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 2001651091,
			"isDeleted": false,
			"id": "zfeWdDMiihaIR01uGP2s8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -824.2916666666677,
			"y": 716.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 52,
			"seed": 552690270,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					4,
					20
				],
				[
					4,
					32
				],
				[
					4,
					44
				],
				[
					8,
					48
				],
				[
					8,
					52
				],
				[
					8,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0146484375,
				0.322265625,
				0.3837890625,
				0.4169921875,
				0.4521484375,
				0.4755859375,
				0.4189453125,
				0.3505859375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 2115522845,
			"isDeleted": false,
			"id": "HwGVXNNyyIfZFjoMUaO8j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -836.2916666666677,
			"y": 752.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 16,
			"seed": 1622288286,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					0,
					-8
				],
				[
					8,
					-12
				],
				[
					20,
					-12
				],
				[
					24,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0185546875,
				0.1982421875,
				0.3271484375,
				0.3369140625,
				0.2255859375,
				0.1103515625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 42,
			"versionNonce": 1260821299,
			"isDeleted": false,
			"id": "VMwihKCZsUVutgLWgo4fd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -800.2916666666677,
			"y": 724.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 48,
			"seed": 700741698,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					8,
					28
				],
				[
					8,
					36
				],
				[
					8,
					40
				],
				[
					8,
					36
				],
				[
					8,
					32
				],
				[
					12,
					20
				],
				[
					12,
					12
				],
				[
					16,
					8
				],
				[
					20,
					12
				],
				[
					28,
					24
				],
				[
					36,
					32
				],
				[
					40,
					40
				],
				[
					40,
					44
				],
				[
					44,
					48
				],
				[
					44,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2099609375,
				0.2900390625,
				0.33203125,
				0.3681640625,
				0.388671875,
				0.40234375,
				0.4462890625,
				0.4462890625,
				0.4443359375,
				0.4453125,
				0.4482421875,
				0.4658203125,
				0.4990234375,
				0.505859375,
				0.4970703125,
				0.431640625,
				0.3330078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1418339709,
			"isDeleted": false,
			"id": "E_PhcRAOvLHhTXgtJmIPx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -772.2916666666677,
			"y": 688.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 108,
			"seed": 735276482,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					8,
					4
				],
				[
					16,
					20
				],
				[
					24,
					44
				],
				[
					32,
					68
				],
				[
					36,
					88
				],
				[
					36,
					100
				],
				[
					36,
					104
				],
				[
					36,
					104
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.212890625,
				0.345703125,
				0.435546875,
				0.4970703125,
				0.52734375,
				0.4755859375,
				0.34765625,
				0.1865234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 58,
			"versionNonce": 749911251,
			"isDeleted": false,
			"id": "YkJ_YyThfcnN-FV9d5cVN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1360.2916666666677,
			"y": 888.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 72,
			"seed": 2142661790,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					8
				],
				[
					8,
					20
				],
				[
					8,
					28
				],
				[
					12,
					28
				],
				[
					12,
					32
				],
				[
					12,
					40
				],
				[
					12,
					36
				],
				[
					12,
					32
				],
				[
					12,
					20
				],
				[
					12,
					4
				],
				[
					16,
					-8
				],
				[
					20,
					-16
				],
				[
					28,
					-20
				],
				[
					36,
					-16
				],
				[
					44,
					-12
				],
				[
					44,
					-4
				],
				[
					44,
					12
				],
				[
					36,
					20
				],
				[
					32,
					20
				],
				[
					32,
					24
				],
				[
					28,
					24
				],
				[
					28,
					16
				],
				[
					32,
					16
				],
				[
					36,
					16
				],
				[
					44,
					20
				],
				[
					48,
					24
				],
				[
					48,
					32
				],
				[
					44,
					40
				],
				[
					36,
					48
				],
				[
					32,
					52
				],
				[
					24,
					52
				],
				[
					20,
					48
				],
				[
					20,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0224609375,
				0.2158203125,
				0.265625,
				0.3359375,
				0.35546875,
				0.359375,
				0.36328125,
				0.306640625,
				0.1123046875,
				0.08203125,
				0.0732421875,
				0.1142578125,
				0.189453125,
				0.2373046875,
				0.2978515625,
				0.3515625,
				0.3974609375,
				0.41796875,
				0.447265625,
				0.453125,
				0.455078125,
				0.45703125,
				0.453125,
				0.4306640625,
				0.4248046875,
				0.421875,
				0.451171875,
				0.474609375,
				0.5166015625,
				0.5283203125,
				0.5322265625,
				0.521484375,
				0.4091796875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 981626333,
			"isDeleted": false,
			"id": "O7df8DAML9cth7MAE1PIA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1272.2916666666677,
			"y": 896.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 8,
			"seed": 745627934,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					12,
					-4
				],
				[
					16,
					-4
				],
				[
					24,
					-4
				],
				[
					28,
					-8
				],
				[
					32,
					-8
				],
				[
					36,
					-8
				],
				[
					36,
					-8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0068359375,
				0.158203125,
				0.2353515625,
				0.33203125,
				0.3583984375,
				0.359375,
				0.2890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 2005510771,
			"isDeleted": false,
			"id": "Y4MccCm0e9fvlEB4v9mxf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1264.2916666666677,
			"y": 908.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 4,
			"seed": 1544312514,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					12,
					0
				],
				[
					20,
					0
				],
				[
					28,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2529296875,
				0.2900390625,
				0.2373046875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1595058749,
			"isDeleted": false,
			"id": "Uq8e-lnSlI_p3PeQqqyiF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1192.2916666666677,
			"y": 856.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 88,
			"seed": 1794237890,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-12,
					28
				],
				[
					-12,
					52
				],
				[
					-8,
					68
				],
				[
					-4,
					76
				],
				[
					4,
					84
				],
				[
					4,
					88
				],
				[
					4,
					88
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0419921875,
				0.3271484375,
				0.42578125,
				0.48828125,
				0.498046875,
				0.4287109375,
				0.2802734375,
				0.140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 47,
			"versionNonce": 1349641235,
			"isDeleted": false,
			"id": "4rEWQr6MVQNkvk9zhF0Ia",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1168.2916666666677,
			"y": 884.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 56,
			"seed": 1065356418,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					28
				],
				[
					8,
					48
				],
				[
					12,
					52
				],
				[
					12,
					56
				],
				[
					8,
					44
				],
				[
					8,
					24
				],
				[
					20,
					8
				],
				[
					28,
					12
				],
				[
					28,
					16
				],
				[
					32,
					28
				],
				[
					36,
					36
				],
				[
					36,
					40
				],
				[
					40,
					44
				],
				[
					36,
					36
				],
				[
					40,
					24
				],
				[
					40,
					16
				],
				[
					44,
					12
				],
				[
					52,
					20
				],
				[
					60,
					28
				],
				[
					64,
					36
				],
				[
					68,
					44
				],
				[
					68,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.1943359375,
				0.3486328125,
				0.3955078125,
				0.41015625,
				0.4326171875,
				0.478515625,
				0.470703125,
				0.4599609375,
				0.4599609375,
				0.462890625,
				0.470703125,
				0.4755859375,
				0.4794921875,
				0.4951171875,
				0.509765625,
				0.5029296875,
				0.4931640625,
				0.4912109375,
				0.501953125,
				0.5107421875,
				0.4892578125,
				0.359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 320625309,
			"isDeleted": false,
			"id": "QErgnzClIEPXrwugxzJhq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1080.2916666666677,
			"y": 872.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 52,
			"seed": 1362769822,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					8
				],
				[
					4,
					16
				],
				[
					8,
					28
				],
				[
					12,
					36
				],
				[
					12,
					44
				],
				[
					16,
					48
				],
				[
					12,
					52
				],
				[
					12,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0341796875,
				0.3466796875,
				0.400390625,
				0.4609375,
				0.515625,
				0.5390625,
				0.509765625,
				0.333984375,
				0.1455078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 2137123251,
			"isDeleted": false,
			"id": "KaeHOOC9r64dXWGtpFPP5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1088.2916666666677,
			"y": 908.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 16,
			"seed": 1509625858,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					16,
					-12
				],
				[
					20,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0322265625,
				0.1474609375,
				0.2255859375,
				0.275390625,
				0.21484375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 256966397,
			"isDeleted": false,
			"id": "zbtkAYEtE1WfPfU6s08Sf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1048.2916666666677,
			"y": 884.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 44,
			"seed": 231402014,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					20
				],
				[
					0,
					36
				],
				[
					0,
					40
				],
				[
					4,
					12
				],
				[
					8,
					8
				],
				[
					16,
					12
				],
				[
					20,
					20
				],
				[
					28,
					32
				],
				[
					32,
					40
				],
				[
					32,
					44
				],
				[
					32,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.26953125,
				0.361328125,
				0.4755859375,
				0.5029296875,
				0.5234375,
				0.5234375,
				0.5224609375,
				0.529296875,
				0.5263671875,
				0.416015625,
				0.3134765625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 159398739,
			"isDeleted": false,
			"id": "zCzarxg5oz4jkqw0aZ_Vu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1012.2916666666677,
			"y": 848.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 96,
			"seed": 1912281054,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359180,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					12
				],
				[
					12,
					28
				],
				[
					20,
					48
				],
				[
					24,
					68
				],
				[
					24,
					80
				],
				[
					24,
					88
				],
				[
					20,
					96
				],
				[
					20,
					96
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1611328125,
				0.3310546875,
				0.4365234375,
				0.5078125,
				0.53125,
				0.53125,
				0.486328125,
				0.337890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 2050103133,
			"isDeleted": false,
			"id": "-PMRkyGTu0HR3Er7nAk49",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -948.2916666666677,
			"y": 876.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 56,
			"seed": 59046850,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					16
				],
				[
					0,
					28
				],
				[
					-8,
					44
				],
				[
					-8,
					52
				],
				[
					-12,
					56
				],
				[
					-16,
					56
				],
				[
					-16,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0009765625,
				0.16796875,
				0.4677734375,
				0.5244140625,
				0.53515625,
				0.49609375,
				0.345703125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 186865907,
			"isDeleted": false,
			"id": "Dali-grSbTaQIlifNhxUE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -972.2916666666677,
			"y": 884.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 32,
			"seed": 1801806466,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					12,
					8
				],
				[
					20,
					12
				],
				[
					24,
					20
				],
				[
					28,
					24
				],
				[
					32,
					28
				],
				[
					32,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0400390625,
				0.0927734375,
				0.302734375,
				0.4462890625,
				0.5048828125,
				0.5244140625,
				0.51953125,
				0.2802734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 772875197,
			"isDeleted": false,
			"id": "l1yJpvUOMjHEuhlJt3NO0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -924.2916666666677,
			"y": 860.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 76,
			"seed": 275616066,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					4,
					0
				],
				[
					8,
					12
				],
				[
					12,
					24
				],
				[
					16,
					64
				],
				[
					16,
					68
				],
				[
					16,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.109375,
				0.2314453125,
				0.3876953125,
				0.46484375,
				0.4970703125,
				0.3466796875,
				0.1865234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1372701331,
			"isDeleted": false,
			"id": "51oPhluFllZINIcNY09bz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1348.2916666666677,
			"y": 1060.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 76,
			"seed": 1489012738,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-12,
					0
				],
				[
					-20,
					4
				],
				[
					-32,
					20
				],
				[
					-36,
					32
				],
				[
					-36,
					48
				],
				[
					-32,
					60
				],
				[
					-24,
					68
				],
				[
					-16,
					72
				],
				[
					-4,
					72
				],
				[
					-4,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0244140625,
				0.181640625,
				0.2744140625,
				0.34375,
				0.431640625,
				0.470703125,
				0.5,
				0.5068359375,
				0.4951171875,
				0.419921875,
				0.18359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1057989661,
			"isDeleted": false,
			"id": "K8o4jvHCu3U3mHwmpXUyQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1316.2916666666677,
			"y": 1080.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 16,
			"seed": 114918046,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					12,
					-8
				],
				[
					20,
					-12
				],
				[
					28,
					-12
				],
				[
					36,
					-16
				],
				[
					36,
					-16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1416015625,
				0.21875,
				0.3232421875,
				0.373046875,
				0.3828125,
				0.3173828125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 910293043,
			"isDeleted": false,
			"id": "FGwHDv7dYblHi4di2jqF1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1308.2916666666677,
			"y": 1088.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 4,
			"seed": 864144706,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					8,
					4
				],
				[
					20,
					4
				],
				[
					28,
					0
				],
				[
					32,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.005859375,
				0.1669921875,
				0.291015625,
				0.3271484375,
				0.349609375,
				0.3291015625,
				0.2333984375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 51,
			"versionNonce": 1092556925,
			"isDeleted": false,
			"id": "wR0Z9ttwibDHvSb-97vaU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1212.2916666666677,
			"y": 1056.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 88,
			"height": 52,
			"seed": 1826125086,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					24
				],
				[
					4,
					32
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					48
				],
				[
					4,
					44
				],
				[
					0,
					36
				],
				[
					4,
					20
				],
				[
					8,
					8
				],
				[
					16,
					0
				],
				[
					28,
					8
				],
				[
					36,
					20
				],
				[
					40,
					28
				],
				[
					40,
					32
				],
				[
					40,
					28
				],
				[
					44,
					16
				],
				[
					48,
					8
				],
				[
					52,
					4
				],
				[
					56,
					8
				],
				[
					64,
					20
				],
				[
					76,
					40
				],
				[
					80,
					48
				],
				[
					84,
					52
				],
				[
					88,
					52
				],
				[
					88,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1962890625,
				0.23046875,
				0.283203125,
				0.3173828125,
				0.341796875,
				0.3662109375,
				0.3935546875,
				0.4248046875,
				0.4365234375,
				0.44140625,
				0.4443359375,
				0.447265625,
				0.455078125,
				0.470703125,
				0.4794921875,
				0.4892578125,
				0.4814453125,
				0.4755859375,
				0.4697265625,
				0.470703125,
				0.478515625,
				0.484375,
				0.4560546875,
				0.384765625,
				0.26171875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 911899091,
			"isDeleted": false,
			"id": "qdGe3k6j1Rb0eV_Hs9e9y",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1116.2916666666677,
			"y": 1052.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 52,
			"seed": 1507219522,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					12,
					32
				],
				[
					16,
					48
				],
				[
					16,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0302734375,
				0.1259765625,
				0.4833984375,
				0.16015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1308688605,
			"isDeleted": false,
			"id": "CdfHz2fFZKpOJFRIvXSHW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1132.2916666666677,
			"y": 1072.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 12,
			"seed": 1359177602,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					12,
					-8
				],
				[
					20,
					-8
				],
				[
					32,
					-12
				],
				[
					32,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0546875,
				0.328125,
				0.41796875,
				0.392578125,
				0.1396484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 1328662387,
			"isDeleted": false,
			"id": "MRY4_7bzOfTURf3GEmTT1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1080.2916666666677,
			"y": 1052.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 40,
			"seed": 1855325790,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					20
				],
				[
					4,
					24
				],
				[
					8,
					36
				],
				[
					8,
					40
				],
				[
					8,
					36
				],
				[
					8,
					20
				],
				[
					12,
					4
				],
				[
					24,
					20
				],
				[
					32,
					32
				],
				[
					32,
					40
				],
				[
					36,
					40
				],
				[
					36,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.009765625,
				0.4599609375,
				0.4765625,
				0.505859375,
				0.515625,
				0.5263671875,
				0.5068359375,
				0.5009765625,
				0.509765625,
				0.4951171875,
				0.3857421875,
				0.302734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1262935357,
			"isDeleted": false,
			"id": "gcK9mth2caVH1nyLYNw0a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1056.2916666666677,
			"y": 1012.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 100,
			"seed": 1072462878,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8,
					8
				],
				[
					12,
					12
				],
				[
					16,
					20
				],
				[
					32,
					64
				],
				[
					32,
					76
				],
				[
					32,
					88
				],
				[
					32,
					96
				],
				[
					28,
					100
				],
				[
					28,
					100
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.037109375,
				0.375,
				0.4091796875,
				0.466796875,
				0.57421875,
				0.5595703125,
				0.4970703125,
				0.380859375,
				0.23046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 386818323,
			"isDeleted": false,
			"id": "bKMhVHzx3uDvYGusCg_yj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1220.2916666666677,
			"y": 1020.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 96,
			"seed": 1115890562,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-12,
					20
				],
				[
					-16,
					36
				],
				[
					-20,
					76
				],
				[
					-12,
					88
				],
				[
					-4,
					96
				],
				[
					-4,
					96
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0185546875,
				0.2265625,
				0.3154296875,
				0.4091796875,
				0.322265625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1884433821,
			"isDeleted": false,
			"id": "m3Rj6dgRruRPGp-pQICgj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -996.2916666666677,
			"y": 1044.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 52,
			"seed": 2017219202,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					0,
					24
				],
				[
					-4,
					40
				],
				[
					-8,
					48
				],
				[
					-8,
					52
				],
				[
					-8,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2412109375,
				0.369140625,
				0.4306640625,
				0.4521484375,
				0.40625,
				0.33984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 392611507,
			"isDeleted": false,
			"id": "NBnhgG4k6tyw26WeygBH3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1020.2916666666677,
			"y": 1056.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 32,
			"seed": 1175867294,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					4,
					0
				],
				[
					16,
					8
				],
				[
					24,
					16
				],
				[
					32,
					24
				],
				[
					40,
					28
				],
				[
					44,
					28
				],
				[
					44,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.173828125,
				0.44921875,
				0.5068359375,
				0.52734375,
				0.498046875,
				0.3505859375,
				0.1826171875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 206860797,
			"isDeleted": false,
			"id": "qiJMfG4T17n4ZjuXSRFfU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -964.2916666666677,
			"y": 1036.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 72,
			"seed": 1457179870,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					4
				],
				[
					8,
					20
				],
				[
					12,
					36
				],
				[
					16,
					56
				],
				[
					20,
					64
				],
				[
					20,
					68
				],
				[
					20,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.044921875,
				0.146484375,
				0.443359375,
				0.5009765625,
				0.5205078125,
				0.494140625,
				0.37890625,
				0.2021484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 49,
			"versionNonce": 1726052435,
			"isDeleted": false,
			"id": "Evj24mDayRaaqq6HJJOuX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -604.2916666666677,
			"y": 684.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 80,
			"height": 80,
			"seed": 1088541890,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					16
				],
				[
					4,
					36
				],
				[
					8,
					48
				],
				[
					16,
					60
				],
				[
					24,
					64
				],
				[
					32,
					56
				],
				[
					44,
					40
				],
				[
					48,
					24
				],
				[
					52,
					4
				],
				[
					52,
					-12
				],
				[
					52,
					-16
				],
				[
					48,
					-16
				],
				[
					48,
					-4
				],
				[
					48,
					16
				],
				[
					52,
					36
				],
				[
					56,
					44
				],
				[
					60,
					48
				],
				[
					72,
					44
				],
				[
					76,
					32
				],
				[
					80,
					16
				],
				[
					80,
					4
				],
				[
					80,
					-4
				],
				[
					80,
					-8
				],
				[
					80,
					-12
				],
				[
					80,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0146484375,
				0.244140625,
				0.30078125,
				0.33203125,
				0.3583984375,
				0.3828125,
				0.40625,
				0.4169921875,
				0.4287109375,
				0.435546875,
				0.4384765625,
				0.4384765625,
				0.4375,
				0.4404296875,
				0.4365234375,
				0.4345703125,
				0.4423828125,
				0.4453125,
				0.4677734375,
				0.478515625,
				0.482421875,
				0.4599609375,
				0.390625,
				0.314453125,
				0.1416015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 206514781,
			"isDeleted": false,
			"id": "Q7DBZ--fNYwts6e3v0VAf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -512.2916666666677,
			"y": 696.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 36,
			"seed": 2026526622,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					4,
					16
				],
				[
					4,
					20
				],
				[
					4,
					24
				],
				[
					4,
					28
				],
				[
					4,
					36
				],
				[
					4,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1669921875,
				0.28515625,
				0.3193359375,
				0.34375,
				0.3701171875,
				0.3056640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 43,
			"versionNonce": 55899635,
			"isDeleted": false,
			"id": "uOMGtXAoGI0EEj-GVzvhO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -380.29166666666765,
			"y": 680.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 68,
			"seed": 1357488158,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					8
				],
				[
					-8,
					12
				],
				[
					-8,
					20
				],
				[
					-8,
					32
				],
				[
					-8,
					40
				],
				[
					-4,
					48
				],
				[
					0,
					52
				],
				[
					8,
					56
				],
				[
					16,
					48
				],
				[
					28,
					36
				],
				[
					32,
					24
				],
				[
					32,
					12
				],
				[
					16,
					-12
				],
				[
					-12,
					-4
				],
				[
					-20,
					4
				],
				[
					-20,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1357421875,
				0.2275390625,
				0.2587890625,
				0.294921875,
				0.3232421875,
				0.3447265625,
				0.3603515625,
				0.3779296875,
				0.3857421875,
				0.4052734375,
				0.42578125,
				0.4306640625,
				0.4365234375,
				0.4501953125,
				0.3564453125,
				0.1337890625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1091819197,
			"isDeleted": false,
			"id": "amSgbvShYYBi8IvmF0e7q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -280.29166666666765,
			"y": 696.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 8,
			"seed": 917950018,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.33984375,
				0.462890625,
				0.4306640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1808252819,
			"isDeleted": false,
			"id": "McUqDBMy8ldg9aJM5GXme",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -244.29166666666765,
			"y": 696.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 1485075358,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3203125,
				0.3984375,
				0.2314453125,
				0.1240234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1698952989,
			"isDeleted": false,
			"id": "fAlFUIxpkoxWkNNg1h-9L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -216.29166666666765,
			"y": 692.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 624342174,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-8
				],
				[
					8,
					-4
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.375,
				0.43359375,
				0.46484375,
				0.2529296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 2054182195,
			"isDeleted": false,
			"id": "ej_PU1l7zAKL6W1NdECql",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -288.29166666666765,
			"y": 700.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 2051044766,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					8,
					0
				],
				[
					4,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0029296875,
				0.3544921875,
				0.44921875,
				0.462890625,
				0.462890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 45,
			"versionNonce": 1666255741,
			"isDeleted": false,
			"id": "WJPiQ0YpXQEfFXSige5o0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -104.29166666666765,
			"y": 668.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 64,
			"seed": 803321502,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					0
				],
				[
					-12,
					8
				],
				[
					-16,
					20
				],
				[
					-16,
					32
				],
				[
					-16,
					40
				],
				[
					-8,
					48
				],
				[
					0,
					52
				],
				[
					12,
					48
				],
				[
					20,
					40
				],
				[
					28,
					28
				],
				[
					32,
					16
				],
				[
					28,
					0
				],
				[
					20,
					-8
				],
				[
					12,
					-12
				],
				[
					0,
					-12
				],
				[
					-8,
					-4
				],
				[
					-12,
					0
				],
				[
					-16,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1103515625,
				0.2451171875,
				0.294921875,
				0.34765625,
				0.3857421875,
				0.4072265625,
				0.4248046875,
				0.443359375,
				0.4609375,
				0.46875,
				0.4765625,
				0.482421875,
				0.4931640625,
				0.4912109375,
				0.4853515625,
				0.4677734375,
				0.396484375,
				0.333984375,
				0.15234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 41,
			"versionNonce": 2125805267,
			"isDeleted": false,
			"id": "AXrnjhPrlLImBCNlEtmyj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -580.2916666666677,
			"y": 832.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 72,
			"seed": 322397250,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					-4,
					32
				],
				[
					-4,
					36
				],
				[
					0,
					48
				],
				[
					8,
					52
				],
				[
					16,
					48
				],
				[
					28,
					40
				],
				[
					40,
					16
				],
				[
					36,
					0
				],
				[
					32,
					-12
				],
				[
					20,
					-20
				],
				[
					4,
					-16
				],
				[
					-4,
					-8
				],
				[
					-8,
					-4
				],
				[
					-12,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.189453125,
				0.3046875,
				0.3173828125,
				0.388671875,
				0.41796875,
				0.4375,
				0.453125,
				0.48828125,
				0.4970703125,
				0.5068359375,
				0.5068359375,
				0.4541015625,
				0.357421875,
				0.27734375,
				0.138671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 49,
			"versionNonce": 1534890973,
			"isDeleted": false,
			"id": "KMIFzjBa4QHM7gYsa2sBH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -436.29166666666765,
			"y": 816.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 52,
			"seed": 766848798,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					8
				],
				[
					-4,
					24
				],
				[
					0,
					40
				],
				[
					4,
					48
				],
				[
					8,
					52
				],
				[
					16,
					52
				],
				[
					24,
					52
				],
				[
					32,
					40
				],
				[
					36,
					28
				],
				[
					36,
					12
				],
				[
					36,
					8
				],
				[
					36,
					4
				],
				[
					32,
					4
				],
				[
					36,
					28
				],
				[
					36,
					40
				],
				[
					44,
					52
				],
				[
					48,
					52
				],
				[
					52,
					52
				],
				[
					60,
					48
				],
				[
					64,
					36
				],
				[
					64,
					24
				],
				[
					64,
					12
				],
				[
					64,
					4
				],
				[
					64,
					4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.16796875,
				0.2138671875,
				0.2998046875,
				0.33203125,
				0.345703125,
				0.353515625,
				0.359375,
				0.3603515625,
				0.361328125,
				0.3623046875,
				0.36328125,
				0.3662109375,
				0.3681640625,
				0.37109375,
				0.373046875,
				0.3740234375,
				0.3994140625,
				0.4189453125,
				0.447265625,
				0.4658203125,
				0.5029296875,
				0.5087890625,
				0.4931640625,
				0.392578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 44,
			"versionNonce": 388818035,
			"isDeleted": false,
			"id": "NlCJ5cd7v0I7YVVp2Prs6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -356.29166666666765,
			"y": 852.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 40,
			"seed": 585817730,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					0
				],
				[
					8,
					-8
				],
				[
					12,
					-8
				],
				[
					16,
					-12
				],
				[
					20,
					-4
				],
				[
					12,
					8
				],
				[
					8,
					20
				],
				[
					-4,
					28
				],
				[
					-8,
					28
				],
				[
					-12,
					28
				],
				[
					-12,
					24
				],
				[
					-4,
					24
				],
				[
					0,
					24
				],
				[
					12,
					24
				],
				[
					20,
					28
				],
				[
					24,
					28
				],
				[
					28,
					28
				],
				[
					32,
					28
				],
				[
					32,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.216796875,
				0.3642578125,
				0.41796875,
				0.4326171875,
				0.44921875,
				0.4619140625,
				0.4580078125,
				0.4677734375,
				0.4716796875,
				0.4794921875,
				0.47265625,
				0.4697265625,
				0.478515625,
				0.486328125,
				0.5,
				0.505859375,
				0.482421875,
				0.400390625,
				0.2978515625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1775767613,
			"isDeleted": false,
			"id": "Jc-2OFYnDTTxVvFcqdqkt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -256.29166666666765,
			"y": 848.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 43987906,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1669921875,
				0.4189453125,
				0.408203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1268637203,
			"isDeleted": false,
			"id": "7CMhYH8jpe_pgJHw4iUtX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -224.29166666666765,
			"y": 852.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 17708574,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					8,
					0
				],
				[
					8,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.251953125,
				0.3408203125,
				0.388671875,
				0.4580078125,
				0.4560546875,
				0.314453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 742719645,
			"isDeleted": false,
			"id": "CyU9FmjIxikH-sJTfjelQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -192.29166666666765,
			"y": 856.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 1234346846,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.1416015625,
				0.2890625,
				0.365234375,
				0.4443359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1727964083,
			"isDeleted": false,
			"id": "bMQctzbpS682QxOAHVHKK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -248.29166666666765,
			"y": 952.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 794690946,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0009765625,
				0.158203125,
				0.337890625,
				0.453125,
				0.4599609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 141878525,
			"isDeleted": false,
			"id": "cVK7dO14yroO-QU_ZTTj9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -232.29166666666765,
			"y": 988.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 12,
			"seed": 1469461634,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					12,
					-4
				],
				[
					12,
					0
				],
				[
					12,
					-4
				],
				[
					16,
					-8
				],
				[
					16,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.25390625,
				0.2919921875,
				0.322265625,
				0.4111328125,
				0.4208984375,
				0.4501953125,
				0.416015625,
				0.30859375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 292926803,
			"isDeleted": false,
			"id": "ZIsvXUkk1zbaqshjrzfvT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -196.29166666666765,
			"y": 996.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 920218370,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					0
				],
				[
					8,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0009765625,
				0.263671875,
				0.3447265625,
				0.40234375,
				0.33984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 837369181,
			"isDeleted": false,
			"id": "4O4NE8YW2isvZ7qaNLfoq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -88.29166666666765,
			"y": 952.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 16,
			"seed": 24304130,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-12
				],
				[
					8,
					-16
				],
				[
					8,
					-12
				],
				[
					12,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.037109375,
				0.2421875,
				0.29296875,
				0.3486328125,
				0.4423828125,
				0.4755859375,
				0.470703125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 710513395,
			"isDeleted": false,
			"id": "rDoqRsOWtnGEu2TkRHybu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -80.29166666666765,
			"y": 984.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 161503426,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2021484375,
				0.3984375,
				0.42578125,
				0.3505859375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1878231485,
			"isDeleted": false,
			"id": "ylvNcHhcyKh5pABVzh86f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -84.29166666666765,
			"y": 1016.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 1433724866,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.2236328125,
				0.2734375,
				0.3173828125,
				0.396484375,
				0.388671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 50,
			"versionNonce": 1647361171,
			"isDeleted": false,
			"id": "M950oVtROpFyGMwzaYoeY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -144.29166666666765,
			"y": 1048.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 60,
			"seed": 1338461790,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					8
				],
				[
					0,
					24
				],
				[
					4,
					36
				],
				[
					8,
					44
				],
				[
					16,
					56
				],
				[
					24,
					60
				],
				[
					28,
					60
				],
				[
					36,
					52
				],
				[
					44,
					40
				],
				[
					48,
					28
				],
				[
					48,
					16
				],
				[
					48,
					8
				],
				[
					44,
					4
				],
				[
					44,
					16
				],
				[
					44,
					28
				],
				[
					44,
					44
				],
				[
					48,
					52
				],
				[
					52,
					56
				],
				[
					60,
					56
				],
				[
					68,
					48
				],
				[
					76,
					40
				],
				[
					80,
					24
				],
				[
					80,
					12
				],
				[
					80,
					4
				],
				[
					80,
					4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1357421875,
				0.1826171875,
				0.2529296875,
				0.265625,
				0.2783203125,
				0.2900390625,
				0.298828125,
				0.3115234375,
				0.3193359375,
				0.3271484375,
				0.3330078125,
				0.33984375,
				0.361328125,
				0.3720703125,
				0.3896484375,
				0.3857421875,
				0.3857421875,
				0.38671875,
				0.3876953125,
				0.3984375,
				0.416015625,
				0.4267578125,
				0.4423828125,
				0.443359375,
				0.4052734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 48,
			"versionNonce": 599083549,
			"isDeleted": false,
			"id": "MfVTYlcDc6Iq4pP_3ePIZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -56.29166666666765,
			"y": 1092.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 36,
			"seed": 516436446,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					12
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					4,
					32
				],
				[
					8,
					28
				],
				[
					8,
					24
				],
				[
					8,
					12
				],
				[
					12,
					0
				],
				[
					16,
					-4
				],
				[
					20,
					-4
				],
				[
					24,
					8
				],
				[
					24,
					20
				],
				[
					24,
					24
				],
				[
					28,
					28
				],
				[
					36,
					4
				],
				[
					36,
					0
				],
				[
					44,
					-4
				],
				[
					52,
					4
				],
				[
					52,
					16
				],
				[
					56,
					20
				],
				[
					56,
					28
				],
				[
					56,
					32
				],
				[
					56,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2177734375,
				0.2626953125,
				0.2958984375,
				0.314453125,
				0.3193359375,
				0.3828125,
				0.3857421875,
				0.3935546875,
				0.4013671875,
				0.4130859375,
				0.443359375,
				0.4580078125,
				0.4599609375,
				0.4677734375,
				0.4755859375,
				0.484375,
				0.482421875,
				0.486328125,
				0.494140625,
				0.4951171875,
				0.4912109375,
				0.4375,
				0.1943359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 45,
			"versionNonce": 347189811,
			"isDeleted": false,
			"id": "NIr-ku6wJw2p_qV8t1wbt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -124.29166666666765,
			"y": 832.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 68,
			"seed": 104445406,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					8
				],
				[
					-8,
					16
				],
				[
					-8,
					28
				],
				[
					-4,
					40
				],
				[
					0,
					48
				],
				[
					12,
					48
				],
				[
					20,
					44
				],
				[
					32,
					40
				],
				[
					36,
					28
				],
				[
					40,
					20
				],
				[
					40,
					4
				],
				[
					28,
					-12
				],
				[
					20,
					-20
				],
				[
					12,
					-20
				],
				[
					4,
					-20
				],
				[
					-4,
					-12
				],
				[
					-8,
					-8
				],
				[
					-12,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.025390625,
				0.2236328125,
				0.3369140625,
				0.36328125,
				0.3935546875,
				0.40625,
				0.41015625,
				0.4091796875,
				0.41015625,
				0.4111328125,
				0.412109375,
				0.419921875,
				0.4296875,
				0.46484375,
				0.4814453125,
				0.48828125,
				0.494140625,
				0.466796875,
				0.439453125,
				0.1376953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 236977789,
			"isDeleted": false,
			"id": "Sddojr1wWvZaL8NjfGLqQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -384.29166666666765,
			"y": 932.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 12,
			"seed": 948520002,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.271484375,
				0.345703125,
				0.3564453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1656943571,
			"isDeleted": false,
			"id": "b_colTuuFXil9JJw1JUx6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -384.29166666666765,
			"y": 968.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 12,
			"seed": 839687582,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2724609375,
				0.3154296875,
				0.35546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1442129629,
			"isDeleted": false,
			"id": "O0Wm_Qx9ApB9WngGPBNZt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -388.29166666666765,
			"y": 992.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 1341063810,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0009765625,
				0.3095703125,
				0.330078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 44,
			"versionNonce": 209387891,
			"isDeleted": false,
			"id": "8FWK_dBJDFM-n5Rp07Uot",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -400.29166666666765,
			"y": 1052.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 68,
			"seed": 1497971138,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					0
				],
				[
					-4,
					4
				],
				[
					-8,
					20
				],
				[
					-4,
					32
				],
				[
					0,
					44
				],
				[
					8,
					52
				],
				[
					20,
					52
				],
				[
					28,
					44
				],
				[
					40,
					36
				],
				[
					44,
					24
				],
				[
					44,
					12
				],
				[
					36,
					-8
				],
				[
					24,
					-16
				],
				[
					16,
					-16
				],
				[
					8,
					-12
				],
				[
					0,
					-4
				],
				[
					-4,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.03515625,
				0.1494140625,
				0.21484375,
				0.27734375,
				0.2978515625,
				0.3115234375,
				0.318359375,
				0.32421875,
				0.33984375,
				0.365234375,
				0.3994140625,
				0.43359375,
				0.4619140625,
				0.4716796875,
				0.474609375,
				0.455078125,
				0.34765625,
				0.189453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1304838973,
			"isDeleted": false,
			"id": "97aj-6ZKOW1VPmIND9-dv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -316.29166666666765,
			"y": 1076.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 563418882,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0703125,
				0.3408203125,
				0.30859375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 186669843,
			"isDeleted": false,
			"id": "nFjsafMhzvxPRrMCWOAdC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -268.29166666666765,
			"y": 1068.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 4,
			"seed": 1453317854,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8,
					0
				],
				[
					12,
					-4
				],
				[
					20,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0537109375,
				0.1943359375,
				0.279296875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 2046088093,
			"isDeleted": false,
			"id": "zsJlTaE2YSML_6jPA6sZY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -220.29166666666765,
			"y": 1056.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 4,
			"seed": 1590127938,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					8,
					-4
				],
				[
					12,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0595703125,
				0.310546875,
				0.3876953125,
				0.3662109375,
				0.1494140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1797882035,
			"isDeleted": false,
			"id": "Bj1-gQaFcFy_qjDJZM3d_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -556.2916666666677,
			"y": 924.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 8,
			"seed": 1848491074,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.037109375,
				0.357421875,
				0.37890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1454528509,
			"isDeleted": false,
			"id": "a9voDLho5AL-7nCKlybs-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -564.2916666666677,
			"y": 956.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 1516587906,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-8
				],
				[
					4,
					-12
				],
				[
					4,
					-16
				],
				[
					4,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.3134765625,
				0.3388671875,
				0.34765625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 1715270227,
			"isDeleted": false,
			"id": "OvZ0IAiI4NZ2J2SVtOrFq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -564.2916666666677,
			"y": 972.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 432700034,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0302734375,
				0.29296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 42,
			"versionNonce": 1577078877,
			"isDeleted": false,
			"id": "lw98hipHHZYBbPYXC2Lk7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -592.2916666666677,
			"y": 1052.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 68,
			"seed": 1839421214,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					20
				],
				[
					4,
					28
				],
				[
					12,
					40
				],
				[
					20,
					44
				],
				[
					32,
					44
				],
				[
					44,
					40
				],
				[
					52,
					28
				],
				[
					56,
					16
				],
				[
					56,
					0
				],
				[
					52,
					-12
				],
				[
					40,
					-20
				],
				[
					28,
					-24
				],
				[
					16,
					-16
				],
				[
					12,
					-12
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.15234375,
				0.2431640625,
				0.2568359375,
				0.3056640625,
				0.3251953125,
				0.3427734375,
				0.3603515625,
				0.3896484375,
				0.4423828125,
				0.474609375,
				0.48828125,
				0.4970703125,
				0.4990234375,
				0.4638671875,
				0.40234375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1026633715,
			"isDeleted": false,
			"id": "AN1UCt_L4oXlsvcY-VVPr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -564.2916666666677,
			"y": 1004.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 1614457246,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					0
				],
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.16796875,
				0.3125,
				0.41796875,
				0.3203125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 49,
			"versionNonce": 1303395517,
			"isDeleted": false,
			"id": "0AI2w7w_ICuLHrDK8LgZy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -652.2916666666677,
			"y": 704.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 96,
			"height": 1152,
			"seed": 1483079170,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					-4,
					20
				],
				[
					-8,
					36
				],
				[
					-16,
					72
				],
				[
					-24,
					104
				],
				[
					-40,
					168
				],
				[
					-56,
					236
				],
				[
					-68,
					296
				],
				[
					-76,
					364
				],
				[
					-84,
					428
				],
				[
					-92,
					496
				],
				[
					-92,
					560
				],
				[
					-96,
					624
				],
				[
					-92,
					712
				],
				[
					-84,
					800
				],
				[
					-80,
					868
				],
				[
					-72,
					940
				],
				[
					-60,
					1004
				],
				[
					-52,
					1048
				],
				[
					-24,
					1140
				],
				[
					-16,
					1148
				],
				[
					-12,
					1152
				],
				[
					-8,
					1152
				],
				[
					-8,
					1148
				],
				[
					-8,
					1148
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.162109375,
				0.1953125,
				0.2373046875,
				0.275390625,
				0.2978515625,
				0.3408203125,
				0.3857421875,
				0.4345703125,
				0.46484375,
				0.4970703125,
				0.5185546875,
				0.5341796875,
				0.53125,
				0.537109375,
				0.5478515625,
				0.5478515625,
				0.5478515625,
				0.5615234375,
				0.568359375,
				0.5,
				0.43359375,
				0.3486328125,
				0.173828125,
				0.0322265625,
				0
			]
		},
		{
			"type": "line",
			"version": 130,
			"versionNonce": 1376565651,
			"isDeleted": false,
			"id": "AL9JAHk8dvsgojWBr-16i",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -708.2916666666677,
			"y": 1200.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1604,
			"height": 0,
			"seed": 749077086,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1604,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 85,
			"versionNonce": 761503005,
			"isDeleted": false,
			"id": "aD0pxcsMzWEsS_FdSWYTG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 79.70833333333235,
			"y": 620.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 1260,
			"seed": 563392478,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359182,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					1260
				]
			]
		},
		{
			"type": "freedraw",
			"version": 60,
			"versionNonce": 33951539,
			"isDeleted": false,
			"id": "1DMyE2NfFB1nWuy5yAuCS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 803.7083333333323,
			"y": 624.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 128,
			"height": 1320,
			"seed": 162182466,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-12
				],
				[
					76,
					200
				],
				[
					80,
					232
				],
				[
					100,
					372
				],
				[
					100,
					388
				],
				[
					112,
					496
				],
				[
					112,
					524
				],
				[
					116,
					540
				],
				[
					120,
					616
				],
				[
					124,
					716
				],
				[
					128,
					780
				],
				[
					124,
					848
				],
				[
					124,
					860
				],
				[
					124,
					872
				],
				[
					124,
					976
				],
				[
					124,
					1032
				],
				[
					124,
					1044
				],
				[
					124,
					1052
				],
				[
					124,
					1112
				],
				[
					124,
					1120
				],
				[
					124,
					1156
				],
				[
					124,
					1176
				],
				[
					124,
					1200
				],
				[
					124,
					1220
				],
				[
					124,
					1240
				],
				[
					124,
					1260
				],
				[
					124,
					1272
				],
				[
					120,
					1280
				],
				[
					120,
					1284
				],
				[
					120,
					1292
				],
				[
					120,
					1296
				],
				[
					120,
					1300
				],
				[
					120,
					1304
				],
				[
					120,
					1308
				],
				[
					116,
					1308
				],
				[
					116,
					1308
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1611328125,
				0.41796875,
				0.443359375,
				0.50390625,
				0.5107421875,
				0.5244140625,
				0.52734375,
				0.5244140625,
				0.5361328125,
				0.5283203125,
				0.53125,
				0.5205078125,
				0.52734375,
				0.525390625,
				0.5224609375,
				0.5263671875,
				0.5283203125,
				0.529296875,
				0.5234375,
				0.5244140625,
				0.521484375,
				0.525390625,
				0.5302734375,
				0.5380859375,
				0.5419921875,
				0.5302734375,
				0.5283203125,
				0.5224609375,
				0.5185546875,
				0.5029296875,
				0.50390625,
				0.5087890625,
				0.5234375,
				0.52734375,
				0.482421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 45,
			"versionNonce": 344715645,
			"isDeleted": false,
			"id": "63AtA6AaPlC_oTyalicy7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 143.70833333333235,
			"y": 668.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 96,
			"seed": 593404034,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					4,
					24
				],
				[
					4,
					36
				],
				[
					4,
					52
				],
				[
					4,
					68
				],
				[
					8,
					80
				],
				[
					8,
					88
				],
				[
					8,
					92
				],
				[
					8,
					96
				],
				[
					8,
					92
				],
				[
					16,
					76
				],
				[
					20,
					68
				],
				[
					36,
					36
				],
				[
					44,
					16
				],
				[
					44,
					12
				],
				[
					48,
					12
				],
				[
					48,
					8
				],
				[
					48,
					4
				],
				[
					48,
					0
				],
				[
					52,
					0
				],
				[
					52,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0029296875,
				0.13671875,
				0.1962890625,
				0.2236328125,
				0.2646484375,
				0.3134765625,
				0.3505859375,
				0.3671875,
				0.3818359375,
				0.4169921875,
				0.46484375,
				0.4609375,
				0.45703125,
				0.4365234375,
				0.4072265625,
				0.4013671875,
				0.3994140625,
				0.3955078125,
				0.3837890625,
				0.32421875,
				0.267578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1065595091,
			"isDeleted": false,
			"id": "6ImqpuHkpksGPHmoZPsvm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 179.70833333333235,
			"y": 724.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 36,
			"seed": 2112837826,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					0
				],
				[
					0,
					4
				],
				[
					4,
					8
				],
				[
					8,
					16
				],
				[
					12,
					20
				],
				[
					20,
					24
				],
				[
					24,
					28
				],
				[
					28,
					32
				],
				[
					28,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.28125,
				0.4423828125,
				0.478515625,
				0.501953125,
				0.5234375,
				0.5380859375,
				0.54296875,
				0.537109375,
				0.357421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 812300765,
			"isDeleted": false,
			"id": "2WAO64wr_0rFSv1cEtp3I",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 223.70833333333235,
			"y": 736.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 36,
			"seed": 1671061314,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					12
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					4,
					32
				],
				[
					8,
					36
				],
				[
					8,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0224609375,
				0.39453125,
				0.4619140625,
				0.494140625,
				0.505859375,
				0.474609375,
				0.3583984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1813782131,
			"isDeleted": false,
			"id": "paJ1zon4mmNm9dDLUBPSy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 251.70833333333235,
			"y": 736.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 48,
			"seed": 240307934,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-8,
					0
				],
				[
					-8,
					12
				],
				[
					-8,
					28
				],
				[
					-4,
					36
				],
				[
					0,
					40
				],
				[
					0,
					44
				],
				[
					0,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.03125,
				0.076171875,
				0.3193359375,
				0.4638671875,
				0.505859375,
				0.50390625,
				0.431640625,
				0.265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 168916541,
			"isDeleted": false,
			"id": "N9Okk8hDWW12_KZav3t4D",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 315.70833333333235,
			"y": 668.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 108,
			"seed": 1965016094,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					8
				],
				[
					0,
					32
				],
				[
					4,
					60
				],
				[
					4,
					76
				],
				[
					8,
					92
				],
				[
					8,
					96
				],
				[
					8,
					100
				],
				[
					8,
					104
				],
				[
					8,
					100
				],
				[
					24,
					60
				],
				[
					28,
					56
				],
				[
					32,
					52
				],
				[
					44,
					28
				],
				[
					48,
					24
				],
				[
					48,
					24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.078125,
				0.3115234375,
				0.3681640625,
				0.4287109375,
				0.4609375,
				0.4716796875,
				0.4716796875,
				0.482421875,
				0.4912109375,
				0.5166015625,
				0.4951171875,
				0.490234375,
				0.484375,
				0.33203125,
				0.1943359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 1922422803,
			"isDeleted": false,
			"id": "yUFZw9H9b2mGzU-bfTeMJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 351.70833333333235,
			"y": 704.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 68,
			"seed": 810603102,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					52
				],
				[
					-4,
					56
				],
				[
					0,
					60
				],
				[
					8,
					64
				],
				[
					12,
					68
				],
				[
					16,
					68
				],
				[
					16,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.02734375,
				0.4716796875,
				0.470703125,
				0.4736328125,
				0.439453125,
				0.353515625,
				0.2607421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 207726237,
			"isDeleted": false,
			"id": "up8kZmNmSAd1PvUyDlmbY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 387.70833333333235,
			"y": 752.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 60,
			"seed": 1525692802,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-20
				],
				[
					8,
					-24
				],
				[
					20,
					-32
				],
				[
					24,
					-16
				],
				[
					24,
					-12
				],
				[
					16,
					8
				],
				[
					-8,
					20
				],
				[
					-4,
					12
				],
				[
					8,
					12
				],
				[
					12,
					16
				],
				[
					28,
					24
				],
				[
					36,
					28
				],
				[
					36,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.22265625,
				0.2626953125,
				0.2890625,
				0.30078125,
				0.3486328125,
				0.4267578125,
				0.443359375,
				0.47265625,
				0.490234375,
				0.494140625,
				0.509765625,
				0.5068359375,
				0.427734375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 552033715,
			"isDeleted": false,
			"id": "YzLn0yBiI1k3YLKEt9I3C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 447.70833333333235,
			"y": 728.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 56,
			"seed": 1673763230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8,
					16
				],
				[
					8,
					20
				],
				[
					12,
					40
				],
				[
					12,
					48
				],
				[
					16,
					56
				],
				[
					16,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.5185546875,
				0.5361328125,
				0.5830078125,
				0.4951171875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 1242352381,
			"isDeleted": false,
			"id": "6ez-fNc364NeuCXMlumhU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 651.7083333333323,
			"y": 652.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 96,
			"seed": 2092096158,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					16
				],
				[
					0,
					40
				],
				[
					0,
					72
				],
				[
					0,
					84
				],
				[
					0,
					92
				],
				[
					0,
					96
				],
				[
					4,
					88
				],
				[
					12,
					76
				],
				[
					16,
					60
				],
				[
					28,
					44
				],
				[
					32,
					32
				],
				[
					40,
					20
				],
				[
					44,
					16
				],
				[
					44,
					16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.001953125,
				0.1630859375,
				0.2587890625,
				0.3115234375,
				0.353515625,
				0.41796875,
				0.4423828125,
				0.4677734375,
				0.4853515625,
				0.498046875,
				0.4970703125,
				0.49609375,
				0.48828125,
				0.4638671875,
				0.4052734375,
				0.3408203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1110912851,
			"isDeleted": false,
			"id": "GR_5JvFCukHlydHX4tbwD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 675.7083333333323,
			"y": 688.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 64,
			"seed": 1689163998,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					-8,
					20
				],
				[
					-8,
					28
				],
				[
					-8,
					40
				],
				[
					-4,
					52
				],
				[
					4,
					60
				],
				[
					16,
					64
				],
				[
					24,
					64
				],
				[
					28,
					64
				],
				[
					28,
					64
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0068359375,
				0.1611328125,
				0.2529296875,
				0.3056640625,
				0.388671875,
				0.4453125,
				0.458984375,
				0.427734375,
				0.3037109375,
				0.1611328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 38,
			"versionNonce": 60056413,
			"isDeleted": false,
			"id": "11NfXrFNikfio1hrxDdup",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 711.7083333333323,
			"y": 712.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 48,
			"seed": 9034334,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					16
				],
				[
					4,
					28
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					48
				],
				[
					4,
					44
				],
				[
					4,
					36
				],
				[
					4,
					20
				],
				[
					8,
					12
				],
				[
					12,
					8
				],
				[
					20,
					12
				],
				[
					24,
					24
				],
				[
					28,
					36
				],
				[
					32,
					44
				],
				[
					36,
					48
				],
				[
					36,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0322265625,
				0.26953125,
				0.3173828125,
				0.36328125,
				0.4033203125,
				0.4375,
				0.443359375,
				0.4580078125,
				0.466796875,
				0.462890625,
				0.451171875,
				0.4443359375,
				0.443359375,
				0.4638671875,
				0.4833984375,
				0.4970703125,
				0.4365234375,
				0.255859375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 2027670771,
			"isDeleted": false,
			"id": "MN0LsGPezBQiLgxxYbCfi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 767.7083333333323,
			"y": 728.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 44,
			"seed": 2129796318,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					8
				],
				[
					4,
					16
				],
				[
					8,
					32
				],
				[
					8,
					44
				],
				[
					8,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.3701171875,
				0.423828125,
				0.50390625,
				0.529296875,
				0.318359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1833562045,
			"isDeleted": false,
			"id": "9gN6EjAwkyKOucpaqcQD_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 123.70833333333235,
			"y": 848.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 96,
			"seed": 199605726,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					24
				],
				[
					0,
					56
				],
				[
					0,
					76
				],
				[
					4,
					84
				],
				[
					4,
					92
				],
				[
					12,
					80
				],
				[
					20,
					64
				],
				[
					28,
					40
				],
				[
					40,
					20
				],
				[
					48,
					4
				],
				[
					52,
					-4
				],
				[
					52,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0009765625,
				0.052734375,
				0.2890625,
				0.3583984375,
				0.4208984375,
				0.453125,
				0.462890625,
				0.4755859375,
				0.501953125,
				0.509765625,
				0.5,
				0.47265625,
				0.4033203125,
				0.283203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1482405523,
			"isDeleted": false,
			"id": "0KBIuxrotCVo5c9b9k3rW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 159.70833333333235,
			"y": 864.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 60,
			"seed": 1543733214,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					-8,
					24
				],
				[
					-8,
					40
				],
				[
					0,
					52
				],
				[
					8,
					56
				],
				[
					8,
					60
				],
				[
					16,
					60
				],
				[
					24,
					60
				],
				[
					24,
					60
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.140625,
				0.28515625,
				0.3896484375,
				0.4638671875,
				0.486328125,
				0.4892578125,
				0.4443359375,
				0.26171875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 894365725,
			"isDeleted": false,
			"id": "Lf5bCo5zEVFXUIlJq80lh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 215.70833333333235,
			"y": 888.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 52,
			"seed": 1145574338,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					0,
					20
				],
				[
					0,
					32
				],
				[
					0,
					40
				],
				[
					4,
					48
				],
				[
					4,
					52
				],
				[
					4,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.404296875,
				0.4521484375,
				0.5029296875,
				0.537109375,
				0.5439453125,
				0.486328125,
				0.3857421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 42,
			"versionNonce": 1064135731,
			"isDeleted": false,
			"id": "RCyExLAUtnC7-ZncfBlBH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 231.70833333333235,
			"y": 900.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 52,
			"seed": 1463384706,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-8
				],
				[
					4,
					-12
				],
				[
					12,
					-16
				],
				[
					16,
					-20
				],
				[
					24,
					-24
				],
				[
					28,
					-20
				],
				[
					32,
					-8
				],
				[
					32,
					0
				],
				[
					24,
					12
				],
				[
					16,
					20
				],
				[
					8,
					28
				],
				[
					4,
					28
				],
				[
					0,
					28
				],
				[
					4,
					28
				],
				[
					8,
					28
				],
				[
					20,
					28
				],
				[
					28,
					28
				],
				[
					40,
					28
				],
				[
					44,
					28
				],
				[
					48,
					28
				],
				[
					52,
					28
				],
				[
					52,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.1279296875,
				0.1494140625,
				0.2158203125,
				0.2431640625,
				0.3154296875,
				0.3662109375,
				0.42578125,
				0.4423828125,
				0.453125,
				0.4619140625,
				0.4736328125,
				0.4814453125,
				0.4970703125,
				0.5166015625,
				0.5166015625,
				0.509765625,
				0.513671875,
				0.509765625,
				0.4892578125,
				0.3720703125,
				0.1806640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 1234494589,
			"isDeleted": false,
			"id": "iLRXav7y2hCuWpcep0CEw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 363.70833333333235,
			"y": 852.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 84,
			"seed": 1217136514,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					0
				],
				[
					0,
					4
				],
				[
					0,
					24
				],
				[
					0,
					40
				],
				[
					0,
					56
				],
				[
					0,
					68
				],
				[
					0,
					76
				],
				[
					4,
					72
				],
				[
					8,
					56
				],
				[
					20,
					32
				],
				[
					28,
					16
				],
				[
					36,
					4
				],
				[
					40,
					-4
				],
				[
					44,
					-8
				],
				[
					44,
					-8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1025390625,
				0.30078125,
				0.3173828125,
				0.3935546875,
				0.4189453125,
				0.431640625,
				0.4443359375,
				0.4599609375,
				0.4775390625,
				0.4921875,
				0.4765625,
				0.462890625,
				0.4033203125,
				0.3427734375,
				0.2958984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1912040915,
			"isDeleted": false,
			"id": "VL0T0iHezXoY7Dx2Y9YyC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 391.70833333333235,
			"y": 864.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 72,
			"seed": 110552386,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					-4,
					20
				],
				[
					-4,
					32
				],
				[
					-4,
					40
				],
				[
					0,
					52
				],
				[
					8,
					64
				],
				[
					12,
					68
				],
				[
					20,
					72
				],
				[
					24,
					68
				],
				[
					24,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0029296875,
				0.2119140625,
				0.2978515625,
				0.3623046875,
				0.416015625,
				0.4462890625,
				0.46875,
				0.4521484375,
				0.37109375,
				0.1611328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 39,
			"versionNonce": 1574784221,
			"isDeleted": false,
			"id": "sqOOK9tLlq2Bbas9zWP4o",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 423.70833333333235,
			"y": 896.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 48,
			"seed": 2035190722,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-8
				],
				[
					12,
					-16
				],
				[
					16,
					-16
				],
				[
					20,
					-12
				],
				[
					24,
					-4
				],
				[
					20,
					12
				],
				[
					16,
					20
				],
				[
					8,
					28
				],
				[
					4,
					32
				],
				[
					-4,
					32
				],
				[
					-4,
					28
				],
				[
					0,
					28
				],
				[
					8,
					28
				],
				[
					20,
					32
				],
				[
					32,
					32
				],
				[
					40,
					32
				],
				[
					40,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1923828125,
				0.216796875,
				0.2294921875,
				0.271484375,
				0.3154296875,
				0.3310546875,
				0.3642578125,
				0.380859375,
				0.3896484375,
				0.3935546875,
				0.3935546875,
				0.400390625,
				0.3994140625,
				0.439453125,
				0.4501953125,
				0.4521484375,
				0.3310546875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 1930443635,
			"isDeleted": false,
			"id": "QBkaDYnUaZv7Or5TFqAfz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 467.70833333333235,
			"y": 888.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 56,
			"seed": 866913246,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					16,
					-8
				],
				[
					16,
					0
				],
				[
					16,
					12
				],
				[
					8,
					20
				],
				[
					4,
					28
				],
				[
					4,
					32
				],
				[
					0,
					36
				],
				[
					4,
					40
				],
				[
					12,
					40
				],
				[
					20,
					40
				],
				[
					28,
					44
				],
				[
					36,
					44
				],
				[
					40,
					44
				],
				[
					40,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0185546875,
				0.1103515625,
				0.1943359375,
				0.2568359375,
				0.3251953125,
				0.369140625,
				0.3896484375,
				0.41015625,
				0.42578125,
				0.4326171875,
				0.4482421875,
				0.4501953125,
				0.45703125,
				0.4541015625,
				0.4501953125,
				0.3837890625,
				0.1513671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 834251069,
			"isDeleted": false,
			"id": "W8CI797yTTeeCs1RPUoo9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 683.7083333333323,
			"y": 844.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 92,
			"seed": 872601282,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					24
				],
				[
					0,
					52
				],
				[
					0,
					68
				],
				[
					0,
					80
				],
				[
					0,
					84
				],
				[
					0,
					88
				],
				[
					4,
					84
				],
				[
					16,
					64
				],
				[
					28,
					48
				],
				[
					36,
					36
				],
				[
					44,
					24
				],
				[
					48,
					16
				],
				[
					52,
					16
				],
				[
					52,
					16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.142578125,
				0.2490234375,
				0.2880859375,
				0.3388671875,
				0.3828125,
				0.4052734375,
				0.421875,
				0.4326171875,
				0.4482421875,
				0.46484375,
				0.4677734375,
				0.46875,
				0.458984375,
				0.412109375,
				0.32421875,
				0.275390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 519984403,
			"isDeleted": false,
			"id": "U-9l3PjIr_fGSGweaCWeX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 719.7083333333323,
			"y": 868.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 64,
			"seed": 1589114014,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-12,
					24
				],
				[
					-12,
					32
				],
				[
					-12,
					48
				],
				[
					-8,
					56
				],
				[
					0,
					64
				],
				[
					8,
					64
				],
				[
					16,
					64
				],
				[
					16,
					64
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.03125,
				0.1669921875,
				0.2470703125,
				0.3095703125,
				0.3984375,
				0.42578125,
				0.4296875,
				0.35546875,
				0.1640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 39,
			"versionNonce": 378239389,
			"isDeleted": false,
			"id": "9OAC38eyeS0qx3uDr5eet",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 747.7083333333323,
			"y": 892.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 52,
			"seed": 591905538,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					40
				],
				[
					8,
					44
				],
				[
					8,
					48
				],
				[
					8,
					36
				],
				[
					8,
					24
				],
				[
					12,
					16
				],
				[
					16,
					12
				],
				[
					20,
					16
				],
				[
					24,
					20
				],
				[
					24,
					32
				],
				[
					28,
					36
				],
				[
					28,
					44
				],
				[
					32,
					44
				],
				[
					32,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.119140625,
				0.3017578125,
				0.392578125,
				0.4306640625,
				0.4443359375,
				0.44921875,
				0.4501953125,
				0.4541015625,
				0.4599609375,
				0.4658203125,
				0.4716796875,
				0.4765625,
				0.4814453125,
				0.4814453125,
				0.4765625,
				0.462890625,
				0.3134765625,
				0.19921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 39,
			"versionNonce": 87571123,
			"isDeleted": false,
			"id": "WZFtJ5zlbd9-Z9mPRmsQb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 783.7083333333323,
			"y": 908.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 64,
			"seed": 1827403934,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-8
				],
				[
					0,
					-12
				],
				[
					4,
					-16
				],
				[
					16,
					-16
				],
				[
					20,
					-12
				],
				[
					28,
					-4
				],
				[
					32,
					0
				],
				[
					28,
					12
				],
				[
					28,
					24
				],
				[
					24,
					28
				],
				[
					20,
					36
				],
				[
					20,
					40
				],
				[
					24,
					44
				],
				[
					28,
					44
				],
				[
					36,
					48
				],
				[
					44,
					48
				],
				[
					52,
					48
				],
				[
					56,
					48
				],
				[
					56,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.15625,
				0.2060546875,
				0.2822265625,
				0.3701171875,
				0.400390625,
				0.4140625,
				0.416015625,
				0.41015625,
				0.4091796875,
				0.4091796875,
				0.4189453125,
				0.4296875,
				0.4521484375,
				0.4560546875,
				0.45703125,
				0.4404296875,
				0.3369140625,
				0.146484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 897859069,
			"isDeleted": false,
			"id": "JepBW3lI_fS_SmgtV3qye",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 127.70833333333235,
			"y": 1068.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 84,
			"seed": 1759960514,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					4
				],
				[
					4,
					28
				],
				[
					4,
					48
				],
				[
					4,
					64
				],
				[
					8,
					72
				],
				[
					8,
					76
				],
				[
					8,
					80
				],
				[
					12,
					80
				],
				[
					20,
					64
				],
				[
					32,
					48
				],
				[
					44,
					28
				],
				[
					48,
					16
				],
				[
					52,
					12
				],
				[
					56,
					8
				],
				[
					56,
					8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0908203125,
				0.3203125,
				0.396484375,
				0.44140625,
				0.46875,
				0.4755859375,
				0.482421875,
				0.4921875,
				0.5146484375,
				0.51171875,
				0.5,
				0.47265625,
				0.400390625,
				0.3515625,
				0.2255859375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 40135763,
			"isDeleted": false,
			"id": "CurM0uf-XG-WLjtri04HA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 171.70833333333235,
			"y": 1084.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 64,
			"seed": 1142600578,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-12,
					28
				],
				[
					-12,
					32
				],
				[
					-12,
					40
				],
				[
					-12,
					52
				],
				[
					-4,
					60
				],
				[
					4,
					64
				],
				[
					8,
					64
				],
				[
					8,
					64
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.2841796875,
				0.3330078125,
				0.376953125,
				0.439453125,
				0.4462890625,
				0.3603515625,
				0.2822265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 363165277,
			"isDeleted": false,
			"id": "Z_f-v6wp7Igfep-yrEos5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 203.70833333333235,
			"y": 1104.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 40,
			"seed": 1487946306,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					12
				],
				[
					0,
					24
				],
				[
					0,
					32
				],
				[
					0,
					40
				],
				[
					4,
					40
				],
				[
					4,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0087890625,
				0.3408203125,
				0.3935546875,
				0.431640625,
				0.484375,
				0.49609375,
				0.435546875,
				0.3193359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 47,
			"versionNonce": 442067443,
			"isDeleted": false,
			"id": "s5zpKz2UMYGrJNlehtpAo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 231.70833333333235,
			"y": 1104.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 52,
			"seed": 1278515458,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					-4,
					20
				],
				[
					0,
					28
				],
				[
					0,
					36
				],
				[
					0,
					48
				],
				[
					0,
					52
				],
				[
					0,
					48
				],
				[
					0,
					32
				],
				[
					4,
					20
				],
				[
					8,
					16
				],
				[
					12,
					16
				],
				[
					20,
					24
				],
				[
					20,
					36
				],
				[
					24,
					40
				],
				[
					24,
					48
				],
				[
					24,
					52
				],
				[
					24,
					48
				],
				[
					28,
					32
				],
				[
					32,
					24
				],
				[
					32,
					20
				],
				[
					36,
					20
				],
				[
					44,
					32
				],
				[
					52,
					40
				],
				[
					56,
					48
				],
				[
					60,
					52
				],
				[
					60,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.140625,
				0.2392578125,
				0.2861328125,
				0.328125,
				0.3505859375,
				0.388671875,
				0.41015625,
				0.4345703125,
				0.4306640625,
				0.4287109375,
				0.431640625,
				0.4375,
				0.4541015625,
				0.4794921875,
				0.49609375,
				0.5078125,
				0.5166015625,
				0.533203125,
				0.52734375,
				0.5224609375,
				0.5224609375,
				0.5234375,
				0.5341796875,
				0.537109375,
				0.505859375,
				0.357421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 1640014525,
			"isDeleted": false,
			"id": "9IUFdfuo5QleaWRXM26FX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 367.70833333333235,
			"y": 1076.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 68,
			"seed": 1657652126,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					4,
					12
				],
				[
					4,
					32
				],
				[
					4,
					44
				],
				[
					4,
					56
				],
				[
					4,
					60
				],
				[
					4,
					64
				],
				[
					8,
					64
				],
				[
					12,
					56
				],
				[
					20,
					40
				],
				[
					32,
					24
				],
				[
					36,
					16
				],
				[
					44,
					4
				],
				[
					44,
					4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1416015625,
				0.31640625,
				0.3671875,
				0.4091796875,
				0.431640625,
				0.4619140625,
				0.4697265625,
				0.4833984375,
				0.50390625,
				0.5,
				0.490234375,
				0.474609375,
				0.4462890625,
				0.2890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 303936403,
			"isDeleted": false,
			"id": "GX9Z_8YkKgJhXgcnaYW0_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 407.70833333333235,
			"y": 1080.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 72,
			"seed": 56978242,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359183,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-12,
					24
				],
				[
					-12,
					36
				],
				[
					-8,
					52
				],
				[
					-4,
					60
				],
				[
					-4,
					64
				],
				[
					4,
					72
				],
				[
					8,
					72
				],
				[
					12,
					72
				],
				[
					12,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0068359375,
				0.1357421875,
				0.2978515625,
				0.3837890625,
				0.4296875,
				0.4580078125,
				0.46484375,
				0.39453125,
				0.3291015625,
				0.150390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 1853309725,
			"isDeleted": false,
			"id": "ZnFqsPcfmVUWbmGHKVO1i",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 427.70833333333235,
			"y": 1132.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 52,
			"seed": 654348738,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-16
				],
				[
					12,
					-16
				],
				[
					16,
					-8
				],
				[
					16,
					-4
				],
				[
					8,
					8
				],
				[
					-8,
					24
				],
				[
					-12,
					28
				],
				[
					16,
					32
				],
				[
					20,
					32
				],
				[
					24,
					36
				],
				[
					28,
					36
				],
				[
					32,
					36
				],
				[
					32,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.1328125,
				0.1884765625,
				0.232421875,
				0.2568359375,
				0.3076171875,
				0.357421875,
				0.3681640625,
				0.39453125,
				0.4111328125,
				0.4208984375,
				0.49609375,
				0.4951171875,
				0.4736328125,
				0.345703125,
				0.1640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 48,
			"versionNonce": 1239927091,
			"isDeleted": false,
			"id": "Iq2CtR7CjtmdZJsVRPaTG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 467.70833333333235,
			"y": 1116.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 36,
			"seed": 1600776066,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					4,
					24
				],
				[
					4,
					28
				],
				[
					4,
					32
				],
				[
					4,
					36
				],
				[
					0,
					36
				],
				[
					0,
					32
				],
				[
					4,
					20
				],
				[
					8,
					8
				],
				[
					12,
					4
				],
				[
					24,
					8
				],
				[
					24,
					16
				],
				[
					28,
					24
				],
				[
					28,
					32
				],
				[
					28,
					36
				],
				[
					28,
					32
				],
				[
					28,
					28
				],
				[
					32,
					16
				],
				[
					36,
					12
				],
				[
					40,
					12
				],
				[
					44,
					16
				],
				[
					48,
					20
				],
				[
					52,
					28
				],
				[
					52,
					32
				],
				[
					56,
					36
				],
				[
					56,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.03125,
				0.2392578125,
				0.3095703125,
				0.35546875,
				0.375,
				0.4091796875,
				0.4150390625,
				0.4365234375,
				0.4658203125,
				0.466796875,
				0.4580078125,
				0.455078125,
				0.4541015625,
				0.455078125,
				0.458984375,
				0.46484375,
				0.4716796875,
				0.4765625,
				0.4892578125,
				0.48828125,
				0.4765625,
				0.47265625,
				0.470703125,
				0.4833984375,
				0.4833984375,
				0.4990234375,
				0.4970703125,
				0.3935546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 3856253,
			"isDeleted": false,
			"id": "EyizrI8exJoCptsjLi22e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 707.7083333333323,
			"y": 1084.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 92,
			"seed": 782789570,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					28
				],
				[
					-4,
					48
				],
				[
					-4,
					60
				],
				[
					-4,
					72
				],
				[
					-4,
					76
				],
				[
					-4,
					80
				],
				[
					0,
					80
				],
				[
					8,
					64
				],
				[
					20,
					44
				],
				[
					28,
					24
				],
				[
					40,
					8
				],
				[
					44,
					0
				],
				[
					52,
					-8
				],
				[
					52,
					-12
				],
				[
					48,
					-12
				],
				[
					48,
					-12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2392578125,
				0.322265625,
				0.3701171875,
				0.3896484375,
				0.404296875,
				0.4072265625,
				0.421875,
				0.466796875,
				0.484375,
				0.474609375,
				0.4716796875,
				0.4638671875,
				0.4423828125,
				0.3271484375,
				0.2734375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1461594835,
			"isDeleted": false,
			"id": "076tQNqLl7-V27pqE04II",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 739.7083333333323,
			"y": 1088.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 68,
			"seed": 718786462,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-12,
					24
				],
				[
					-16,
					32
				],
				[
					-16,
					44
				],
				[
					-12,
					52
				],
				[
					-4,
					60
				],
				[
					4,
					68
				],
				[
					8,
					68
				],
				[
					16,
					68
				],
				[
					16,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.005859375,
				0.1591796875,
				0.2578125,
				0.3427734375,
				0.3994140625,
				0.439453125,
				0.4638671875,
				0.462890625,
				0.392578125,
				0.25390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 1363992541,
			"isDeleted": false,
			"id": "ULc_KTBPK3WkLpSJdWuQY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 763.7083333333323,
			"y": 1124.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 40,
			"seed": 2139816222,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					24
				],
				[
					0,
					32
				],
				[
					0,
					36
				],
				[
					4,
					40
				],
				[
					4,
					36
				],
				[
					4,
					20
				],
				[
					8,
					8
				],
				[
					8,
					4
				],
				[
					12,
					0
				],
				[
					16,
					4
				],
				[
					20,
					12
				],
				[
					24,
					24
				],
				[
					28,
					28
				],
				[
					28,
					32
				],
				[
					28,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0322265625,
				0.3251953125,
				0.35546875,
				0.4140625,
				0.43359375,
				0.4384765625,
				0.4462890625,
				0.4541015625,
				0.4501953125,
				0.4462890625,
				0.44921875,
				0.455078125,
				0.466796875,
				0.4892578125,
				0.4775390625,
				0.3876953125,
				0.3125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 46,
			"versionNonce": 1582782579,
			"isDeleted": false,
			"id": "dPHR5wIOltb1RUDVbwVlN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 799.7083333333323,
			"y": 1128.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 36,
			"seed": 1314405762,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					8
				],
				[
					8,
					20
				],
				[
					8,
					24
				],
				[
					8,
					28
				],
				[
					8,
					24
				],
				[
					8,
					16
				],
				[
					12,
					0
				],
				[
					16,
					-4
				],
				[
					20,
					-4
				],
				[
					24,
					4
				],
				[
					28,
					12
				],
				[
					28,
					20
				],
				[
					32,
					24
				],
				[
					32,
					16
				],
				[
					32,
					12
				],
				[
					32,
					4
				],
				[
					36,
					-4
				],
				[
					40,
					-8
				],
				[
					44,
					-4
				],
				[
					52,
					4
				],
				[
					56,
					12
				],
				[
					60,
					20
				],
				[
					60,
					28
				],
				[
					64,
					28
				],
				[
					64,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0068359375,
				0.3251953125,
				0.3955078125,
				0.439453125,
				0.443359375,
				0.4482421875,
				0.46875,
				0.462890625,
				0.4541015625,
				0.4501953125,
				0.4638671875,
				0.474609375,
				0.48828125,
				0.4951171875,
				0.501953125,
				0.486328125,
				0.482421875,
				0.4775390625,
				0.4736328125,
				0.4775390625,
				0.48828125,
				0.5048828125,
				0.5185546875,
				0.4970703125,
				0.40625,
				0.2861328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 1472126013,
			"isDeleted": false,
			"id": "VrzIXzziZVhAYiuThZoUY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 531.7083333333323,
			"y": 744.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 12,
			"seed": 1068175874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-4
				],
				[
					4,
					0
				],
				[
					0,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.02734375,
				0.3837890625,
				0.412109375,
				0.484375,
				0.513671875,
				0.3701171875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 760861203,
			"isDeleted": false,
			"id": "GFj719NEYCJRfTMg5_WJn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 563.7083333333323,
			"y": 740.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 940902430,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					-4
				],
				[
					8,
					0
				],
				[
					8,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.2158203125,
				0.37109375,
				0.4697265625,
				0.4736328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1265781917,
			"isDeleted": false,
			"id": "ZNRFIdqP1CxpxWlF9fcA4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 595.7083333333323,
			"y": 736.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 8,
			"seed": 127469854,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					12,
					-8
				],
				[
					12,
					-4
				],
				[
					12,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2080078125,
				0.326171875,
				0.361328125,
				0.4033203125,
				0.4404296875,
				0.1669921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 354162611,
			"isDeleted": false,
			"id": "hjh2UC16QHf672X_VM45-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 523.7083333333323,
			"y": 896.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 536450654,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					8,
					-8
				],
				[
					8,
					-4
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.40625,
				0.4599609375,
				0.5380859375,
				0.5390625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1813557501,
			"isDeleted": false,
			"id": "OGolvpKy83dYVkzuK75S2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 563.7083333333323,
			"y": 892.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 8,
			"seed": 1434957186,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					8,
					-8
				],
				[
					12,
					-8
				],
				[
					12,
					-4
				],
				[
					8,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.021484375,
				0.30078125,
				0.345703125,
				0.419921875,
				0.44921875,
				0.4140625,
				0.265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 63220051,
			"isDeleted": false,
			"id": "C3IJye8qXSf4VazcfIAf2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 603.7083333333323,
			"y": 888.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 8,
			"seed": 465306690,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					-4
				],
				[
					8,
					-8
				],
				[
					12,
					-8
				],
				[
					12,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.224609375,
				0.390625,
				0.4482421875,
				0.4677734375,
				0.326171875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 120818013,
			"isDeleted": false,
			"id": "mUR1W2KvdsItOeA0kr0iF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 543.7083333333323,
			"y": 1024.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 12,
			"seed": 802978270,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-8
				],
				[
					4,
					-12
				],
				[
					8,
					-12
				],
				[
					12,
					-12
				],
				[
					12,
					-8
				],
				[
					12,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.021484375,
				0.2900390625,
				0.4287109375,
				0.4833984375,
				0.4990234375,
				0.4267578125,
				0.2392578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 1588201203,
			"isDeleted": false,
			"id": "3rUvaqWSooNLOzEVjhk8x",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 571.7083333333323,
			"y": 1060.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 1950256926,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0048828125,
				0.29296875,
				0.3505859375,
				0.3916015625,
				0.259765625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 1041520061,
			"isDeleted": false,
			"id": "5aAzr7pX0bsK4AH7gLRvO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 599.7083333333323,
			"y": 1080.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 4,
			"seed": 726077470,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					12,
					0
				],
				[
					12,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.18359375,
				0.4208984375,
				0.439453125,
				0.4951171875,
				0.49609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 475181203,
			"isDeleted": false,
			"id": "1FgPPNPutMzw3DnsKVJ0T",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 763.7083333333323,
			"y": 972.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 1594136514,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0361328125,
				0.146484375,
				0.3466796875,
				0.5244140625,
				0.1875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 199005725,
			"isDeleted": false,
			"id": "esm8G7SzkDc1e53vcMNAf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 759.7083333333323,
			"y": 1008.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 12,
			"seed": 591505090,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					12,
					-12
				],
				[
					8,
					-8
				],
				[
					8,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0048828125,
				0.2822265625,
				0.404296875,
				0.4521484375,
				0.4677734375,
				0.3037109375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 510993971,
			"isDeleted": false,
			"id": "v_HVhJ-cj7zJjYXYOt-Uw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 763.7083333333323,
			"y": 1040.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 4,
			"seed": 685190530,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					8,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0244140625,
				0.373046875,
				0.4169921875,
				0.4921875,
				0.375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 192793213,
			"isDeleted": false,
			"id": "7krDOeyFiKKORo0SSvmOw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 447.70833333333235,
			"y": 968.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 1463508098,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.4462890625,
				0.3349609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 1274537939,
			"isDeleted": false,
			"id": "PNLnkNIXGKIseNVpiivZr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 447.70833333333235,
			"y": 992.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 8,
			"seed": 805032898,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.154296875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 2109305565,
			"isDeleted": false,
			"id": "Orfq59qYCEZdxEuk5phH3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 443.70833333333235,
			"y": 1044.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 310416130,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.4677734375,
				0.53125,
				0.158203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1794209139,
			"isDeleted": false,
			"id": "u_giRKRY7QvBmJDPT12ZL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 207.70833333333235,
			"y": 968.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 16,
			"seed": 514892510,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					4,
					-12
				],
				[
					8,
					-12
				],
				[
					8,
					-16
				],
				[
					8,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0439453125,
				0.2685546875,
				0.369140625,
				0.4501953125,
				0.4755859375,
				0.4501953125,
				0.146484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 253824829,
			"isDeleted": false,
			"id": "BVrqBwdCpNLfhUXP2kI9c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 215.70833333333235,
			"y": 996.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 1817778206,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.044921875,
				0.484375,
				0.5048828125,
				0.15625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 984108819,
			"isDeleted": false,
			"id": "hbDR0K6B8y0Nve6z_3fbJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 207.70833333333235,
			"y": 1036.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 914513922,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2607421875,
				0.3310546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 1578508189,
			"isDeleted": false,
			"id": "Lj6SiemmjVWbz5kCsDDbg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 223.70833333333235,
			"y": 1048.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 16,
			"seed": 279414594,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					-4
				],
				[
					-8,
					0
				],
				[
					-8,
					4
				],
				[
					-12,
					8
				],
				[
					-12,
					4
				],
				[
					-8,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					8
				],
				[
					-4,
					12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.1298828125,
				0.3720703125,
				0.4482421875,
				0.451171875,
				0.4853515625,
				0.494140625,
				0.49609375,
				0.4560546875,
				0.404296875,
				0.169921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1301476531,
			"isDeleted": false,
			"id": "C_q-l2usXlOxTVefHqKee",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -644.2916666666677,
			"y": 1260.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 92,
			"seed": 1212589442,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					16
				],
				[
					0,
					60
				],
				[
					0,
					76
				],
				[
					0,
					84
				],
				[
					4,
					84
				],
				[
					8,
					72
				],
				[
					20,
					44
				],
				[
					32,
					16
				],
				[
					32,
					12
				],
				[
					40,
					0
				],
				[
					44,
					-8
				],
				[
					48,
					-8
				],
				[
					48,
					-8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.302734375,
				0.35546875,
				0.37109375,
				0.380859375,
				0.392578125,
				0.41015625,
				0.423828125,
				0.42578125,
				0.42578125,
				0.3935546875,
				0.259765625,
				0.1748046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1086989309,
			"isDeleted": false,
			"id": "f9khrjyfuiG9ZbctgTTfY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -620.2916666666677,
			"y": 1272.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 60,
			"seed": 720030046,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					16
				],
				[
					-4,
					28
				],
				[
					0,
					36
				],
				[
					0,
					44
				],
				[
					4,
					52
				],
				[
					8,
					56
				],
				[
					8,
					60
				],
				[
					8,
					60
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.005859375,
				0.23046875,
				0.30859375,
				0.33984375,
				0.3564453125,
				0.35546875,
				0.3369140625,
				0.2333984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 592963155,
			"isDeleted": false,
			"id": "TPpfGdCzEI3f1z_UhRAwH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -584.2916666666677,
			"y": 1300.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 44,
			"seed": 1592471198,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					20
				],
				[
					0,
					28
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0234375,
				0.2861328125,
				0.373046875,
				0.3984375,
				0.388671875,
				0.34765625,
				0.248046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 1262394461,
			"isDeleted": false,
			"id": "fLHv1jpdZX-51iIYj0Km5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -560.2916666666677,
			"y": 1296.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 48,
			"seed": 1434902850,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					48
				],
				[
					4,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0107421875,
				0.228515625,
				0.3427734375,
				0.40625,
				0.43359375,
				0.4482421875,
				0.4384765625,
				0.38671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 47031283,
			"isDeleted": false,
			"id": "uNShoePRyX_sc1Y4rBXHv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -500.29166666666765,
			"y": 1260.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 80,
			"seed": 872929282,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					16
				],
				[
					4,
					32
				],
				[
					8,
					52
				],
				[
					8,
					72
				],
				[
					8,
					76
				],
				[
					8,
					80
				],
				[
					12,
					80
				],
				[
					16,
					68
				],
				[
					16,
					64
				],
				[
					24,
					44
				],
				[
					40,
					20
				],
				[
					40,
					16
				],
				[
					48,
					4
				],
				[
					52,
					0
				],
				[
					52,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.001953125,
				0.193359375,
				0.28515625,
				0.341796875,
				0.3935546875,
				0.4365234375,
				0.4482421875,
				0.455078125,
				0.482421875,
				0.49609375,
				0.49609375,
				0.4990234375,
				0.4365234375,
				0.4111328125,
				0.2734375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 356845757,
			"isDeleted": false,
			"id": "_X7kMovkyPbzBjaObcDE-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -460.29166666666765,
			"y": 1276.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 72,
			"seed": 1092363714,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					-8,
					24
				],
				[
					-8,
					40
				],
				[
					-8,
					52
				],
				[
					-4,
					64
				],
				[
					4,
					68
				],
				[
					8,
					72
				],
				[
					12,
					72
				],
				[
					12,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.2080078125,
				0.3427734375,
				0.421875,
				0.453125,
				0.48046875,
				0.44921875,
				0.322265625,
				0.1416015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 40,
			"versionNonce": 335195539,
			"isDeleted": false,
			"id": "WwqkexEaee2GXE4DZiwOw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -436.29166666666765,
			"y": 1328.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 52,
			"seed": 1379415198,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-12
				],
				[
					12,
					-20
				],
				[
					16,
					-24
				],
				[
					24,
					-24
				],
				[
					24,
					-20
				],
				[
					28,
					-16
				],
				[
					28,
					0
				],
				[
					20,
					12
				],
				[
					12,
					20
				],
				[
					8,
					24
				],
				[
					4,
					24
				],
				[
					4,
					20
				],
				[
					8,
					20
				],
				[
					16,
					20
				],
				[
					24,
					24
				],
				[
					32,
					28
				],
				[
					36,
					28
				],
				[
					44,
					28
				],
				[
					44,
					28
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.2041015625,
				0.251953125,
				0.294921875,
				0.3232421875,
				0.36328125,
				0.3779296875,
				0.40234375,
				0.4248046875,
				0.439453125,
				0.455078125,
				0.4580078125,
				0.4697265625,
				0.474609375,
				0.4833984375,
				0.486328125,
				0.48828125,
				0.4736328125,
				0.388671875,
				0.244140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1082059037,
			"isDeleted": false,
			"id": "jJvChA2uUn5vxGK1Hh4LV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -372.29166666666765,
			"y": 1312.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 44,
			"seed": 1085936478,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.1748046875,
				0.48046875,
				0.513671875,
				0.55859375,
				0.5751953125,
				0.529296875,
				0.47265625,
				0.3447265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 974488371,
			"isDeleted": false,
			"id": "Nx1Sx14ctgxOeO4Srh0yG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -176.29166666666765,
			"y": 1248.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 84,
			"seed": 914860098,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					12
				],
				[
					4,
					32
				],
				[
					8,
					60
				],
				[
					12,
					76
				],
				[
					12,
					84
				],
				[
					16,
					84
				],
				[
					20,
					80
				],
				[
					28,
					64
				],
				[
					40,
					40
				],
				[
					56,
					8
				],
				[
					60,
					4
				],
				[
					64,
					0
				],
				[
					64,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0185546875,
				0.263671875,
				0.3212890625,
				0.376953125,
				0.4228515625,
				0.439453125,
				0.443359375,
				0.451171875,
				0.4541015625,
				0.4609375,
				0.4677734375,
				0.4169921875,
				0.369140625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1046330749,
			"isDeleted": false,
			"id": "tLTo3u3GiHcko6qloGMbP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -124.29166666666765,
			"y": 1260.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 68,
			"seed": 1409926722,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					64
				],
				[
					4,
					68
				],
				[
					12,
					68
				],
				[
					16,
					68
				],
				[
					16,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0068359375,
				0.447265625,
				0.3876953125,
				0.2236328125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 38,
			"versionNonce": 763667667,
			"isDeleted": false,
			"id": "Aj6m2VkG_i8N7qlG0DQ0f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -88.29166666666765,
			"y": 1284.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 56,
			"seed": 694811550,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					16
				],
				[
					-4,
					32
				],
				[
					0,
					44
				],
				[
					0,
					52
				],
				[
					0,
					56
				],
				[
					0,
					52
				],
				[
					0,
					44
				],
				[
					4,
					32
				],
				[
					4,
					16
				],
				[
					8,
					12
				],
				[
					16,
					12
				],
				[
					20,
					24
				],
				[
					28,
					36
				],
				[
					32,
					48
				],
				[
					36,
					52
				],
				[
					36,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0419921875,
				0.169921875,
				0.302734375,
				0.408203125,
				0.4501953125,
				0.4658203125,
				0.474609375,
				0.4677734375,
				0.4736328125,
				0.4755859375,
				0.478515625,
				0.4794921875,
				0.482421875,
				0.50390625,
				0.513671875,
				0.515625,
				0.45703125,
				0.2958984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 1445135837,
			"isDeleted": false,
			"id": "sJpZs8QpqrDMY3XpOKxlx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -32.29166666666765,
			"y": 1296.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 44,
			"seed": 1507175966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					4,
					28
				],
				[
					4,
					32
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.068359375,
				0.470703125,
				0.5126953125,
				0.5234375,
				0.515625,
				0.40234375,
				0.181640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1440649843,
			"isDeleted": false,
			"id": "m8c8Plamu2TIy1A3M6IX-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -664.2916666666677,
			"y": 1428.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 96,
			"seed": 948296130,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					4,
					48
				],
				[
					8,
					76
				],
				[
					8,
					80
				],
				[
					12,
					88
				],
				[
					12,
					96
				],
				[
					16,
					92
				],
				[
					20,
					72
				],
				[
					28,
					52
				],
				[
					44,
					20
				],
				[
					52,
					12
				],
				[
					52,
					8
				],
				[
					52,
					8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.2236328125,
				0.32421875,
				0.3857421875,
				0.392578125,
				0.4052734375,
				0.423828125,
				0.447265625,
				0.4443359375,
				0.4443359375,
				0.3935546875,
				0.2587890625,
				0.115234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 1793081917,
			"isDeleted": false,
			"id": "c9PPm_1p2NH9OypDK0HHj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -632.2916666666677,
			"y": 1456.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 60,
			"seed": 805253406,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					20
				],
				[
					-4,
					28
				],
				[
					-4,
					40
				],
				[
					0,
					48
				],
				[
					8,
					52
				],
				[
					12,
					56
				],
				[
					16,
					60
				],
				[
					20,
					60
				],
				[
					20,
					60
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.224609375,
				0.302734375,
				0.36328125,
				0.3857421875,
				0.39453125,
				0.359375,
				0.314453125,
				0.1494140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 1676266515,
			"isDeleted": false,
			"id": "w4Td0904iRF4oU7L0esqi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -592.2916666666677,
			"y": 1484.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 52,
			"seed": 1947295362,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					0,
					28
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					8,
					52
				],
				[
					8,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.3271484375,
				0.4130859375,
				0.4599609375,
				0.4765625,
				0.4208984375,
				0.2666015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 24572573,
			"isDeleted": false,
			"id": "wDs1HxoRcYguNBbvMXQqV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -576.2916666666677,
			"y": 1496.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 56,
			"seed": 644744094,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					16,
					-16
				],
				[
					24,
					-12
				],
				[
					32,
					-4
				],
				[
					32,
					4
				],
				[
					32,
					16
				],
				[
					28,
					24
				],
				[
					28,
					28
				],
				[
					28,
					32
				],
				[
					32,
					36
				],
				[
					36,
					40
				],
				[
					40,
					36
				],
				[
					48,
					36
				],
				[
					48,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.095703125,
				0.1484375,
				0.2470703125,
				0.2998046875,
				0.34765625,
				0.3857421875,
				0.4248046875,
				0.4638671875,
				0.4765625,
				0.4990234375,
				0.5078125,
				0.5087890625,
				0.451171875,
				0.322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 731697587,
			"isDeleted": false,
			"id": "4peI1OdetZR9WqipsZSql",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -676.2916666666677,
			"y": 1640.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 104,
			"seed": 1764305730,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					4,
					44
				],
				[
					8,
					60
				],
				[
					8,
					84
				],
				[
					12,
					92
				],
				[
					12,
					100
				],
				[
					16,
					100
				],
				[
					20,
					84
				],
				[
					28,
					64
				],
				[
					36,
					40
				],
				[
					44,
					20
				],
				[
					52,
					8
				],
				[
					52,
					4
				],
				[
					56,
					0
				],
				[
					56,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0830078125,
				0.2646484375,
				0.3251953125,
				0.3818359375,
				0.40625,
				0.4296875,
				0.4384765625,
				0.45703125,
				0.4599609375,
				0.4658203125,
				0.4736328125,
				0.4775390625,
				0.4521484375,
				0.3701171875,
				0.287109375,
				0.2197265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 110663421,
			"isDeleted": false,
			"id": "0UFQZnf-VAsUI3syGFBx4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -640.2916666666677,
			"y": 1660.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 72,
			"seed": 2069968926,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					16
				],
				[
					-4,
					20
				],
				[
					-4,
					32
				],
				[
					-4,
					48
				],
				[
					0,
					60
				],
				[
					4,
					68
				],
				[
					12,
					72
				],
				[
					16,
					72
				],
				[
					20,
					68
				],
				[
					20,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.185546875,
				0.21484375,
				0.294921875,
				0.3583984375,
				0.3779296875,
				0.3935546875,
				0.3583984375,
				0.3134765625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 1042162515,
			"isDeleted": false,
			"id": "-94GXUiDpLiYPUKHuhzco",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -608.2916666666677,
			"y": 1696.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 48,
			"seed": 420219294,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					0,
					20
				],
				[
					4,
					32
				],
				[
					4,
					40
				],
				[
					8,
					48
				],
				[
					8,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.2216796875,
				0.29296875,
				0.337890625,
				0.359375,
				0.3671875,
				0.2685546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 45,
			"versionNonce": 1422307165,
			"isDeleted": false,
			"id": "8QGLU19gHUCTHkco9YsZR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -584.2916666666677,
			"y": 1692.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 48,
			"seed": 1583527490,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					8,
					32
				],
				[
					8,
					40
				],
				[
					8,
					48
				],
				[
					4,
					44
				],
				[
					4,
					36
				],
				[
					4,
					24
				],
				[
					8,
					12
				],
				[
					12,
					8
				],
				[
					20,
					8
				],
				[
					28,
					24
				],
				[
					32,
					32
				],
				[
					36,
					40
				],
				[
					36,
					44
				],
				[
					32,
					40
				],
				[
					36,
					24
				],
				[
					40,
					8
				],
				[
					48,
					8
				],
				[
					56,
					12
				],
				[
					56,
					16
				],
				[
					64,
					24
				],
				[
					64,
					32
				],
				[
					68,
					40
				],
				[
					68,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0322265625,
				0.240234375,
				0.2880859375,
				0.3212890625,
				0.3349609375,
				0.3623046875,
				0.3740234375,
				0.37890625,
				0.3798828125,
				0.38671875,
				0.3955078125,
				0.3955078125,
				0.3935546875,
				0.3994140625,
				0.4130859375,
				0.419921875,
				0.427734375,
				0.4326171875,
				0.4384765625,
				0.4453125,
				0.44921875,
				0.4501953125,
				0.4501953125,
				0.427734375,
				0.2578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1136935155,
			"isDeleted": false,
			"id": "LU4c7V4tOdPAoChbByPtI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -476.29166666666765,
			"y": 1448.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 92,
			"seed": 2045361694,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					4,
					28
				],
				[
					8,
					44
				],
				[
					8,
					68
				],
				[
					8,
					80
				],
				[
					12,
					84
				],
				[
					12,
					80
				],
				[
					16,
					64
				],
				[
					28,
					36
				],
				[
					36,
					16
				],
				[
					44,
					4
				],
				[
					48,
					-4
				],
				[
					52,
					-8
				],
				[
					52,
					-8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.2373046875,
				0.318359375,
				0.353515625,
				0.396484375,
				0.4140625,
				0.421875,
				0.4453125,
				0.4453125,
				0.4365234375,
				0.435546875,
				0.4072265625,
				0.34375,
				0.185546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 2052242365,
			"isDeleted": false,
			"id": "2IRJtHDJ9WlXU2sIzZg0d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -432.29166666666765,
			"y": 1452.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 72,
			"seed": 1104363550,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					20
				],
				[
					-12,
					28
				],
				[
					-12,
					40
				],
				[
					-8,
					56
				],
				[
					0,
					64
				],
				[
					4,
					68
				],
				[
					8,
					72
				],
				[
					16,
					72
				],
				[
					16,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0341796875,
				0.1796875,
				0.2568359375,
				0.32421875,
				0.4013671875,
				0.427734375,
				0.4326171875,
				0.4169921875,
				0.2333984375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 370518675,
			"isDeleted": false,
			"id": "bEboraC0ntfDc_tDYj6hn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -412.29166666666765,
			"y": 1496.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 48,
			"seed": 137174914,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					16,
					-16
				],
				[
					20,
					-12
				],
				[
					20,
					-4
				],
				[
					20,
					12
				],
				[
					16,
					24
				],
				[
					16,
					28
				],
				[
					16,
					32
				],
				[
					20,
					32
				],
				[
					28,
					28
				],
				[
					36,
					24
				],
				[
					36,
					24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1865234375,
				0.25390625,
				0.287109375,
				0.322265625,
				0.345703125,
				0.388671875,
				0.4140625,
				0.4462890625,
				0.462890625,
				0.4697265625,
				0.4736328125,
				0.369140625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 1063140381,
			"isDeleted": false,
			"id": "X4DTEDUEpiA9OGnjjgGc1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -372.29166666666765,
			"y": 1484.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 56,
			"seed": 1532231042,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					8,
					-12
				],
				[
					12,
					-16
				],
				[
					20,
					-12
				],
				[
					24,
					-4
				],
				[
					24,
					8
				],
				[
					20,
					20
				],
				[
					20,
					28
				],
				[
					20,
					32
				],
				[
					20,
					36
				],
				[
					24,
					40
				],
				[
					32,
					40
				],
				[
					40,
					40
				],
				[
					44,
					36
				],
				[
					48,
					36
				],
				[
					48,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.171875,
				0.208984375,
				0.259765625,
				0.310546875,
				0.34765625,
				0.373046875,
				0.3974609375,
				0.4248046875,
				0.4482421875,
				0.4697265625,
				0.4775390625,
				0.4853515625,
				0.4716796875,
				0.3818359375,
				0.23046875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 432594995,
			"isDeleted": false,
			"id": "DBZ8QcPT7WqZLB4pEjSC9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -460.29166666666765,
			"y": 1644.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 108,
			"seed": 1749038302,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					12
				],
				[
					-4,
					44
				],
				[
					-4,
					72
				],
				[
					0,
					92
				],
				[
					0,
					96
				],
				[
					0,
					104
				],
				[
					8,
					88
				],
				[
					16,
					64
				],
				[
					28,
					40
				],
				[
					40,
					24
				],
				[
					44,
					16
				],
				[
					48,
					12
				],
				[
					48,
					12
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.041015625,
				0.30859375,
				0.365234375,
				0.388671875,
				0.412109375,
				0.4169921875,
				0.4404296875,
				0.4580078125,
				0.4580078125,
				0.4677734375,
				0.451171875,
				0.4033203125,
				0.3095703125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1809494141,
			"isDeleted": false,
			"id": "o9kKuSoEO_ezuB3w01db2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -432.29166666666765,
			"y": 1672.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 84,
			"seed": 1832318686,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-16,
					36
				],
				[
					-12,
					56
				],
				[
					-8,
					68
				],
				[
					0,
					80
				],
				[
					8,
					84
				],
				[
					16,
					84
				],
				[
					20,
					84
				],
				[
					20,
					84
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2802734375,
				0.3681640625,
				0.4013671875,
				0.41796875,
				0.38671875,
				0.248046875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 1489265107,
			"isDeleted": false,
			"id": "3DPz5u8V21-XnshYj1K3C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -400.29166666666765,
			"y": 1732.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 72,
			"seed": 946531358,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					12,
					-24
				],
				[
					16,
					-20
				],
				[
					16,
					4
				],
				[
					16,
					8
				],
				[
					12,
					16
				],
				[
					4,
					28
				],
				[
					0,
					32
				],
				[
					-4,
					32
				],
				[
					-4,
					28
				],
				[
					0,
					28
				],
				[
					8,
					28
				],
				[
					16,
					32
				],
				[
					28,
					40
				],
				[
					32,
					44
				],
				[
					36,
					48
				],
				[
					36,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2734375,
				0.3251953125,
				0.3662109375,
				0.3642578125,
				0.3701171875,
				0.392578125,
				0.404296875,
				0.4208984375,
				0.421875,
				0.431640625,
				0.455078125,
				0.462890625,
				0.46875,
				0.416015625,
				0.2666015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 39,
			"versionNonce": 1300863197,
			"isDeleted": false,
			"id": "0HJWCymLhOEoBb_ClADSP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -348.29166666666765,
			"y": 1720.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 48,
			"seed": 156170846,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					20
				],
				[
					0,
					32
				],
				[
					0,
					40
				],
				[
					0,
					44
				],
				[
					0,
					48
				],
				[
					0,
					36
				],
				[
					0,
					24
				],
				[
					4,
					16
				],
				[
					4,
					12
				],
				[
					12,
					16
				],
				[
					16,
					24
				],
				[
					20,
					32
				],
				[
					20,
					40
				],
				[
					24,
					40
				],
				[
					24,
					32
				],
				[
					28,
					20
				],
				[
					36,
					12
				],
				[
					52,
					32
				],
				[
					56,
					40
				],
				[
					56,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.220703125,
				0.26171875,
				0.322265625,
				0.3701171875,
				0.3896484375,
				0.408203125,
				0.427734375,
				0.4423828125,
				0.443359375,
				0.4453125,
				0.4453125,
				0.4462890625,
				0.451171875,
				0.453125,
				0.4541015625,
				0.45703125,
				0.4501953125,
				0.4521484375,
				0.4541015625,
				0.458984375,
				0.37109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 41,
			"versionNonce": 1545514867,
			"isDeleted": false,
			"id": "9mXbzVX7sKphHeafolBSN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -180.29166666666765,
			"y": 1676.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76,
			"height": 108,
			"seed": 1580211550,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					4,
					32
				],
				[
					8,
					64
				],
				[
					12,
					88
				],
				[
					12,
					100
				],
				[
					12,
					108
				],
				[
					16,
					100
				],
				[
					24,
					72
				],
				[
					32,
					52
				],
				[
					44,
					32
				],
				[
					48,
					20
				],
				[
					52,
					16
				],
				[
					48,
					20
				],
				[
					40,
					32
				],
				[
					36,
					52
				],
				[
					36,
					72
				],
				[
					36,
					84
				],
				[
					44,
					92
				],
				[
					56,
					100
				],
				[
					64,
					100
				],
				[
					72,
					100
				],
				[
					76,
					96
				],
				[
					76,
					96
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.02734375,
				0.2958984375,
				0.3251953125,
				0.3671875,
				0.412109375,
				0.4384765625,
				0.443359375,
				0.466796875,
				0.466796875,
				0.46484375,
				0.4619140625,
				0.435546875,
				0.3583984375,
				0.3125,
				0.1611328125,
				0.22265625,
				0.298828125,
				0.373046875,
				0.4130859375,
				0.44140625,
				0.4287109375,
				0.3623046875,
				0.2138671875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 2113697085,
			"isDeleted": false,
			"id": "V7Cc8mGSCxFo_tVGFWTiu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -100.29166666666765,
			"y": 1732.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 56,
			"seed": 1851327646,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					0,
					28
				],
				[
					0,
					44
				],
				[
					0,
					52
				],
				[
					0,
					56
				],
				[
					0,
					52
				],
				[
					0,
					40
				],
				[
					4,
					16
				],
				[
					12,
					16
				],
				[
					20,
					32
				],
				[
					24,
					40
				],
				[
					24,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2646484375,
				0.2998046875,
				0.36328125,
				0.388671875,
				0.3974609375,
				0.41015625,
				0.416015625,
				0.4072265625,
				0.3984375,
				0.4150390625,
				0.400390625,
				0.26953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 1176389907,
			"isDeleted": false,
			"id": "nIJvCAbf6zQPY-S1C5STe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -60.29166666666765,
			"y": 1736.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 48,
			"seed": 1968593538,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					4,
					32
				],
				[
					4,
					44
				],
				[
					4,
					48
				],
				[
					4,
					44
				],
				[
					4,
					28
				],
				[
					8,
					12
				],
				[
					12,
					8
				],
				[
					16,
					12
				],
				[
					24,
					20
				],
				[
					24,
					32
				],
				[
					28,
					40
				],
				[
					24,
					28
				],
				[
					32,
					8
				],
				[
					48,
					20
				],
				[
					48,
					24
				],
				[
					56,
					36
				],
				[
					56,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.029296875,
				0.294921875,
				0.361328125,
				0.384765625,
				0.41015625,
				0.4287109375,
				0.4541015625,
				0.451171875,
				0.451171875,
				0.4462890625,
				0.4462890625,
				0.44921875,
				0.4521484375,
				0.453125,
				0.44921875,
				0.4384765625,
				0.4453125,
				0.443359375,
				0.2783203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 39,
			"versionNonce": 1754580381,
			"isDeleted": false,
			"id": "N0H5mILcXSVhGNrvYfSJI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -184.29166666666765,
			"y": 1404.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 72,
			"height": 104,
			"seed": 2099116318,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					4,
					28
				],
				[
					4,
					44
				],
				[
					8,
					72
				],
				[
					8,
					84
				],
				[
					12,
					100
				],
				[
					12,
					104
				],
				[
					16,
					96
				],
				[
					20,
					76
				],
				[
					28,
					56
				],
				[
					36,
					36
				],
				[
					44,
					20
				],
				[
					48,
					20
				],
				[
					44,
					24
				],
				[
					40,
					40
				],
				[
					36,
					60
				],
				[
					36,
					76
				],
				[
					48,
					88
				],
				[
					56,
					92
				],
				[
					64,
					92
				],
				[
					72,
					92
				],
				[
					72,
					92
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.158203125,
				0.2421875,
				0.2900390625,
				0.3486328125,
				0.3828125,
				0.412109375,
				0.443359375,
				0.478515625,
				0.48046875,
				0.4794921875,
				0.4560546875,
				0.3486328125,
				0.302734375,
				0.25,
				0.2802734375,
				0.3466796875,
				0.404296875,
				0.4404296875,
				0.435546875,
				0.3544921875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 741977779,
			"isDeleted": false,
			"id": "uH8mTb1-1nXj4hWCY3DgZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -104.29166666666765,
			"y": 1448.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 60,
			"seed": 1670315038,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					16
				],
				[
					8,
					36
				],
				[
					8,
					48
				],
				[
					12,
					52
				],
				[
					12,
					60
				],
				[
					12,
					56
				],
				[
					12,
					52
				],
				[
					12,
					36
				],
				[
					12,
					20
				],
				[
					16,
					12
				],
				[
					20,
					12
				],
				[
					28,
					16
				],
				[
					36,
					32
				],
				[
					40,
					44
				],
				[
					44,
					52
				],
				[
					48,
					56
				],
				[
					48,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.21875,
				0.3173828125,
				0.3955078125,
				0.416015625,
				0.4248046875,
				0.4326171875,
				0.43359375,
				0.43359375,
				0.421875,
				0.4140625,
				0.4169921875,
				0.4345703125,
				0.44140625,
				0.4619140625,
				0.4501953125,
				0.3828125,
				0.1611328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 277088765,
			"isDeleted": false,
			"id": "QJfLDdjFuJ_EYc6qd_ycj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -48.29166666666765,
			"y": 1468.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 64,
			"seed": 1758203550,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-12
				],
				[
					8,
					-16
				],
				[
					20,
					-16
				],
				[
					28,
					-8
				],
				[
					32,
					-4
				],
				[
					28,
					12
				],
				[
					24,
					24
				],
				[
					24,
					32
				],
				[
					20,
					40
				],
				[
					24,
					44
				],
				[
					28,
					48
				],
				[
					40,
					48
				],
				[
					48,
					44
				],
				[
					56,
					44
				],
				[
					56,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.169921875,
				0.2255859375,
				0.3125,
				0.349609375,
				0.4443359375,
				0.46875,
				0.4697265625,
				0.4853515625,
				0.501953125,
				0.5068359375,
				0.5244140625,
				0.5302734375,
				0.533203125,
				0.5078125,
				0.4404296875,
				0.296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 823615571,
			"isDeleted": false,
			"id": "rCDB3P0kX6QMZaiFUWGQe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -300.29166666666765,
			"y": 1308.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 425785346,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-12
				],
				[
					8,
					-12
				],
				[
					8,
					-8
				],
				[
					8,
					-4
				],
				[
					8,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3037109375,
				0.353515625,
				0.4365234375,
				0.5234375,
				0.5361328125,
				0.54296875,
				0.5146484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 382452317,
			"isDeleted": false,
			"id": "JtzZDn1QvYq6rJRPWhh1V",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -256.29166666666765,
			"y": 1308.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 1959890526,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					0
				],
				[
					4,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3173828125,
				0.4169921875,
				0.236328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 1586355699,
			"isDeleted": false,
			"id": "hHavOL1RLH6vRuojWvQG8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -240.29166666666765,
			"y": 1308.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 2133935554,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-8
				],
				[
					8,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1279296875,
				0.322265625,
				0.408203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 4026045,
			"isDeleted": false,
			"id": "wZVWAtQ-FUjuCvaLfFB4m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -308.29166666666765,
			"y": 1484.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 16,
			"seed": 1307640862,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-12
				],
				[
					8,
					-16
				],
				[
					12,
					-16
				],
				[
					12,
					-12
				],
				[
					12,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.4375,
				0.4794921875,
				0.49609375,
				0.5234375,
				0.5205078125,
				0.3603515625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1067689875,
			"isDeleted": false,
			"id": "zVni-_Hh2SHWQQDjGdtpB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -284.29166666666765,
			"y": 1484.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 8,
			"seed": 1760866654,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					-4
				],
				[
					12,
					-8
				],
				[
					16,
					-8
				],
				[
					16,
					-4
				],
				[
					16,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.044921875,
				0.173828125,
				0.2744140625,
				0.3916015625,
				0.375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 997887773,
			"isDeleted": false,
			"id": "6xBhJtYXHQNaq3XOzWrRI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -256.29166666666765,
			"y": 1492.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 8,
			"seed": 298063518,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					8,
					-8
				],
				[
					12,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1455078125,
				0.236328125,
				0.3330078125,
				0.4580078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 982465843,
			"isDeleted": false,
			"id": "JG2OmkDse2v-gJmy5Is9t",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -84.29166666666765,
			"y": 1516.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 16,
			"seed": 739039134,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					4,
					-12
				],
				[
					8,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.05078125,
				0.3544921875,
				0.48046875,
				0.51953125,
				0.537109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1727308669,
			"isDeleted": false,
			"id": "6eRD3qYdRCzPEz2vfDEvA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -80.29166666666765,
			"y": 1576.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 16,
			"seed": 258807966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					0,
					-12
				],
				[
					0,
					-16
				],
				[
					4,
					-12
				],
				[
					4,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.0830078125,
				0.271484375,
				0.33203125,
				0.380859375,
				0.443359375,
				0.2138671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 716644051,
			"isDeleted": false,
			"id": "lgpanfSvU0bkDrqD_H8T8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -76.29166666666765,
			"y": 1612.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 601093598,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-8
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.30078125,
				0.326171875,
				0.396484375,
				0.412109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 1458383837,
			"isDeleted": false,
			"id": "_5dRrfsTn2aEPhMSuytKN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -292.29166666666765,
			"y": 1568.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 24,
			"seed": 949163742,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-12
				],
				[
					0,
					-16
				],
				[
					0,
					-20
				],
				[
					4,
					-20
				],
				[
					4,
					-24
				],
				[
					8,
					-20
				],
				[
					8,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0634765625,
				0.19921875,
				0.4130859375,
				0.4599609375,
				0.498046875,
				0.5068359375,
				0.4765625,
				0.34375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 984730739,
			"isDeleted": false,
			"id": "TWoNjv-88iPT-256uhm6e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -256.29166666666765,
			"y": 1604.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 1786239070,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					8,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.337890625,
				0.365234375,
				0.2275390625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1534437437,
			"isDeleted": false,
			"id": "usokSSXp8CDVyKVygnxu4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -236.29166666666765,
			"y": 1640.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 8,
			"seed": 1324464478,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					8,
					0
				],
				[
					12,
					-4
				],
				[
					16,
					-4
				],
				[
					16,
					0
				],
				[
					20,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.02734375,
				0.224609375,
				0.384765625,
				0.451171875,
				0.4716796875,
				0.4814453125,
				0.3798828125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 2118501907,
			"isDeleted": false,
			"id": "XVaoWB-Se3y7fTct-twm-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -396.29166666666765,
			"y": 1560.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 16,
			"seed": 1889279646,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					8,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.013671875,
				0.3046875,
				0.376953125,
				0.4775390625,
				0.4921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 1181718685,
			"isDeleted": false,
			"id": "bajr8s2XAMxWO38KKdiGV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -396.29166666666765,
			"y": 1588.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 8,
			"seed": 2057363358,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.00390625,
				0.376953125,
				0.341796875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 1281985459,
			"isDeleted": false,
			"id": "jNTfiEwFsZTpBz6W6n8V4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -396.29166666666765,
			"y": 1620.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 1787583582,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.03125,
				0.212890625,
				0.2041015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 831290621,
			"isDeleted": false,
			"id": "DoEcsKz2-xwt2l5IP6Iwv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -604.2916666666677,
			"y": 1556.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 16,
			"seed": 1229459742,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-16
				],
				[
					8,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3916015625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 1497603411,
			"isDeleted": false,
			"id": "No4MGjjldRBs7IgwM5vdx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -600.2916666666677,
			"y": 1576.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 8,
			"seed": 1226767838,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3173828125,
				0.3359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 72209757,
			"isDeleted": false,
			"id": "xNqDzNoenwuJKwbBPtttc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -604.2916666666677,
			"y": 1604.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 12,
			"seed": 473703070,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					12
				],
				[
					4,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0009765625,
				0.099609375,
				0.2001953125,
				0.298828125,
				0.142578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 271219443,
			"isDeleted": false,
			"id": "Gg3ubyDkYN-aoHhl9FGrQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 191.70833333333235,
			"y": 1304.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 72,
			"height": 100,
			"seed": 606004126,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-8,
					32
				],
				[
					-8,
					48
				],
				[
					-4,
					68
				],
				[
					0,
					80
				],
				[
					12,
					84
				],
				[
					28,
					84
				],
				[
					44,
					72
				],
				[
					56,
					56
				],
				[
					64,
					32
				],
				[
					60,
					16
				],
				[
					52,
					-4
				],
				[
					40,
					-16
				],
				[
					28,
					-16
				],
				[
					8,
					-4
				],
				[
					4,
					12
				],
				[
					0,
					20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.1611328125,
				0.259765625,
				0.3125,
				0.3701171875,
				0.419921875,
				0.4443359375,
				0.455078125,
				0.4580078125,
				0.4638671875,
				0.4794921875,
				0.4892578125,
				0.5029296875,
				0.5029296875,
				0.49609375,
				0.431640625,
				0.3076171875,
				0.1630859375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 973414845,
			"isDeleted": false,
			"id": "82-PPmwn1hbNNsudrPcxY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 351.70833333333235,
			"y": 1300.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 80,
			"height": 100,
			"seed": 1879696066,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359185,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					8
				],
				[
					-8,
					24
				],
				[
					-4,
					44
				],
				[
					0,
					56
				],
				[
					12,
					68
				],
				[
					28,
					72
				],
				[
					48,
					64
				],
				[
					60,
					52
				],
				[
					68,
					32
				],
				[
					72,
					12
				],
				[
					64,
					-12
				],
				[
					44,
					-28
				],
				[
					28,
					-28
				],
				[
					16,
					-20
				],
				[
					4,
					-4
				],
				[
					0,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.25,
				0.337890625,
				0.392578125,
				0.4150390625,
				0.4365234375,
				0.4501953125,
				0.455078125,
				0.466796875,
				0.4736328125,
				0.494140625,
				0.501953125,
				0.51171875,
				0.5146484375,
				0.48828125,
				0.375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 765764755,
			"isDeleted": false,
			"id": "42ZJihFPGBksSpLKg67Lu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 731.7083333333323,
			"y": 1304.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 72,
			"height": 96,
			"seed": 424523842,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					20
				],
				[
					-4,
					24
				],
				[
					-4,
					44
				],
				[
					0,
					60
				],
				[
					12,
					68
				],
				[
					24,
					72
				],
				[
					44,
					64
				],
				[
					56,
					48
				],
				[
					68,
					32
				],
				[
					68,
					12
				],
				[
					60,
					-8
				],
				[
					48,
					-24
				],
				[
					28,
					-24
				],
				[
					16,
					-20
				],
				[
					0,
					-4
				],
				[
					-4,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0400390625,
				0.224609375,
				0.248046875,
				0.30078125,
				0.33203125,
				0.35546875,
				0.3701171875,
				0.416015625,
				0.4365234375,
				0.4501953125,
				0.4609375,
				0.4775390625,
				0.49609375,
				0.5048828125,
				0.47265625,
				0.353515625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1741939229,
			"isDeleted": false,
			"id": "39t34f61M_Ei2fhYQ0t7j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 191.70833333333235,
			"y": 1492.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 84,
			"seed": 2093788610,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					28
				],
				[
					0,
					44
				],
				[
					12,
					60
				],
				[
					20,
					64
				],
				[
					36,
					60
				],
				[
					52,
					52
				],
				[
					60,
					36
				],
				[
					60,
					16
				],
				[
					56,
					0
				],
				[
					40,
					-16
				],
				[
					32,
					-20
				],
				[
					20,
					-20
				],
				[
					8,
					-8
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.244140625,
				0.298828125,
				0.341796875,
				0.3525390625,
				0.361328125,
				0.3671875,
				0.3779296875,
				0.380859375,
				0.3876953125,
				0.400390625,
				0.4091796875,
				0.4111328125,
				0.3857421875,
				0.3232421875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 36,
			"versionNonce": 426285619,
			"isDeleted": false,
			"id": "O_xGKtvQiglZ74dlfFVUB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 355.70833333333235,
			"y": 1496.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 76,
			"seed": 759623070,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					8
				],
				[
					-8,
					20
				],
				[
					-8,
					36
				],
				[
					-4,
					48
				],
				[
					0,
					56
				],
				[
					4,
					60
				],
				[
					12,
					60
				],
				[
					24,
					56
				],
				[
					32,
					48
				],
				[
					40,
					36
				],
				[
					44,
					28
				],
				[
					40,
					8
				],
				[
					28,
					-12
				],
				[
					16,
					-16
				],
				[
					4,
					-12
				],
				[
					-4,
					-4
				],
				[
					-12,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.029296875,
				0.216796875,
				0.314453125,
				0.369140625,
				0.392578125,
				0.41015625,
				0.4150390625,
				0.4306640625,
				0.451171875,
				0.474609375,
				0.486328125,
				0.484375,
				0.482421875,
				0.48046875,
				0.474609375,
				0.43359375,
				0.326171875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 35,
			"versionNonce": 44799613,
			"isDeleted": false,
			"id": "2c8uPZ7nTxmmiZULaM--c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 195.70833333333235,
			"y": 1712.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 80,
			"seed": 786168002,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					16
				],
				[
					0,
					32
				],
				[
					8,
					44
				],
				[
					24,
					48
				],
				[
					36,
					44
				],
				[
					48,
					36
				],
				[
					56,
					28
				],
				[
					60,
					16
				],
				[
					60,
					4
				],
				[
					52,
					-16
				],
				[
					36,
					-32
				],
				[
					20,
					-32
				],
				[
					8,
					-28
				],
				[
					0,
					-16
				],
				[
					0,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2216796875,
				0.3115234375,
				0.357421875,
				0.3779296875,
				0.3916015625,
				0.3984375,
				0.4033203125,
				0.4091796875,
				0.4306640625,
				0.4423828125,
				0.4541015625,
				0.470703125,
				0.453125,
				0.3779296875,
				0.2275390625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 6085587,
			"isDeleted": false,
			"id": "zq-sFju4e4revCWUdRpxN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 351.70833333333235,
			"y": 1712.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 72,
			"height": 88,
			"seed": 1889291842,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-12,
					20
				],
				[
					-8,
					56
				],
				[
					-8,
					60
				],
				[
					0,
					68
				],
				[
					16,
					68
				],
				[
					36,
					60
				],
				[
					52,
					40
				],
				[
					56,
					20
				],
				[
					48,
					-8
				],
				[
					32,
					-20
				],
				[
					16,
					-16
				],
				[
					0,
					-8
				],
				[
					-8,
					0
				],
				[
					-12,
					8
				],
				[
					-16,
					12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0234375,
				0.26171875,
				0.3466796875,
				0.3525390625,
				0.3671875,
				0.365234375,
				0.3662109375,
				0.35546875,
				0.3544921875,
				0.380859375,
				0.4072265625,
				0.408203125,
				0.3486328125,
				0.3017578125,
				0.197265625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 1699593949,
			"isDeleted": false,
			"id": "nd1eGEADxoV5Ln0Cyx-xA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 727.7083333333323,
			"y": 1724.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 88,
			"seed": 1087317278,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					8
				],
				[
					-8,
					16
				],
				[
					-8,
					28
				],
				[
					-8,
					40
				],
				[
					-4,
					48
				],
				[
					-4,
					52
				],
				[
					8,
					56
				],
				[
					20,
					52
				],
				[
					36,
					44
				],
				[
					52,
					28
				],
				[
					60,
					12
				],
				[
					60,
					-8
				],
				[
					52,
					-24
				],
				[
					36,
					-32
				],
				[
					20,
					-32
				],
				[
					8,
					-28
				],
				[
					0,
					-16
				],
				[
					-4,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1748046875,
				0.2431640625,
				0.2978515625,
				0.3251953125,
				0.3369140625,
				0.3408203125,
				0.3505859375,
				0.3544921875,
				0.3603515625,
				0.3837890625,
				0.4072265625,
				0.4287109375,
				0.4384765625,
				0.4462890625,
				0.44140625,
				0.38671875,
				0.27734375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 33,
			"versionNonce": 781707635,
			"isDeleted": false,
			"id": "2ls7svW5kODmkR9o3Q7rE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 719.7083333333323,
			"y": 1512.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 88,
			"seed": 278418398,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					28
				],
				[
					-4,
					32
				],
				[
					0,
					48
				],
				[
					12,
					60
				],
				[
					24,
					64
				],
				[
					36,
					60
				],
				[
					52,
					52
				],
				[
					60,
					36
				],
				[
					64,
					16
				],
				[
					48,
					-20
				],
				[
					36,
					-24
				],
				[
					20,
					-20
				],
				[
					12,
					-12
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.224609375,
				0.2392578125,
				0.2802734375,
				0.3095703125,
				0.3291015625,
				0.3564453125,
				0.388671875,
				0.4169921875,
				0.4248046875,
				0.4306640625,
				0.4296875,
				0.3876953125,
				0.3212890625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 28,
			"versionNonce": 374070077,
			"isDeleted": false,
			"id": "nHcuYWml99SPbYSqEZ8mr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 507.70833333333235,
			"y": 1332.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 16,
			"seed": 767404574,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					8,
					0
				],
				[
					8,
					4
				],
				[
					8,
					8
				],
				[
					8,
					12
				],
				[
					4,
					12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.212890625,
				0.4423828125,
				0.462890625,
				0.4970703125,
				0.529296875,
				0.5341796875,
				0.5166015625,
				0.4580078125,
				0.2763671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 694174483,
			"isDeleted": false,
			"id": "8bmhi1Ku8ObgbVhm2A4tP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 543.7083333333323,
			"y": 1344.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 8,
			"seed": 420123970,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					-4
				],
				[
					12,
					-4
				],
				[
					12,
					-8
				],
				[
					12,
					-4
				],
				[
					12,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.03125,
				0.111328125,
				0.263671875,
				0.37890625,
				0.435546875,
				0.4755859375,
				0.154296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 1309109149,
			"isDeleted": false,
			"id": "44APjapJGg1NqvkQJb_KV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 579.7083333333323,
			"y": 1340.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 8,
			"seed": 1253772290,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8,
					0
				],
				[
					8,
					-4
				],
				[
					12,
					-4
				],
				[
					16,
					-8
				],
				[
					16,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.193359375,
				0.2470703125,
				0.298828125,
				0.39453125,
				0.2392578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 153905331,
			"isDeleted": false,
			"id": "5ATPBrvO3eno4SZL427Qt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 495.70833333333235,
			"y": 1552.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 16,
			"seed": 1595321886,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-12
				],
				[
					8,
					-16
				],
				[
					8,
					-12
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.265625,
				0.384765625,
				0.4775390625,
				0.4111328125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1018294269,
			"isDeleted": false,
			"id": "fFR-53e5uDHE9z1HDBoZy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 547.7083333333323,
			"y": 1544.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 16,
			"seed": 1146411458,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					12,
					-16
				],
				[
					16,
					-16
				],
				[
					16,
					-8
				],
				[
					16,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.4013671875,
				0.4638671875,
				0.498046875,
				0.521484375,
				0.455078125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 329439827,
			"isDeleted": false,
			"id": "oXxaQbVT6-mt6ciVFv_c6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 579.7083333333323,
			"y": 1540.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 12,
			"seed": 411730050,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					16,
					-12
				],
				[
					16,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.4794921875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 273475677,
			"isDeleted": false,
			"id": "1laZwpgq10MHIPauY0NiK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 547.7083333333323,
			"y": 1644.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 16,
			"seed": 1148024770,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-8
				],
				[
					4,
					-16
				],
				[
					8,
					-16
				],
				[
					8,
					-12
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.486328125,
				0.693359375,
				0.5849609375,
				0.453125,
				0.30078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 362420211,
			"isDeleted": false,
			"id": "JfdpjEPJ5egiaP9QmONUe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 571.7083333333323,
			"y": 1672.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 12,
			"seed": 1319616094,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					8,
					-12
				],
				[
					12,
					-12
				],
				[
					16,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0146484375,
				0.384765625,
				0.4814453125,
				0.5244140625,
				0.5458984375,
				0.47265625,
				0.314453125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 984208573,
			"isDeleted": false,
			"id": "k4zmVgP0Td1hg1xP77nsL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 611.7083333333323,
			"y": 1696.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 1693385630,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.16015625,
				0.5888671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 2098766227,
			"isDeleted": false,
			"id": "esnTrB0yVOIcpsbXjl0_a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 771.7083333333323,
			"y": 1612.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 12,
			"seed": 878510174,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-8
				],
				[
					0,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0185546875,
				0.3115234375,
				0.4541015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 2003449117,
			"isDeleted": false,
			"id": "EjfmlbVpx_MGAUExmSQk6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 771.7083333333323,
			"y": 1620.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 20,
			"seed": 329987358,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					12
				],
				[
					0,
					16
				],
				[
					0,
					20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3740234375,
				0.3017578125,
				0.15625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 861206323,
			"isDeleted": false,
			"id": "VD8gSBn5BsAWZXk2n2Eqc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 767.7083333333323,
			"y": 1652.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 20,
			"seed": 1549103874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					12
				],
				[
					0,
					16
				],
				[
					0,
					20
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0625,
				0.203125,
				0.333984375,
				0.4033203125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 18,
			"versionNonce": 301959549,
			"isDeleted": false,
			"id": "LUfIaIRurRqKBBrLSR5dE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 375.70833333333235,
			"y": 1592.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.0001,
			"height": 0.0001,
			"seed": 615178754,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.0001,
					0.0001
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0400390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 917870803,
			"isDeleted": false,
			"id": "FTLIKKM5JuXcWHDfZ5r0v",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 375.70833333333235,
			"y": 1632.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 1462051678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1455078125,
				0.2763671875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 1806389725,
			"isDeleted": false,
			"id": "9j-VBFUzY7c0P8VAbW9-d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 379.70833333333235,
			"y": 1664.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 13852866,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					-4,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.009765625,
				0.314453125,
				0.244140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 1959855731,
			"isDeleted": false,
			"id": "HW7jpUHkdgF8FgYE-kyNx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 247.70833333333235,
			"y": 1596.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 604454914,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					-4
				],
				[
					-8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.15625,
				0.361328125,
				0.4033203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 1098845757,
			"isDeleted": false,
			"id": "5eTgAPqq82vkJyLVsidPC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 243.70833333333235,
			"y": 1612.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 2008425950,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3173828125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 1684914195,
			"isDeleted": false,
			"id": "StOqX3VoW155H0nowNU8a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 247.70833333333235,
			"y": 1636.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 8,
			"seed": 1430538910,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.17578125,
				0.3603515625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 844906141,
			"isDeleted": false,
			"id": "g19qUs0zyYKQdcFAd1rbh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 467.70833333333235,
			"y": 1764.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 16,
			"seed": 767797086,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-12
				],
				[
					8,
					-12
				],
				[
					12,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.052734375,
				0.279296875,
				0.5068359375,
				0.5556640625,
				0.4951171875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 1602373043,
			"isDeleted": false,
			"id": "agrycHSE4mzztmBJVXCn_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 523.7083333333323,
			"y": 1756.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 16,
			"seed": 279688322,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					12,
					-8
				],
				[
					16,
					-8
				],
				[
					20,
					-12
				],
				[
					24,
					-16
				],
				[
					28,
					-16
				],
				[
					36,
					-16
				],
				[
					36,
					-16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0400390625,
				0.169921875,
				0.4794921875,
				0.6904296875,
				0.7373046875,
				0.7236328125,
				0.6015625,
				0.431640625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 83124989,
			"isDeleted": false,
			"id": "k6iFHlAEXFoDBsmcgV_Et",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 575.7083333333323,
			"y": 1740.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 8,
			"seed": 1254074846,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					8,
					4
				],
				[
					8,
					8
				],
				[
					12,
					8
				],
				[
					16,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.138671875,
				0.3798828125,
				0.48828125,
				0.583984375,
				0.3740234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 39,
			"versionNonce": 1026889555,
			"isDeleted": false,
			"id": "J2iNbsue_ojyuXChxpgUE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1015.7083333333323,
			"y": 660.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 1300,
			"seed": 894565058,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					8
				],
				[
					-4,
					20
				],
				[
					-4,
					24
				],
				[
					-12,
					104
				],
				[
					-12,
					132
				],
				[
					-16,
					220
				],
				[
					-20,
					380
				],
				[
					-20,
					404
				],
				[
					-24,
					640
				],
				[
					-24,
					680
				],
				[
					-24,
					772
				],
				[
					-24,
					860
				],
				[
					-24,
					876
				],
				[
					-20,
					968
				],
				[
					-16,
					1028
				],
				[
					-16,
					1040
				],
				[
					-4,
					1132
				],
				[
					4,
					1196
				],
				[
					4,
					1208
				],
				[
					12,
					1252
				],
				[
					12,
					1276
				],
				[
					16,
					1300
				],
				[
					16,
					1300
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.169921875,
				0.1845703125,
				0.197265625,
				0.2685546875,
				0.2802734375,
				0.2978515625,
				0.3369140625,
				0.345703125,
				0.41796875,
				0.421875,
				0.4404296875,
				0.4462890625,
				0.447265625,
				0.447265625,
				0.4501953125,
				0.447265625,
				0.44140625,
				0.4365234375,
				0.435546875,
				0.4228515625,
				0.4189453125,
				0.3251953125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 45,
			"versionNonce": 768146269,
			"isDeleted": false,
			"id": "DyqViDMGVrccHFvmp0r-N",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1255.7083333333323,
			"y": 704.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76,
			"height": 1316,
			"seed": 1954196830,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					4
				],
				[
					4,
					24
				],
				[
					28,
					96
				],
				[
					52,
					196
				],
				[
					68,
					320
				],
				[
					72,
					356
				],
				[
					72,
					488
				],
				[
					72,
					584
				],
				[
					68,
					700
				],
				[
					64,
					808
				],
				[
					60,
					868
				],
				[
					60,
					884
				],
				[
					60,
					940
				],
				[
					52,
					1004
				],
				[
					48,
					1048
				],
				[
					44,
					1100
				],
				[
					40,
					1128
				],
				[
					32,
					1164
				],
				[
					28,
					1192
				],
				[
					24,
					1204
				],
				[
					20,
					1232
				],
				[
					16,
					1260
				],
				[
					12,
					1280
				],
				[
					12,
					1296
				],
				[
					8,
					1304
				],
				[
					8,
					1308
				],
				[
					8,
					1312
				],
				[
					8,
					1312
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.00390625,
				0.1103515625,
				0.2421875,
				0.28125,
				0.3291015625,
				0.357421875,
				0.416015625,
				0.4306640625,
				0.4619140625,
				0.466796875,
				0.4638671875,
				0.4423828125,
				0.4384765625,
				0.4375,
				0.4267578125,
				0.423828125,
				0.4130859375,
				0.404296875,
				0.408203125,
				0.40234375,
				0.3916015625,
				0.38671875,
				0.388671875,
				0.3994140625,
				0.3916015625,
				0.3828125,
				0.3740234375,
				0.349609375,
				0.3408203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 735884531,
			"isDeleted": false,
			"id": "0i_ne7o26vKwmLhTpHJl9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1103.7083333333323,
			"y": 796.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 96,
			"height": 16,
			"seed": 1988453314,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					16,
					0
				],
				[
					44,
					-8
				],
				[
					68,
					-12
				],
				[
					84,
					-16
				],
				[
					92,
					-16
				],
				[
					96,
					-16
				],
				[
					96,
					-16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0263671875,
				0.2998046875,
				0.3740234375,
				0.4482421875,
				0.4697265625,
				0.4697265625,
				0.380859375,
				0.2421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 355174333,
			"isDeleted": false,
			"id": "YP_uYr11p2n71Uwiph5Rr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1135.7083333333323,
			"y": 780.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 108,
			"seed": 1764018818,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					24
				],
				[
					-4,
					84
				],
				[
					-4,
					88
				],
				[
					0,
					96
				],
				[
					0,
					100
				],
				[
					0,
					108
				],
				[
					0,
					108
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.341796875,
				0.4814453125,
				0.4794921875,
				0.4677734375,
				0.412109375,
				0.2890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 1258266259,
			"isDeleted": false,
			"id": "7YOSJGNcjkyLGf7uOIcly",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1115.7083333333323,
			"y": 856.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 20,
			"seed": 1447909278,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-12
				],
				[
					20,
					-16
				],
				[
					32,
					-16
				],
				[
					36,
					-20
				],
				[
					40,
					-20
				],
				[
					44,
					-20
				],
				[
					44,
					-20
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.021484375,
				0.15234375,
				0.2470703125,
				0.3115234375,
				0.33984375,
				0.3359375,
				0.26171875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 490571805,
			"isDeleted": false,
			"id": "pphD87Hp8xPkgxR9T3JHu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1171.7083333333323,
			"y": 824.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 52,
			"seed": 1001182430,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					8
				],
				[
					4,
					20
				],
				[
					8,
					32
				],
				[
					8,
					40
				],
				[
					8,
					48
				],
				[
					8,
					52
				],
				[
					8,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0205078125,
				0.2509765625,
				0.345703125,
				0.3955078125,
				0.4189453125,
				0.416015625,
				0.330078125,
				0.248046875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 89412659,
			"isDeleted": false,
			"id": "k7Sd7j0PDvkGYIcvjLFsi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1099.7083333333323,
			"y": 940.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 24,
			"seed": 729156126,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-4
				],
				[
					20,
					-8
				],
				[
					40,
					-16
				],
				[
					48,
					-20
				],
				[
					56,
					-20
				],
				[
					64,
					-24
				],
				[
					68,
					-24
				],
				[
					68,
					-24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.017578125,
				0.3125,
				0.357421875,
				0.400390625,
				0.419921875,
				0.427734375,
				0.416015625,
				0.2958984375,
				0.140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1743813757,
			"isDeleted": false,
			"id": "Z5c60cqGYrVL6oaRtz_wX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1119.7083333333323,
			"y": 916.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 80,
			"seed": 1634612610,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					8
				],
				[
					-8,
					16
				],
				[
					-12,
					24
				],
				[
					-12,
					44
				],
				[
					-8,
					60
				],
				[
					-8,
					72
				],
				[
					-4,
					76
				],
				[
					-4,
					80
				],
				[
					-4,
					80
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.177734375,
				0.2861328125,
				0.33984375,
				0.41015625,
				0.4267578125,
				0.34765625,
				0.310546875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 717313491,
			"isDeleted": false,
			"id": "Q5eGeEfyuFeoMvnZUVDnx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1095.7083333333323,
			"y": 984.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 20,
			"seed": 1945655518,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					8,
					-12
				],
				[
					20,
					-16
				],
				[
					32,
					-16
				],
				[
					32,
					-20
				],
				[
					32,
					-20
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1220703125,
				0.263671875,
				0.25390625,
				0.1025390625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 1560667357,
			"isDeleted": false,
			"id": "LM6b8AD43UrYEvJEWr9YD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1147.7083333333323,
			"y": 972.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 52,
			"seed": 1575877086,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					-4
				],
				[
					4,
					-16
				],
				[
					16,
					-16
				],
				[
					16,
					-12
				],
				[
					16,
					-4
				],
				[
					12,
					8
				],
				[
					8,
					20
				],
				[
					0,
					28
				],
				[
					-4,
					32
				],
				[
					0,
					28
				],
				[
					4,
					28
				],
				[
					20,
					28
				],
				[
					32,
					28
				],
				[
					40,
					32
				],
				[
					48,
					32
				],
				[
					52,
					36
				],
				[
					52,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0107421875,
				0.1904296875,
				0.3037109375,
				0.33984375,
				0.361328125,
				0.37890625,
				0.390625,
				0.4033203125,
				0.41796875,
				0.4453125,
				0.4794921875,
				0.5,
				0.50390625,
				0.5126953125,
				0.50390625,
				0.4541015625,
				0.3203125,
				0.171875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 1247617907,
			"isDeleted": false,
			"id": "1uoSEsxy70A3Gw1oKY2qC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1071.7083333333323,
			"y": 1124.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 20,
			"seed": 614259806,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					20,
					-4
				],
				[
					40,
					-8
				],
				[
					56,
					-16
				],
				[
					68,
					-16
				],
				[
					76,
					-16
				],
				[
					80,
					-20
				],
				[
					80,
					-20
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01953125,
				0.11328125,
				0.3505859375,
				0.373046875,
				0.4150390625,
				0.4345703125,
				0.447265625,
				0.4365234375,
				0.3974609375,
				0.267578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 1880047933,
			"isDeleted": false,
			"id": "bc7gpUg6YnpBdbqG-DAkh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1095.7083333333323,
			"y": 1116.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 84,
			"seed": 1557102046,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					4
				],
				[
					-8,
					12
				],
				[
					-12,
					24
				],
				[
					-12,
					36
				],
				[
					-12,
					48
				],
				[
					-12,
					64
				],
				[
					-8,
					76
				],
				[
					-8,
					80
				],
				[
					-4,
					84
				],
				[
					-4,
					84
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1572265625,
				0.2509765625,
				0.318359375,
				0.36328125,
				0.3896484375,
				0.3984375,
				0.359375,
				0.3056640625,
				0.1220703125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 1282293011,
			"isDeleted": false,
			"id": "0T4VDqtr45m7gWwTel5Ds",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1075.7083333333323,
			"y": 1184.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 24,
			"seed": 905641822,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-16
				],
				[
					12,
					-20
				],
				[
					20,
					-24
				],
				[
					24,
					-24
				],
				[
					24,
					-24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.001953125,
				0.08984375,
				0.1796875,
				0.259765625,
				0.2802734375,
				0.23046875,
				0.1240234375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 40,
			"versionNonce": 644747677,
			"isDeleted": false,
			"id": "WA-KWJ-WBKazpGbf4wOW3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1119.7083333333323,
			"y": 1160.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 68,
			"height": 40,
			"seed": 1105321090,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					12
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					4,
					32
				],
				[
					4,
					36
				],
				[
					4,
					24
				],
				[
					4,
					12
				],
				[
					8,
					4
				],
				[
					12,
					0
				],
				[
					20,
					0
				],
				[
					24,
					8
				],
				[
					28,
					16
				],
				[
					28,
					24
				],
				[
					32,
					28
				],
				[
					32,
					24
				],
				[
					32,
					16
				],
				[
					36,
					4
				],
				[
					40,
					0
				],
				[
					44,
					-4
				],
				[
					48,
					0
				],
				[
					56,
					8
				],
				[
					64,
					16
				],
				[
					68,
					24
				],
				[
					68,
					24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.203125,
				0.2421875,
				0.302734375,
				0.345703125,
				0.37109375,
				0.4599609375,
				0.4580078125,
				0.4599609375,
				0.458984375,
				0.4560546875,
				0.4580078125,
				0.462890625,
				0.46484375,
				0.4658203125,
				0.47265625,
				0.4677734375,
				0.462890625,
				0.4609375,
				0.4609375,
				0.4619140625,
				0.4609375,
				0.4482421875,
				0.3212890625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 19,
			"versionNonce": 1282089651,
			"isDeleted": false,
			"id": "Gsw0apcq2Chmlzx-bC5e-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1139.7083333333323,
			"y": 1036.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 4,
			"seed": 1120725314,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359186,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.455078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 19,
			"versionNonce": 1565775357,
			"isDeleted": false,
			"id": "xPbuWqiwmtp431XdRx_Q5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1143.7083333333323,
			"y": 1056.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 4,
			"seed": 1613620318,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.00390625,
				0.361328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 20,
			"versionNonce": 855266387,
			"isDeleted": false,
			"id": "qsVGtLhWNYpMXJYyP2POZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1139.7083333333323,
			"y": 1084.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 1820909570,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					0,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2783203125,
				0.294921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 1338117725,
			"isDeleted": false,
			"id": "WY1HNEUELIRl5e-sQAcnq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1131.7083333333323,
			"y": 1040.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 1178470210,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0234375,
				0.36328125,
				0.3955078125,
				0.421875,
				0.4560546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 267538931,
			"isDeleted": false,
			"id": "HmftGwTNjl-KmRdd45zS_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1135.7083333333323,
			"y": 1056.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 8,
			"seed": 545740354,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.009765625,
				0.3984375,
				0.279296875,
				0.1279296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 1552562877,
			"isDeleted": false,
			"id": "sUH902dA04Ff1jGiGy0gM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1131.7083333333323,
			"y": 1076.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 1623419806,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					4,
					-8
				],
				[
					4,
					-4
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.3271484375,
				0.4150390625,
				0.4423828125,
				0.33984375,
				0.244140625,
				0
			]
		},
		{
			"type": "line",
			"version": 37,
			"versionNonce": 878287763,
			"isDeleted": false,
			"id": "U4gsG-uS3skuKm6-a1NX5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1031.7083333333323,
			"y": 1284.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 284,
			"height": 4,
			"seed": 553350210,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					284,
					-4
				]
			]
		},
		{
			"type": "freedraw",
			"version": 27,
			"versionNonce": 206428957,
			"isDeleted": false,
			"id": "r9HVjbiLdn19seyZp5-ZM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1115.7083333333323,
			"y": 1308.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 72,
			"seed": 766078878,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					4
				],
				[
					12,
					12
				],
				[
					12,
					16
				],
				[
					20,
					24
				],
				[
					24,
					32
				],
				[
					32,
					44
				],
				[
					36,
					56
				],
				[
					40,
					68
				],
				[
					40,
					72
				],
				[
					40,
					72
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0078125,
				0.2001953125,
				0.2724609375,
				0.3251953125,
				0.341796875,
				0.3876953125,
				0.41015625,
				0.4296875,
				0.44140625,
				0.4052734375,
				0.3310546875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 208056627,
			"isDeleted": false,
			"id": "aOghp9oTGLYV_OKKH5yIO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1143.7083333333323,
			"y": 1348.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 44,
			"seed": 1648887746,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-16,
					12
				],
				[
					-24,
					28
				],
				[
					-24,
					36
				],
				[
					-24,
					40
				],
				[
					-24,
					44
				],
				[
					-24,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.4091796875,
				0.4541015625,
				0.4423828125,
				0.392578125,
				0.3154296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 1467903869,
			"isDeleted": false,
			"id": "oenSOp9Orc3Doh58zGwtW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1175.7083333333323,
			"y": 1356.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 44,
			"seed": 1900877506,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					12
				],
				[
					0,
					32
				],
				[
					0,
					40
				],
				[
					0,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2880859375,
				0.509765625,
				0.5234375,
				0.369140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 964694739,
			"isDeleted": false,
			"id": "urqM5tCjpPrFlf5K7Tk7D",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1207.7083333333323,
			"y": 1308.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 36,
			"seed": 1698374430,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					0,
					16
				],
				[
					0,
					24
				],
				[
					0,
					32
				],
				[
					0,
					36
				],
				[
					0,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0263671875,
				0.4443359375,
				0.47265625,
				0.513671875,
				0.5244140625,
				0.4580078125,
				0.3779296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 744323037,
			"isDeleted": false,
			"id": "v-_qttWBRcMr87LOkCnGm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1103.7083333333323,
			"y": 1452.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 68,
			"seed": 2006496450,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					16,
					8
				],
				[
					24,
					20
				],
				[
					32,
					36
				],
				[
					36,
					40
				],
				[
					40,
					56
				],
				[
					44,
					60
				],
				[
					44,
					68
				],
				[
					44,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.009765625,
				0.22265625,
				0.3232421875,
				0.4287109375,
				0.4853515625,
				0.5107421875,
				0.51171875,
				0.5146484375,
				0.4873046875,
				0.3232421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1815887987,
			"isDeleted": false,
			"id": "tDQmtU99lwxaHnqFINCck",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1135.7083333333323,
			"y": 1488.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 60,
			"seed": 2106506050,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-16,
					8
				],
				[
					-24,
					28
				],
				[
					-28,
					40
				],
				[
					-28,
					44
				],
				[
					-28,
					48
				],
				[
					-28,
					52
				],
				[
					-28,
					56
				],
				[
					-28,
					56
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0048828125,
				0.2705078125,
				0.41796875,
				0.4736328125,
				0.490234375,
				0.4853515625,
				0.4541015625,
				0.375,
				0.2705078125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 34,
			"versionNonce": 888960061,
			"isDeleted": false,
			"id": "KfU6bFelaQy1xQDMHj5jT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1155.7083333333323,
			"y": 1516.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 56,
			"seed": 805447454,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					12,
					-20
				],
				[
					20,
					-24
				],
				[
					24,
					-24
				],
				[
					28,
					-24
				],
				[
					32,
					-16
				],
				[
					32,
					-4
				],
				[
					24,
					8
				],
				[
					16,
					20
				],
				[
					12,
					24
				],
				[
					8,
					24
				],
				[
					4,
					24
				],
				[
					8,
					24
				],
				[
					12,
					24
				],
				[
					20,
					28
				],
				[
					28,
					32
				],
				[
					36,
					32
				],
				[
					40,
					32
				],
				[
					40,
					32
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2890625,
				0.33203125,
				0.36328125,
				0.38671875,
				0.419921875,
				0.4375,
				0.451171875,
				0.4736328125,
				0.4931640625,
				0.50390625,
				0.5146484375,
				0.5234375,
				0.5244140625,
				0.5224609375,
				0.5126953125,
				0.4453125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 2120333843,
			"isDeleted": false,
			"id": "8slATEah7QEKxgUSiTIQG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1199.7083333333323,
			"y": 1452.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 44,
			"seed": 1632991646,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					4,
					12
				],
				[
					4,
					16
				],
				[
					8,
					28
				],
				[
					8,
					36
				],
				[
					12,
					40
				],
				[
					12,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0341796875,
				0.1796875,
				0.400390625,
				0.4951171875,
				0.5068359375,
				0.4521484375,
				0.259765625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1564271773,
			"isDeleted": false,
			"id": "kmlWOyZK-KocYVWBQb9lE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1107.7083333333323,
			"y": 1804.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 68,
			"seed": 1935652574,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					12,
					16
				],
				[
					16,
					28
				],
				[
					24,
					44
				],
				[
					28,
					56
				],
				[
					28,
					64
				],
				[
					32,
					64
				],
				[
					32,
					68
				],
				[
					32,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.03125,
				0.3740234375,
				0.42578125,
				0.447265625,
				0.466796875,
				0.4541015625,
				0.376953125,
				0.318359375,
				0.1943359375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 1290207155,
			"isDeleted": false,
			"id": "hegNBQbIxxuCokk3QFWfe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1131.7083333333323,
			"y": 1836.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 48,
			"seed": 618343618,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-12,
					-4
				],
				[
					-20,
					0
				],
				[
					-24,
					8
				],
				[
					-32,
					16
				],
				[
					-32,
					24
				],
				[
					-32,
					32
				],
				[
					-32,
					40
				],
				[
					-28,
					44
				],
				[
					-28,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.119140625,
				0.2353515625,
				0.3251953125,
				0.3798828125,
				0.421875,
				0.4326171875,
				0.4345703125,
				0.3828125,
				0.275390625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 32,
			"versionNonce": 416303357,
			"isDeleted": false,
			"id": "x_x88sQFKrAcf2evgpNW-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1143.7083333333323,
			"y": 1844.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24,
			"height": 44,
			"seed": 613888834,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					20
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					44
				],
				[
					4,
					32
				],
				[
					4,
					20
				],
				[
					8,
					12
				],
				[
					12,
					16
				],
				[
					16,
					20
				],
				[
					20,
					28
				],
				[
					20,
					32
				],
				[
					20,
					36
				],
				[
					24,
					40
				],
				[
					24,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.02734375,
				0.2734375,
				0.33984375,
				0.369140625,
				0.4033203125,
				0.40625,
				0.4169921875,
				0.4404296875,
				0.4423828125,
				0.4375,
				0.443359375,
				0.4404296875,
				0.4384765625,
				0.4208984375,
				0.3212890625,
				0.2197265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 1374851411,
			"isDeleted": false,
			"id": "OQMEfVw7PfOXf5DBF5jtk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1159.7083333333323,
			"y": 1772.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 44,
			"seed": 1778833666,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					8,
					32
				],
				[
					8,
					40
				],
				[
					12,
					44
				],
				[
					12,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.4208984375,
				0.4521484375,
				0.4814453125,
				0.4970703125,
				0.50390625,
				0.41015625,
				0.271484375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 20,
			"versionNonce": 1765286237,
			"isDeleted": false,
			"id": "hIQ5HJWWARF4KPp-Rxeca",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1135.7083333333323,
			"y": 1576.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 4,
			"seed": 2060777410,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					4,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.4208984375,
				0.4619140625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 2128277235,
			"isDeleted": false,
			"id": "pg153ILyfCwIICRMsTTX7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1135.7083333333323,
			"y": 1620.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 1690056450,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2685546875,
				0.388671875,
				0.4296875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 600174013,
			"isDeleted": false,
			"id": "OPzgAip5VC_zPcXYJf3sB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1139.7083333333323,
			"y": 1652.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 8,
			"seed": 1013366494,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					0,
					-4
				],
				[
					4,
					0
				],
				[
					0,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2802734375,
				0.4033203125,
				0.4208984375,
				0.3876953125,
				0.2451171875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 25,
			"versionNonce": 1445370003,
			"isDeleted": false,
			"id": "Jd4EhegGYWcMgPsmw7awQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1419.7083333333323,
			"y": 1072.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 4,
			"seed": 1840485634,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					0
				],
				[
					8,
					0
				],
				[
					16,
					0
				],
				[
					28,
					-4
				],
				[
					40,
					-4
				],
				[
					44,
					-4
				],
				[
					48,
					-4
				],
				[
					48,
					-4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0302734375,
				0.169921875,
				0.3642578125,
				0.4560546875,
				0.4814453125,
				0.4970703125,
				0.5,
				0.4755859375,
				0.283203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 24,
			"versionNonce": 2006658589,
			"isDeleted": false,
			"id": "_xZyTHpFoSO6Ds4wWLRAY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1427.7083333333323,
			"y": 1096.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 4,
			"seed": 2111005022,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					8,
					4
				],
				[
					16,
					4
				],
				[
					24,
					4
				],
				[
					28,
					0
				],
				[
					32,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.1259765625,
				0.40234375,
				0.4345703125,
				0.4375,
				0.3447265625,
				0.2607421875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 52,
			"versionNonce": 1166806579,
			"isDeleted": false,
			"id": "N6_l_15HA4l6sIwxBsxwF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1575.7083333333323,
			"y": 684.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76,
			"height": 1256,
			"seed": 1710886814,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-8,
					8
				],
				[
					-16,
					24
				],
				[
					-24,
					56
				],
				[
					-28,
					100
				],
				[
					-32,
					144
				],
				[
					-36,
					196
				],
				[
					-36,
					260
				],
				[
					-36,
					320
				],
				[
					-36,
					364
				],
				[
					-32,
					428
				],
				[
					-32,
					492
				],
				[
					-32,
					552
				],
				[
					-28,
					624
				],
				[
					-24,
					680
				],
				[
					-20,
					736
				],
				[
					-16,
					784
				],
				[
					-12,
					832
				],
				[
					-8,
					880
				],
				[
					-4,
					932
				],
				[
					0,
					960
				],
				[
					4,
					996
				],
				[
					8,
					1024
				],
				[
					8,
					1052
				],
				[
					12,
					1076
				],
				[
					12,
					1108
				],
				[
					16,
					1128
				],
				[
					16,
					1148
				],
				[
					20,
					1164
				],
				[
					20,
					1176
				],
				[
					24,
					1192
				],
				[
					28,
					1212
				],
				[
					28,
					1224
				],
				[
					32,
					1232
				],
				[
					36,
					1244
				],
				[
					40,
					1252
				],
				[
					40,
					1256
				],
				[
					40,
					1256
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.0478515625,
				0.189453125,
				0.2333984375,
				0.26953125,
				0.3251953125,
				0.3701171875,
				0.40234375,
				0.453125,
				0.4833984375,
				0.5048828125,
				0.5126953125,
				0.525390625,
				0.5224609375,
				0.5341796875,
				0.5244140625,
				0.5244140625,
				0.5283203125,
				0.51953125,
				0.5263671875,
				0.517578125,
				0.5087890625,
				0.5087890625,
				0.5146484375,
				0.50390625,
				0.5,
				0.5,
				0.5,
				0.498046875,
				0.498046875,
				0.4990234375,
				0.4990234375,
				0.49609375,
				0.4873046875,
				0.4736328125,
				0.43359375,
				0.3837890625,
				0.34375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 50,
			"versionNonce": 866738813,
			"isDeleted": false,
			"id": "nDwvCNW-FN5iYaUey1tNv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1867.7083333333323,
			"y": 680.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104,
			"height": 1276,
			"seed": 647200834,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					8,
					24
				],
				[
					16,
					48
				],
				[
					28,
					84
				],
				[
					36,
					124
				],
				[
					48,
					176
				],
				[
					60,
					224
				],
				[
					68,
					272
				],
				[
					76,
					320
				],
				[
					84,
					372
				],
				[
					92,
					428
				],
				[
					100,
					524
				],
				[
					104,
					608
				],
				[
					104,
					664
				],
				[
					104,
					680
				],
				[
					104,
					760
				],
				[
					104,
					840
				],
				[
					104,
					888
				],
				[
					104,
					932
				],
				[
					100,
					988
				],
				[
					100,
					1036
				],
				[
					100,
					1052
				],
				[
					100,
					1084
				],
				[
					100,
					1112
				],
				[
					96,
					1140
				],
				[
					96,
					1168
				],
				[
					96,
					1188
				],
				[
					96,
					1212
				],
				[
					96,
					1228
				],
				[
					96,
					1240
				],
				[
					96,
					1248
				],
				[
					96,
					1256
				],
				[
					96,
					1260
				],
				[
					96,
					1268
				],
				[
					96,
					1272
				],
				[
					92,
					1276
				],
				[
					96,
					1272
				],
				[
					96,
					1272
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0029296875,
				0.251953125,
				0.2958984375,
				0.3251953125,
				0.349609375,
				0.3876953125,
				0.390625,
				0.42578125,
				0.4599609375,
				0.4765625,
				0.5029296875,
				0.521484375,
				0.544921875,
				0.5517578125,
				0.55078125,
				0.552734375,
				0.5517578125,
				0.544921875,
				0.546875,
				0.541015625,
				0.5390625,
				0.5400390625,
				0.546875,
				0.556640625,
				0.552734375,
				0.5439453125,
				0.5439453125,
				0.548828125,
				0.5537109375,
				0.552734375,
				0.55078125,
				0.546875,
				0.546875,
				0.5458984375,
				0.544921875,
				0.541015625,
				0.5380859375,
				0.158203125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 41,
			"versionNonce": 1072811987,
			"isDeleted": false,
			"id": "THZeDMBmxoz0jKkaGfL8n",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1571.7083333333323,
			"y": 776.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 108,
			"height": 100,
			"seed": 2024835906,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					24
				],
				[
					4,
					36
				],
				[
					12,
					56
				],
				[
					20,
					76
				],
				[
					32,
					88
				],
				[
					40,
					92
				],
				[
					52,
					88
				],
				[
					60,
					80
				],
				[
					68,
					68
				],
				[
					68,
					52
				],
				[
					68,
					20
				],
				[
					64,
					8
				],
				[
					64,
					-4
				],
				[
					64,
					-8
				],
				[
					64,
					12
				],
				[
					64,
					44
				],
				[
					72,
					68
				],
				[
					80,
					80
				],
				[
					84,
					84
				],
				[
					96,
					84
				],
				[
					100,
					76
				],
				[
					108,
					60
				],
				[
					108,
					40
				],
				[
					108,
					20
				],
				[
					104,
					4
				],
				[
					104,
					-4
				],
				[
					104,
					0
				],
				[
					104,
					8
				],
				[
					104,
					8
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.24609375,
				0.27734375,
				0.337890625,
				0.376953125,
				0.408203125,
				0.427734375,
				0.4541015625,
				0.4853515625,
				0.505859375,
				0.517578125,
				0.509765625,
				0.5068359375,
				0.5078125,
				0.5087890625,
				0.5107421875,
				0.5224609375,
				0.5224609375,
				0.5224609375,
				0.5205078125,
				0.51953125,
				0.529296875,
				0.5634765625,
				0.5751953125,
				0.5791015625,
				0.580078125,
				0.5634765625,
				0.34375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 19,
			"versionNonce": 1286736605,
			"isDeleted": false,
			"id": "bBXRlDo0d3QIEOW7vRjIc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1707.7083333333323,
			"y": 816.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 52,
			"seed": 1312729502,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					4,
					28
				],
				[
					4,
					36
				],
				[
					4,
					44
				],
				[
					4,
					52
				],
				[
					4,
					52
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0556640625,
				0.3701171875,
				0.4921875,
				0.5126953125,
				0.51171875,
				0.453125,
				0.24609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 393108851,
			"isDeleted": false,
			"id": "nO1FEPhxrkrcTKuDHu3Mc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1779.7083333333323,
			"y": 760.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 96,
			"seed": 1954158146,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-16,
					-8
				],
				[
					-24,
					0
				],
				[
					-32,
					24
				],
				[
					-32,
					28
				],
				[
					-32,
					32
				],
				[
					-32,
					48
				],
				[
					-28,
					72
				],
				[
					-28,
					76
				],
				[
					-24,
					80
				],
				[
					-24,
					88
				],
				[
					-24,
					88
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0263671875,
				0.3837890625,
				0.4921875,
				0.59375,
				0.607421875,
				0.6201171875,
				0.6435546875,
				0.6484375,
				0.6376953125,
				0.5849609375,
				0.4375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 20,
			"versionNonce": 591832893,
			"isDeleted": false,
			"id": "-7lqxugiQMAf-U9HUlRVa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1731.7083333333323,
			"y": 828.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 16,
			"seed": 575907934,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					16,
					-8
				],
				[
					28,
					-12
				],
				[
					40,
					-16
				],
				[
					48,
					-16
				],
				[
					48,
					-16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0244140625,
				0.2783203125,
				0.3916015625,
				0.443359375,
				0.458984375,
				0.4482421875,
				0.3486328125,
				0.134765625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 19,
			"versionNonce": 390608659,
			"isDeleted": false,
			"id": "MnkAthBZNaVbAWgzqqTas",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1795.7083333333323,
			"y": 800.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4,
			"height": 60,
			"seed": 501788062,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					24
				],
				[
					4,
					36
				],
				[
					4,
					48
				],
				[
					4,
					52
				],
				[
					4,
					60
				],
				[
					4,
					60
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0166015625,
				0.2998046875,
				0.4697265625,
				0.4873046875,
				0.4765625,
				0.4033203125,
				0.173828125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 37,
			"versionNonce": 164149149,
			"isDeleted": false,
			"id": "Jl0vBCtu1glpOmy5I5h93",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1595.7083333333323,
			"y": 960.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 108,
			"height": 84,
			"seed": 727994946,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					4,
					28
				],
				[
					8,
					48
				],
				[
					16,
					64
				],
				[
					28,
					76
				],
				[
					36,
					80
				],
				[
					48,
					76
				],
				[
					60,
					60
				],
				[
					68,
					44
				],
				[
					68,
					28
				],
				[
					68,
					8
				],
				[
					64,
					0
				],
				[
					64,
					-4
				],
				[
					64,
					16
				],
				[
					68,
					48
				],
				[
					76,
					64
				],
				[
					84,
					68
				],
				[
					92,
					68
				],
				[
					104,
					48
				],
				[
					108,
					32
				],
				[
					108,
					28
				],
				[
					104,
					16
				],
				[
					104,
					4
				],
				[
					104,
					0
				],
				[
					104,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0107421875,
				0.1923828125,
				0.3486328125,
				0.416015625,
				0.447265625,
				0.462890625,
				0.466796875,
				0.4833984375,
				0.5029296875,
				0.515625,
				0.5234375,
				0.529296875,
				0.544921875,
				0.5517578125,
				0.5546875,
				0.5576171875,
				0.556640625,
				0.556640625,
				0.55859375,
				0.5771484375,
				0.58203125,
				0.5908203125,
				0.58984375,
				0.5732421875,
				0.541015625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 1576393907,
			"isDeleted": false,
			"id": "Doz-FdDBrxY80UcIwdjGB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1723.7083333333323,
			"y": 1004.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 60,
			"seed": 354771486,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					0,
					-16
				],
				[
					8,
					-20
				],
				[
					12,
					-16
				],
				[
					12,
					-8
				],
				[
					12,
					0
				],
				[
					8,
					12
				],
				[
					0,
					24
				],
				[
					-4,
					28
				],
				[
					-4,
					36
				],
				[
					0,
					40
				],
				[
					8,
					40
				],
				[
					16,
					40
				],
				[
					28,
					36
				],
				[
					32,
					36
				],
				[
					32,
					36
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0537109375,
				0.19921875,
				0.2705078125,
				0.37109375,
				0.4013671875,
				0.4423828125,
				0.4697265625,
				0.4775390625,
				0.482421875,
				0.478515625,
				0.4814453125,
				0.4833984375,
				0.5029296875,
				0.5205078125,
				0.5302734375,
				0.529296875,
				0.5,
				0.330078125,
				0.1787109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 174701565,
			"isDeleted": false,
			"id": "4-b0DllCY0Ea72tm7I4D2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1811.7083333333323,
			"y": 952.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 84,
			"seed": 2081598530,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-12
				],
				[
					-8,
					-16
				],
				[
					-20,
					-8
				],
				[
					-28,
					8
				],
				[
					-32,
					24
				],
				[
					-32,
					40
				],
				[
					-32,
					52
				],
				[
					-32,
					64
				],
				[
					-32,
					68
				],
				[
					-32,
					68
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0224609375,
				0.2216796875,
				0.3896484375,
				0.6259765625,
				0.685546875,
				0.7119140625,
				0.703125,
				0.6376953125,
				0.353515625,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 20,
			"versionNonce": 1998442067,
			"isDeleted": false,
			"id": "c9EMifyOxE_tDtsOJH7b7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1771.7083333333323,
			"y": 1004.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 16,
			"seed": 923341506,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359187,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-4,
					-4
				],
				[
					0,
					-8
				],
				[
					12,
					-12
				],
				[
					20,
					-16
				],
				[
					32,
					-16
				],
				[
					40,
					-16
				],
				[
					40,
					-16
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.181640625,
				0.2841796875,
				0.359375,
				0.4306640625,
				0.431640625,
				0.3740234375,
				0.1796875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 26,
			"versionNonce": 1831547997,
			"isDeleted": false,
			"id": "icCwEltwM3BlHzK4H8xxg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1819.7083333333323,
			"y": 992.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28,
			"height": 52,
			"seed": 1450908034,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					0
				],
				[
					8,
					0
				],
				[
					12,
					4
				],
				[
					12,
					12
				],
				[
					8,
					28
				],
				[
					4,
					40
				],
				[
					0,
					44
				],
				[
					0,
					48
				],
				[
					0,
					52
				],
				[
					8,
					52
				],
				[
					16,
					52
				],
				[
					24,
					48
				],
				[
					24,
					48
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.103515625,
				0.388671875,
				0.42578125,
				0.4375,
				0.4453125,
				0.453125,
				0.486328125,
				0.4951171875,
				0.5107421875,
				0.53125,
				0.5517578125,
				0.515625,
				0.42578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 899058675,
			"isDeleted": false,
			"id": "yUZZfMrUEQ_tyf1e3w5JV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1723.7083333333323,
			"y": 1116.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16,
			"height": 20,
			"seed": 1619523458,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					8,
					-8
				],
				[
					8,
					-12
				],
				[
					12,
					-16
				],
				[
					12,
					-20
				],
				[
					16,
					-16
				],
				[
					12,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.13671875,
				0.3076171875,
				0.3818359375,
				0.4794921875,
				0.560546875,
				0.3505859375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 17,
			"versionNonce": 2111742141,
			"isDeleted": false,
			"id": "2ZMIRCHap3kVg2hHweVHI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1727.7083333333323,
			"y": 1160.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 855176926,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-12
				],
				[
					8,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.025390625,
				0.3662109375,
				0.482421875,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 18,
			"versionNonce": 1298568595,
			"isDeleted": false,
			"id": "q8rtV1fYgk--yCeYqk1mT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1727.7083333333323,
			"y": 1196.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 8,
			"seed": 1218762050,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-8
				],
				[
					8,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.015625,
				0.4560546875,
				0.4716796875,
				0.4765625,
				0.169921875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 38,
			"versionNonce": 304447773,
			"isDeleted": false,
			"id": "m1VwpExGJ4neFz77aXbD4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1611.7083333333323,
			"y": 1216.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104,
			"height": 80,
			"seed": 1779901506,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					4
				],
				[
					-8,
					16
				],
				[
					-4,
					36
				],
				[
					0,
					56
				],
				[
					12,
					72
				],
				[
					24,
					80
				],
				[
					36,
					80
				],
				[
					48,
					72
				],
				[
					56,
					60
				],
				[
					60,
					44
				],
				[
					60,
					24
				],
				[
					60,
					16
				],
				[
					56,
					12
				],
				[
					56,
					24
				],
				[
					56,
					48
				],
				[
					60,
					64
				],
				[
					68,
					76
				],
				[
					76,
					80
				],
				[
					84,
					76
				],
				[
					92,
					64
				],
				[
					96,
					48
				],
				[
					96,
					28
				],
				[
					92,
					16
				],
				[
					92,
					8
				],
				[
					92,
					4
				],
				[
					92,
					4
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0,
				0.2197265625,
				0.3349609375,
				0.408203125,
				0.44921875,
				0.478515625,
				0.48828125,
				0.4990234375,
				0.5224609375,
				0.533203125,
				0.537109375,
				0.5556640625,
				0.5615234375,
				0.560546875,
				0.552734375,
				0.546875,
				0.5400390625,
				0.5361328125,
				0.537109375,
				0.5341796875,
				0.5390625,
				0.544921875,
				0.55859375,
				0.5458984375,
				0.478515625,
				0.375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 29,
			"versionNonce": 767847219,
			"isDeleted": false,
			"id": "qzhsQ8GZrG2flNE5Yp5-r",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1723.7083333333323,
			"y": 1264.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 44,
			"seed": 652945602,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					24
				],
				[
					0,
					32
				],
				[
					0,
					40
				],
				[
					0,
					44
				],
				[
					0,
					40
				],
				[
					4,
					24
				],
				[
					4,
					16
				],
				[
					12,
					0
				],
				[
					20,
					12
				],
				[
					20,
					16
				],
				[
					24,
					32
				],
				[
					24,
					36
				],
				[
					32,
					8
				],
				[
					36,
					8
				],
				[
					44,
					24
				],
				[
					52,
					40
				],
				[
					52,
					40
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0244140625,
				0.4443359375,
				0.451171875,
				0.462890625,
				0.474609375,
				0.51953125,
				0.5126953125,
				0.51171875,
				0.517578125,
				0.5224609375,
				0.51953125,
				0.5341796875,
				0.546875,
				0.5478515625,
				0.5595703125,
				0.5546875,
				0.3427734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 20,
			"versionNonce": 1332827517,
			"isDeleted": false,
			"id": "xv-ZClsuoiM-JMAmTFgvU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1831.7083333333323,
			"y": 1228.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 80,
			"seed": 106824350,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-16,
					-16
				],
				[
					-20,
					-8
				],
				[
					-32,
					28
				],
				[
					-32,
					44
				],
				[
					-32,
					52
				],
				[
					-28,
					60
				],
				[
					-28,
					64
				],
				[
					-28,
					64
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.537109375,
				0.56640625,
				0.6142578125,
				0.599609375,
				0.5576171875,
				0.4052734375,
				0.3173828125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 20,
			"versionNonce": 454462675,
			"isDeleted": false,
			"id": "ilaopz9tsjeMWdUoDWcoH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1791.7083333333323,
			"y": 1272.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 24,
			"seed": 1425186782,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					8,
					-12
				],
				[
					20,
					-16
				],
				[
					32,
					-20
				],
				[
					44,
					-24
				],
				[
					48,
					-24
				],
				[
					48,
					-24
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0302734375,
				0.1689453125,
				0.322265625,
				0.384765625,
				0.41796875,
				0.3994140625,
				0.2314453125,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 38,
			"versionNonce": 822320605,
			"isDeleted": false,
			"id": "FqhibUmiJoYG5i6fNZjbb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1851.7083333333323,
			"y": 1244.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 52,
			"seed": 683472158,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					24
				],
				[
					-4,
					36
				],
				[
					-4,
					44
				],
				[
					-4,
					48
				],
				[
					-4,
					52
				],
				[
					-4,
					48
				],
				[
					0,
					36
				],
				[
					4,
					28
				],
				[
					8,
					20
				],
				[
					12,
					20
				],
				[
					16,
					24
				],
				[
					16,
					32
				],
				[
					16,
					40
				],
				[
					16,
					44
				],
				[
					16,
					48
				],
				[
					16,
					44
				],
				[
					20,
					32
				],
				[
					24,
					24
				],
				[
					28,
					20
				],
				[
					36,
					20
				],
				[
					40,
					28
				],
				[
					44,
					32
				],
				[
					44,
					40
				],
				[
					44,
					44
				],
				[
					44,
					44
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.2373046875,
				0.33984375,
				0.4033203125,
				0.447265625,
				0.46484375,
				0.509765625,
				0.5595703125,
				0.5634765625,
				0.564453125,
				0.568359375,
				0.5693359375,
				0.564453125,
				0.55859375,
				0.552734375,
				0.5556640625,
				0.5625,
				0.56640625,
				0.5654296875,
				0.5673828125,
				0.5751953125,
				0.5810546875,
				0.58203125,
				0.54296875,
				0.4677734375,
				0.3603515625,
				0
			]
		},
		{
			"type": "line",
			"version": 28,
			"versionNonce": 150174323,
			"isDeleted": false,
			"id": "4LlojJ1jPuiIo0P_QMO20",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1607.7083333333323,
			"y": 1348.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 384,
			"height": 24,
			"seed": 2020542622,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					384,
					-24
				]
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 1307433533,
			"isDeleted": false,
			"id": "ezjFSgH091ftwE7YfTH5F",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1719.7083333333323,
			"y": 1388.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 64,
			"height": 80,
			"seed": 350684894,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					0
				],
				[
					-12,
					12
				],
				[
					-12,
					28
				],
				[
					-8,
					48
				],
				[
					-8,
					52
				],
				[
					8,
					56
				],
				[
					24,
					52
				],
				[
					44,
					36
				],
				[
					52,
					16
				],
				[
					48,
					0
				],
				[
					40,
					-12
				],
				[
					20,
					-20
				],
				[
					8,
					-24
				],
				[
					-4,
					-16
				],
				[
					-12,
					-8
				],
				[
					-12,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0283203125,
				0.3056640625,
				0.3955078125,
				0.443359375,
				0.4736328125,
				0.48046875,
				0.4892578125,
				0.501953125,
				0.505859375,
				0.541015625,
				0.5546875,
				0.5595703125,
				0.5654296875,
				0.552734375,
				0.509765625,
				0.3984375,
				0.0322265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 30,
			"versionNonce": 874624019,
			"isDeleted": false,
			"id": "4HgQc7LqyHee6fpgsFuTk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1719.7083333333323,
			"y": 1528.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 80,
			"seed": 806988126,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-8,
					16
				],
				[
					-4,
					28
				],
				[
					4,
					44
				],
				[
					12,
					48
				],
				[
					20,
					48
				],
				[
					36,
					40
				],
				[
					48,
					28
				],
				[
					52,
					12
				],
				[
					52,
					-8
				],
				[
					44,
					-24
				],
				[
					32,
					-32
				],
				[
					20,
					-32
				],
				[
					12,
					-24
				],
				[
					4,
					-16
				],
				[
					0,
					-4
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0048828125,
				0.302734375,
				0.3701171875,
				0.3935546875,
				0.4208984375,
				0.4287109375,
				0.4306640625,
				0.447265625,
				0.4677734375,
				0.494140625,
				0.5341796875,
				0.5595703125,
				0.572265625,
				0.56640625,
				0.5224609375,
				0.4326171875,
				0.1806640625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 21,
			"versionNonce": 1594985117,
			"isDeleted": false,
			"id": "RsX8uEXYBdd3AzKpj56I8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1755.7083333333323,
			"y": 1664.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 20,
			"seed": 903556062,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					-4,
					-16
				],
				[
					0,
					-20
				],
				[
					4,
					-20
				],
				[
					4,
					-16
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0185546875,
				0.2421875,
				0.3857421875,
				0.4208984375,
				0.466796875,
				0.478515625,
				0.3291015625,
				0.1572265625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 18,
			"versionNonce": 2090318259,
			"isDeleted": false,
			"id": "9KNrbD7u1ryufp36e96Lz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1751.7083333333323,
			"y": 1704.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 12,
			"seed": 837068738,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-12
				],
				[
					8,
					-12
				],
				[
					12,
					-8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.01171875,
				0.2109375,
				0.3603515625,
				0.38671875,
				0.2412109375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 17,
			"versionNonce": 85995261,
			"isDeleted": false,
			"id": "Gl_neukoZrzkRwAXl3QoD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1767.7083333333323,
			"y": 1732.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8,
			"height": 12,
			"seed": 1033483970,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-8
				],
				[
					0,
					-12
				],
				[
					4,
					-12
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.0126953125,
				0.369140625,
				0.4052734375,
				0.2392578125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 31,
			"versionNonce": 2138835795,
			"isDeleted": false,
			"id": "b49KT7RMwG5nsu9BoZFmI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1727.7083333333323,
			"y": 1792.0989583333335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 104,
			"seed": 1745126174,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					12
				],
				[
					-8,
					24
				],
				[
					-8,
					40
				],
				[
					-4,
					60
				],
				[
					4,
					76
				],
				[
					12,
					80
				],
				[
					24,
					76
				],
				[
					36,
					68
				],
				[
					48,
					52
				],
				[
					52,
					32
				],
				[
					52,
					12
				],
				[
					44,
					-16
				],
				[
					32,
					-24
				],
				[
					20,
					-24
				],
				[
					12,
					-12
				],
				[
					4,
					-4
				],
				[
					0,
					8
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.037109375,
				0.23046875,
				0.283203125,
				0.3232421875,
				0.349609375,
				0.361328125,
				0.365234375,
				0.3701171875,
				0.4072265625,
				0.4560546875,
				0.513671875,
				0.55859375,
				0.609375,
				0.6298828125,
				0.6357421875,
				0.5517578125,
				0.423828125,
				0.1865234375,
				0
			]
		},
		{
			"id": "7PN4dQm2pj4bC1uWY4xKx",
			"type": "freedraw",
			"x": 1174.929053753312,
			"y": -659.978050595238,
			"width": 71.42857142857133,
			"height": 128.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1701527325,
			"version": 30,
			"versionNonce": 1318799197,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428442,
					34.285714285714334
				],
				[
					11.428571428571331,
					80
				],
				[
					11.428571428571331,
					114.28571428571422
				],
				[
					11.428571428571331,
					128.57142857142856
				],
				[
					11.428571428571331,
					122.85714285714289
				],
				[
					11.428571428571331,
					102.85714285714278
				],
				[
					17.14285714285711,
					85.71428571428567
				],
				[
					28.57142857142844,
					51.428571428571445
				],
				[
					37.14285714285711,
					45.714285714285666
				],
				[
					42.85714285714266,
					57.14285714285711
				],
				[
					45.71428571428555,
					65.71428571428567
				],
				[
					51.42857142857133,
					91.42857142857144
				],
				[
					57.14285714285711,
					111.42857142857144
				],
				[
					65.71428571428555,
					114.28571428571422
				],
				[
					71.42857142857133,
					111.42857142857144
				],
				[
					71.42857142857133,
					111.42857142857144
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				71.42857142857133,
				111.42857142857144
			]
		},
		{
			"id": "PtbDRAmWfdzaMpcxumtMK",
			"type": "freedraw",
			"x": 1266.3576251818833,
			"y": -608.5494791666665,
			"width": 37.14285714285734,
			"height": 54.28571428571422,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 22431357,
			"version": 28,
			"versionNonce": 1898260723,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.8571428571428896,
					34.28571428571422
				],
				[
					-2.8571428571428896,
					40
				],
				[
					2.8571428571428896,
					51.42857142857133
				],
				[
					8.571428571428669,
					54.28571428571422
				],
				[
					20,
					51.42857142857133
				],
				[
					25.71428571428578,
					40
				],
				[
					28.57142857142867,
					25.714285714285666
				],
				[
					22.85714285714289,
					11.428571428571331
				],
				[
					8.571428571428669,
					0
				],
				[
					-2.8571428571428896,
					0
				],
				[
					-5.714285714285779,
					0
				],
				[
					-8.571428571428669,
					2.8571428571428896
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-8.571428571428669,
				2.8571428571428896
			]
		},
		{
			"id": "ifRDjAYOdFUrg44Fjfd05",
			"type": "freedraw",
			"x": 1317.7861966104547,
			"y": -674.2637648809523,
			"width": 28.57142857142867,
			"height": 114.28571428571433,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 922368381,
			"version": 23,
			"versionNonce": 2111067069,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.8571428571426623,
					5.714285714285779
				],
				[
					-5.714285714285552,
					14.285714285714334
				],
				[
					-11.428571428571331,
					42.85714285714289
				],
				[
					-11.428571428571331,
					54.285714285714334
				],
				[
					-11.428571428571331,
					82.85714285714289
				],
				[
					-2.8571428571426623,
					105.71428571428578
				],
				[
					8.571428571428669,
					114.28571428571433
				],
				[
					17.142857142857338,
					114.28571428571433
				],
				[
					17.142857142857338,
					114.28571428571433
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				17.142857142857338,
				114.28571428571433
			]
		},
		{
			"id": "lPbcz30QjV8MPmARBr8Uk",
			"type": "freedraw",
			"x": 1374.929053753312,
			"y": -614.2637648809523,
			"width": 80,
			"height": 65.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 99812595,
			"version": 30,
			"versionNonce": 924422803,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-17.142857142857338,
					2.8571428571428896
				],
				[
					-20,
					8.571428571428669
				],
				[
					-28.57142857142867,
					28.57142857142867
				],
				[
					-28.57142857142867,
					51.428571428571445
				],
				[
					-22.85714285714289,
					65.71428571428578
				],
				[
					-2.8571428571428896,
					65.71428571428578
				],
				[
					5.714285714285552,
					57.14285714285711
				],
				[
					14.28571428571422,
					40
				],
				[
					17.14285714285711,
					20
				],
				[
					17.14285714285711,
					17.14285714285711
				],
				[
					20,
					45.71428571428578
				],
				[
					28.57142857142844,
					57.14285714285711
				],
				[
					31.42857142857133,
					60
				],
				[
					48.57142857142844,
					65.71428571428578
				],
				[
					51.42857142857133,
					62.85714285714289
				],
				[
					51.42857142857133,
					62.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				51.42857142857133,
				62.85714285714289
			]
		},
		{
			"id": "VpH_h3sa-CpSMbWidxxyt",
			"type": "freedraw",
			"x": 1463.5004823247405,
			"y": -571.4066220238094,
			"width": 20,
			"height": 51.428571428571445,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1238756243,
			"version": 19,
			"versionNonce": 250401821,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8.571428571428442,
					28.571428571428555
				],
				[
					-14.28571428571422,
					42.85714285714289
				],
				[
					-17.14285714285711,
					51.428571428571445
				],
				[
					-20,
					48.571428571428555
				],
				[
					-20,
					48.571428571428555
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-20,
				48.571428571428555
			]
		},
		{
			"id": "GtDhGxQr6H2JEwHL-Tyd0",
			"type": "freedraw",
			"x": 1454.929053753312,
			"y": -585.6923363095236,
			"width": 0,
			"height": 17.142857142857224,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 866853949,
			"version": 17,
			"versionNonce": 1108330547,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-17.142857142857224
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0,
				-17.142857142857224
			]
		},
		{
			"id": "EEXptMQdMiNDpWLzVE0ze",
			"type": "freedraw",
			"x": 1554.929053753312,
			"y": -608.5494791666665,
			"width": 5.714285714285779,
			"height": 8.571428571428669,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1374871891,
			"version": 17,
			"versionNonce": 2111195261,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.714285714285779,
					-8.571428571428669
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-5.714285714285779,
				-8.571428571428669
			]
		},
		{
			"id": "qlxgnUN1sE9BbojwV9ku8",
			"type": "freedraw",
			"x": 1563.5004823247405,
			"y": -619.978050595238,
			"width": 45.71428571428555,
			"height": 71.42857142857144,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 52157981,
			"version": 25,
			"versionNonce": 669927891,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.714285714285552,
					-2.8571428571428896
				],
				[
					-8.571428571428442,
					-2.8571428571428896
				],
				[
					-11.428571428571331,
					-2.8571428571428896
				],
				[
					-14.28571428571422,
					0
				],
				[
					-22.85714285714289,
					11.428571428571445
				],
				[
					-22.85714285714289,
					17.14285714285711
				],
				[
					-28.57142857142844,
					48.571428571428555
				],
				[
					-28.57142857142844,
					54.285714285714334
				],
				[
					-20,
					68.57142857142856
				],
				[
					-2.8571428571428896,
					68.57142857142856
				],
				[
					14.285714285714448,
					60
				],
				[
					17.14285714285711,
					54.285714285714334
				],
				[
					17.14285714285711,
					54.285714285714334
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				17.14285714285711,
				54.285714285714334
			]
		},
		{
			"id": "tfj44Eg5SytzDoYAGQU3l",
			"type": "freedraw",
			"x": 1609.2147680390262,
			"y": -648.5494791666665,
			"width": 151.42857142857156,
			"height": 97.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 943908243,
			"version": 49,
			"versionNonce": 1280454877,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					14.28571428571422,
					94.28571428571422
				],
				[
					22.85714285714289,
					94.28571428571422
				],
				[
					42.85714285714289,
					88.57142857142856
				],
				[
					62.85714285714289,
					65.71428571428567
				],
				[
					65.71428571428578,
					42.85714285714289
				],
				[
					48.57142857142867,
					14.28571428571422
				],
				[
					25.71428571428578,
					5.714285714285666
				],
				[
					8.571428571428669,
					11.428571428571331
				],
				[
					-2.8571428571428896,
					25.714285714285666
				],
				[
					0,
					37.14285714285711
				],
				[
					11.428571428571331,
					48.571428571428555
				],
				[
					20,
					60
				],
				[
					28.57142857142867,
					71.42857142857133
				],
				[
					40,
					85.71428571428567
				],
				[
					51.42857142857133,
					97.14285714285711
				],
				[
					68.57142857142867,
					94.28571428571422
				],
				[
					74.28571428571422,
					88.57142857142856
				],
				[
					85.71428571428578,
					65.71428571428567
				],
				[
					91.42857142857133,
					51.42857142857133
				],
				[
					97.14285714285711,
					45.714285714285666
				],
				[
					100,
					51.42857142857133
				],
				[
					105.71428571428578,
					62.85714285714289
				],
				[
					108.57142857142867,
					68.57142857142856
				],
				[
					111.42857142857133,
					68.57142857142856
				],
				[
					122.85714285714289,
					62.85714285714289
				],
				[
					128.57142857142867,
					57.14285714285711
				],
				[
					134.28571428571422,
					42.85714285714289
				],
				[
					137.1428571428571,
					34.28571428571422
				],
				[
					131.42857142857133,
					28.571428571428555
				],
				[
					120,
					28.571428571428555
				],
				[
					111.42857142857133,
					37.14285714285711
				],
				[
					100,
					60
				],
				[
					97.14285714285711,
					80
				],
				[
					102.85714285714289,
					91.42857142857133
				],
				[
					120,
					94.28571428571422
				],
				[
					140,
					80
				],
				[
					148.57142857142867,
					57.14285714285711
				],
				[
					148.57142857142867,
					57.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				148.57142857142867,
				57.14285714285711
			]
		},
		{
			"id": "cL_P2CkvG26dInQEbMCjf",
			"type": "freedraw",
			"x": 1740.6433394675976,
			"y": -617.1209077380952,
			"width": 28.57142857142867,
			"height": 37.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 88210963,
			"version": 12,
			"versionNonce": 2110494579,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					28.57142857142867,
					-37.14285714285711
				],
				[
					28.57142857142867,
					-37.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				28.57142857142867,
				-37.14285714285711
			]
		},
		{
			"id": "dSeptQhXCmig-4tQ5gxFI",
			"type": "freedraw",
			"x": 1806.3576251818836,
			"y": -665.6923363095236,
			"width": 25.714285714285325,
			"height": 111.42857142857133,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 143775059,
			"version": 16,
			"versionNonce": 1207045437,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.7142857142853245,
					25.714285714285666
				],
				[
					8.571428571428442,
					34.28571428571422
				],
				[
					14.28571428571422,
					62.857142857142776
				],
				[
					25.714285714285325,
					94.28571428571422
				],
				[
					25.714285714285325,
					108.57142857142844
				],
				[
					25.714285714285325,
					111.42857142857133
				],
				[
					25.714285714285325,
					111.42857142857133
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				25.714285714285325,
				111.42857142857133
			]
		},
		{
			"id": "7mErHKzU0lVOu-TWo5FLQ",
			"type": "freedraw",
			"x": 1794.929053753312,
			"y": -579.978050595238,
			"width": 140,
			"height": 88.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1278936797,
			"version": 34,
			"versionNonce": 1911435539,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					-31.428571428571445
				],
				[
					20,
					-40
				],
				[
					40,
					-42.85714285714289
				],
				[
					48.57142857142844,
					-25.714285714285666
				],
				[
					51.42857142857156,
					-20
				],
				[
					51.42857142857156,
					-5.714285714285666
				],
				[
					60,
					5.714285714285666
				],
				[
					68.57142857142844,
					2.857142857142776
				],
				[
					80,
					-11.428571428571445
				],
				[
					88.57142857142844,
					-31.428571428571445
				],
				[
					88.57142857142844,
					-40
				],
				[
					88.57142857142844,
					-42.85714285714289
				],
				[
					91.42857142857156,
					-31.428571428571445
				],
				[
					97.14285714285688,
					-17.142857142857224
				],
				[
					111.42857142857156,
					-5.714285714285666
				],
				[
					122.85714285714266,
					-5.714285714285666
				],
				[
					134.28571428571422,
					-14.285714285714334
				],
				[
					140,
					-31.428571428571445
				],
				[
					134.28571428571422,
					-57.142857142857224
				],
				[
					125.71428571428578,
					-77.14285714285722
				],
				[
					122.85714285714266,
					-82.85714285714289
				],
				[
					120,
					-71.42857142857144
				],
				[
					122.85714285714266,
					-48.571428571428555
				],
				[
					128.57142857142844,
					-22.85714285714289
				],
				[
					134.28571428571422,
					-11.428571428571445
				],
				[
					134.28571428571422,
					-11.428571428571445
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				134.28571428571422,
				-11.428571428571445
			]
		},
		{
			"id": "1XBwtALb6l4ZN144IOR6T",
			"type": "freedraw",
			"x": 1966.3576251818836,
			"y": -574.2637648809523,
			"width": 2.857142857143117,
			"height": 8.571428571428555,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1372377117,
			"version": 11,
			"versionNonce": 269966749,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.857142857143117,
					-5.714285714285666
				],
				[
					-2.857142857143117,
					-8.571428571428555
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-2.857142857143117,
				-8.571428571428555
			]
		},
		{
			"id": "N1PaBPOk90Dw88vZvKcjz",
			"type": "freedraw",
			"x": 1949.2147680390262,
			"y": -671.4066220238094,
			"width": 34.28571428571422,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1686341949,
			"version": 14,
			"versionNonce": 634164915,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359188,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					28.57142857142844,
					-8.571428571428555
				],
				[
					31.42857142857156,
					-8.571428571428555
				],
				[
					34.28571428571422,
					-5.714285714285779
				],
				[
					34.28571428571422,
					5.714285714285779
				],
				[
					34.28571428571422,
					8.571428571428555
				],
				[
					17.142857142857338,
					25.71428571428578
				],
				[
					8.571428571428442,
					31.428571428571445
				],
				[
					8.571428571428442,
					31.428571428571445
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428442,
				31.428571428571445
			]
		},
		{
			"id": "obd9hsTnzQVlhFNraFU9W",
			"type": "freedraw",
			"x": 977.7861966104547,
			"y": -674.2637648809523,
			"width": 68.57142857142867,
			"height": 28.571428571428555,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2037069021,
			"version": 12,
			"versionNonce": 1804185373,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					51.42857142857156,
					-20
				],
				[
					68.57142857142867,
					-25.714285714285666
				],
				[
					62.85714285714289,
					-28.571428571428555
				],
				[
					60,
					-28.571428571428555
				],
				[
					60,
					-28.571428571428555
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				60,
				-28.571428571428555
			]
		},
		{
			"id": "NeQt4B0pooonjjxrLWHS8",
			"type": "freedraw",
			"x": 989.2147680390262,
			"y": -688.5494791666665,
			"width": 77.14285714285711,
			"height": 108.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 657458259,
			"version": 23,
			"versionNonce": 780279091,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-17.14285714285711,
					25.714285714285666
				],
				[
					-22.85714285714289,
					42.85714285714289
				],
				[
					-22.85714285714289,
					65.71428571428567
				],
				[
					-20,
					80
				],
				[
					-14.285714285714448,
					94.28571428571422
				],
				[
					-5.714285714285779,
					102.85714285714289
				],
				[
					8.571428571428442,
					108.57142857142856
				],
				[
					20,
					108.57142857142856
				],
				[
					31.42857142857133,
					105.71428571428567
				],
				[
					37.14285714285711,
					102.85714285714289
				],
				[
					48.57142857142844,
					94.28571428571422
				],
				[
					51.42857142857133,
					94.28571428571422
				],
				[
					54.28571428571422,
					88.57142857142856
				],
				[
					51.42857142857133,
					85.71428571428567
				],
				[
					51.42857142857133,
					82.85714285714289
				],
				[
					51.42857142857133,
					82.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				51.42857142857133,
				82.85714285714289
			]
		},
		{
			"id": "cNCWlVhpP3Ua8lEbS7mb3",
			"type": "freedraw",
			"x": 1054.929053753312,
			"y": -691.4066220238094,
			"width": 5.714285714285552,
			"height": 120,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 36347635,
			"version": 18,
			"versionNonce": 136299389,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285552,
					-2.8571428571428896
				],
				[
					5.714285714285552,
					0
				],
				[
					5.714285714285552,
					20
				],
				[
					2.8571428571426623,
					37.14285714285711
				],
				[
					2.8571428571426623,
					62.85714285714289
				],
				[
					2.8571428571426623,
					85.71428571428578
				],
				[
					2.8571428571426623,
					108.57142857142856
				],
				[
					2.8571428571426623,
					114.28571428571422
				],
				[
					2.8571428571426623,
					117.14285714285711
				],
				[
					2.8571428571426623,
					114.28571428571422
				],
				[
					2.8571428571426623,
					114.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.8571428571426623,
				114.28571428571422
			]
		},
		{
			"id": "oUYItgIy1fi5OufT1hT7C",
			"type": "freedraw",
			"x": 1103.5004823247405,
			"y": -674.2637648809523,
			"width": 14.285714285714448,
			"height": 94.28571428571433,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1920011261,
			"version": 17,
			"versionNonce": 1565392595,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285779,
					2.8571428571428896
				],
				[
					2.8571428571428896,
					25.71428571428578
				],
				[
					2.8571428571428896,
					60
				],
				[
					2.8571428571428896,
					82.85714285714289
				],
				[
					5.714285714285779,
					94.28571428571433
				],
				[
					8.571428571428669,
					94.28571428571433
				],
				[
					8.571428571428669,
					91.42857142857144
				],
				[
					0,
					82.85714285714289
				],
				[
					-5.714285714285779,
					77.14285714285711
				],
				[
					-5.714285714285779,
					77.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-5.714285714285779,
				77.14285714285711
			]
		},
		{
			"id": "6VGjH7LFLQHxwCzj8W609",
			"type": "freedraw",
			"x": 1057.7861966104547,
			"y": -622.8351934523808,
			"width": 68.57142857142867,
			"height": 22.857142857142776,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2084121149,
			"version": 12,
			"versionNonce": 1706314717,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					37.14285714285734,
					-8.571428571428555
				],
				[
					42.85714285714289,
					-8.571428571428555
				],
				[
					60,
					-14.285714285714334
				],
				[
					68.57142857142867,
					-22.857142857142776
				],
				[
					68.57142857142867,
					-22.857142857142776
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				68.57142857142867,
				-22.857142857142776
			]
		},
		{
			"id": "lyQo5wnJ8Bb4nc6Y886mZ",
			"type": "freedraw",
			"x": 1174.929053753312,
			"y": -691.4066220238094,
			"width": 8.571428571428442,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 118806771,
			"version": 16,
			"versionNonce": 929868915,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571426623,
					11.428571428571445
				],
				[
					2.8571428571426623,
					25.71428571428578
				],
				[
					5.714285714285552,
					40
				],
				[
					5.714285714285552,
					42.85714285714289
				],
				[
					8.571428571428442,
					54.28571428571422
				],
				[
					8.571428571428442,
					60
				],
				[
					8.571428571428442,
					57.14285714285711
				],
				[
					5.714285714285552,
					54.28571428571422
				],
				[
					5.714285714285552,
					54.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				5.714285714285552,
				54.28571428571422
			]
		},
		{
			"id": "jht_JiDFBH2iwfPGwAanh",
			"type": "freedraw",
			"x": 1149.2147680390262,
			"y": -662.8351934523808,
			"width": 45.71428571428578,
			"height": 14.285714285714334,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 103329181,
			"version": 15,
			"versionNonce": 1146669117,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285779,
					0
				],
				[
					8.571428571428442,
					0
				],
				[
					20,
					-2.857142857142776
				],
				[
					28.57142857142844,
					-5.714285714285666
				],
				[
					42.85714285714289,
					-8.571428571428555
				],
				[
					45.71428571428578,
					-11.428571428571445
				],
				[
					45.71428571428578,
					-14.285714285714334
				],
				[
					45.71428571428578,
					-14.285714285714334
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428578,
				-14.285714285714334
			]
		},
		{
			"id": "Yazyw84qp_t2Gt8GtF4mP",
			"type": "freedraw",
			"x": 1194.929053753312,
			"y": -691.4066220238094,
			"width": 51.42857142857156,
			"height": 134.28571428571433,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 51874685,
			"version": 25,
			"versionNonce": 1621403155,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-2.8571428571428896
				],
				[
					5.714285714285552,
					-5.714285714285779
				],
				[
					14.28571428571422,
					-5.714285714285779
				],
				[
					22.857142857142662,
					0
				],
				[
					25.714285714285552,
					8.571428571428555
				],
				[
					31.42857142857133,
					34.28571428571422
				],
				[
					34.28571428571422,
					57.14285714285711
				],
				[
					34.28571428571422,
					80
				],
				[
					34.28571428571422,
					100
				],
				[
					34.28571428571422,
					117.14285714285711
				],
				[
					31.42857142857133,
					122.85714285714289
				],
				[
					28.57142857142844,
					122.85714285714289
				],
				[
					20,
					122.85714285714289
				],
				[
					2.8571428571426623,
					125.71428571428578
				],
				[
					-8.571428571428669,
					128.57142857142856
				],
				[
					-14.285714285714448,
					128.57142857142856
				],
				[
					-17.142857142857338,
					128.57142857142856
				],
				[
					-17.142857142857338,
					128.57142857142856
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-17.142857142857338,
				128.57142857142856
			]
		},
		{
			"id": "c6slhsxZx3rzz7WN5lxIt",
			"type": "freedraw",
			"x": 1257.7861966104547,
			"y": -682.8351934523808,
			"width": 48.57142857142867,
			"height": 25.714285714285666,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 527221565,
			"version": 12,
			"versionNonce": 1710143645,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					22.85714285714289,
					-14.285714285714334
				],
				[
					42.85714285714289,
					-17.14285714285711
				],
				[
					48.57142857142867,
					-20
				],
				[
					45.71428571428578,
					-25.714285714285666
				],
				[
					45.71428571428578,
					-25.714285714285666
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428578,
				-25.714285714285666
			]
		},
		{
			"id": "iEUshoFEq3p5ylTUpCNqO",
			"type": "freedraw",
			"x": 1280.6433394675976,
			"y": -711.4066220238094,
			"width": 68.57142857142867,
			"height": 125.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1017294835,
			"version": 20,
			"versionNonce": 1072458675,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-14.28571428571422,
					20
				],
				[
					-20,
					37.14285714285711
				],
				[
					-20,
					57.14285714285711
				],
				[
					-22.85714285714289,
					80
				],
				[
					-17.14285714285711,
					102.85714285714289
				],
				[
					-11.428571428571331,
					117.14285714285711
				],
				[
					-2.8571428571428896,
					122.85714285714289
				],
				[
					8.571428571428669,
					125.71428571428578
				],
				[
					17.14285714285711,
					125.71428571428578
				],
				[
					31.42857142857156,
					122.85714285714289
				],
				[
					42.85714285714289,
					120
				],
				[
					45.71428571428578,
					120
				],
				[
					45.71428571428578,
					120
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428578,
				120
			]
		},
		{
			"id": "6TUNHwo8Jos3Vk3JVqaGx",
			"type": "freedraw",
			"x": 1380.6433394675976,
			"y": -702.8351934523808,
			"width": 8.571428571428669,
			"height": 91.42857142857144,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2051728221,
			"version": 15,
			"versionNonce": 1411882237,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					28.571428571428555
				],
				[
					2.8571428571428896,
					34.285714285714334
				],
				[
					2.8571428571428896,
					62.85714285714289
				],
				[
					2.8571428571428896,
					85.71428571428567
				],
				[
					5.714285714285779,
					91.42857142857144
				],
				[
					8.571428571428669,
					85.71428571428567
				],
				[
					8.571428571428669,
					80
				],
				[
					8.571428571428669,
					80
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428669,
				80
			]
		},
		{
			"id": "uXJ3bhLYPMD-RvwAt_lgt",
			"type": "freedraw",
			"x": 1417.7861966104547,
			"y": -699.978050595238,
			"width": 14.285714285714448,
			"height": 100,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 643836221,
			"version": 16,
			"versionNonce": 426409299,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					8.571428571428555
				],
				[
					2.8571428571428896,
					20
				],
				[
					5.714285714285779,
					51.428571428571445
				],
				[
					11.428571428571558,
					74.28571428571433
				],
				[
					11.428571428571558,
					85.71428571428567
				],
				[
					14.285714285714448,
					100
				],
				[
					14.285714285714448,
					94.28571428571433
				],
				[
					11.428571428571558,
					85.71428571428567
				],
				[
					11.428571428571558,
					85.71428571428567
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				11.428571428571558,
				85.71428571428567
			]
		},
		{
			"id": "4iZhb-3s6aZac-2WwLQqZ",
			"type": "freedraw",
			"x": 1389.2147680390262,
			"y": -648.5494791666665,
			"width": 65.71428571428578,
			"height": 14.285714285714334,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 670648627,
			"version": 14,
			"versionNonce": 1719989597,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					0
				],
				[
					17.14285714285711,
					-2.8571428571428896
				],
				[
					31.42857142857133,
					-5.714285714285779
				],
				[
					48.57142857142844,
					-11.428571428571445
				],
				[
					57.14285714285711,
					-11.428571428571445
				],
				[
					65.71428571428578,
					-14.285714285714334
				],
				[
					65.71428571428578,
					-14.285714285714334
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				65.71428571428578,
				-14.285714285714334
			]
		},
		{
			"id": "ssM5WPUKFW8PIOX3la9hK",
			"type": "freedraw",
			"x": 1477.7861966104547,
			"y": -697.1209077380952,
			"width": 57.14285714285711,
			"height": 117.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2057253117,
			"version": 30,
			"versionNonce": 1752521459,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					14.285714285714334
				],
				[
					5.714285714285779,
					20
				],
				[
					5.714285714285779,
					45.71428571428578
				],
				[
					8.571428571428669,
					71.42857142857156
				],
				[
					11.428571428571558,
					88.57142857142867
				],
				[
					14.285714285714448,
					94.28571428571433
				],
				[
					14.285714285714448,
					91.42857142857156
				],
				[
					11.428571428571558,
					80
				],
				[
					0,
					51.42857142857156
				],
				[
					-2.8571428571426623,
					37.142857142857224
				],
				[
					-5.714285714285552,
					11.428571428571558
				],
				[
					2.8571428571428896,
					-11.428571428571331
				],
				[
					22.85714285714289,
					-22.857142857142776
				],
				[
					37.14285714285734,
					-20
				],
				[
					51.42857142857156,
					-2.857142857142776
				],
				[
					51.42857142857156,
					14.285714285714334
				],
				[
					45.71428571428578,
					28.57142857142867
				],
				[
					34.28571428571445,
					37.142857142857224
				],
				[
					28.57142857142867,
					40
				],
				[
					17.142857142857338,
					40
				],
				[
					8.571428571428669,
					37.142857142857224
				],
				[
					5.714285714285779,
					28.57142857142867
				],
				[
					5.714285714285779,
					28.57142857142867
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				5.714285714285779,
				28.57142857142867
			]
		},
		{
			"id": "-niuuvHcrZkRLzY_CmQTI",
			"type": "freedraw",
			"x": 1537.7861966104547,
			"y": -697.1209077380952,
			"width": 54.28571428571422,
			"height": 88.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 442901715,
			"version": 23,
			"versionNonce": 140001725,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.714285714285552,
					17.142857142857224
				],
				[
					-5.714285714285552,
					25.71428571428578
				],
				[
					-2.8571428571426623,
					62.85714285714289
				],
				[
					8.571428571428669,
					82.85714285714289
				],
				[
					25.71428571428578,
					85.71428571428578
				],
				[
					40.00000000000023,
					71.42857142857156
				],
				[
					48.57142857142867,
					51.42857142857156
				],
				[
					42.85714285714289,
					22.85714285714289
				],
				[
					40.00000000000023,
					17.142857142857224
				],
				[
					34.28571428571445,
					11.428571428571558
				],
				[
					20.000000000000227,
					0
				],
				[
					11.428571428571558,
					-2.857142857142776
				],
				[
					0,
					0
				],
				[
					-2.8571428571426623,
					5.714285714285779
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-2.8571428571426623,
				5.714285714285779
			]
		},
		{
			"id": "Lkin9dM2nnJ9vaDNQhdaH",
			"type": "freedraw",
			"x": 1609.2147680390262,
			"y": -665.6923363095236,
			"width": 48.57142857142867,
			"height": 94.28571428571422,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1196437363,
			"version": 24,
			"versionNonce": 2039710867,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					40
				],
				[
					5.714285714285779,
					42.857142857142776
				],
				[
					17.14285714285711,
					45.714285714285666
				],
				[
					31.42857142857133,
					42.857142857142776
				],
				[
					40,
					34.28571428571422
				],
				[
					45.71428571428578,
					22.857142857142776
				],
				[
					48.57142857142867,
					11.428571428571331
				],
				[
					45.71428571428578,
					5.714285714285666
				],
				[
					42.85714285714289,
					11.428571428571331
				],
				[
					42.85714285714289,
					25.714285714285666
				],
				[
					42.85714285714289,
					37.14285714285711
				],
				[
					40,
					65.71428571428567
				],
				[
					40,
					82.85714285714278
				],
				[
					40,
					91.42857142857133
				],
				[
					37.14285714285711,
					94.28571428571422
				],
				[
					37.14285714285711,
					85.71428571428567
				],
				[
					37.14285714285711,
					85.71428571428567
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				37.14285714285711,
				85.71428571428567
			]
		},
		{
			"id": "7ffE7dAybh4pd8eZJal6v",
			"type": "freedraw",
			"x": 1672.0719108961691,
			"y": -705.6923363095236,
			"width": 57.14285714285711,
			"height": 57.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1237719197,
			"version": 25,
			"versionNonce": 1052967453,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					-11.428571428571558
				],
				[
					5.714285714285779,
					-14.285714285714334
				],
				[
					14.28571428571422,
					-20
				],
				[
					22.85714285714289,
					-22.85714285714289
				],
				[
					34.28571428571422,
					-17.142857142857224
				],
				[
					40,
					-8.571428571428669
				],
				[
					40,
					5.714285714285666
				],
				[
					34.28571428571422,
					20
				],
				[
					22.85714285714289,
					31.42857142857133
				],
				[
					17.14285714285711,
					31.42857142857133
				],
				[
					8.571428571428442,
					22.857142857142776
				],
				[
					11.428571428571331,
					17.14285714285711
				],
				[
					17.14285714285711,
					14.28571428571422
				],
				[
					31.42857142857133,
					20
				],
				[
					42.85714285714289,
					28.57142857142844
				],
				[
					51.42857142857133,
					34.28571428571422
				],
				[
					57.14285714285711,
					34.28571428571422
				],
				[
					57.14285714285711,
					34.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				57.14285714285711,
				34.28571428571422
			]
		},
		{
			"id": "75oLb3M3oDb7wQMySBvZl",
			"type": "freedraw",
			"x": 1740.6433394675976,
			"y": -702.8351934523808,
			"width": 48.57142857142867,
			"height": 14.285714285714334,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 293824605,
			"version": 15,
			"versionNonce": 1148942899,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					0
				],
				[
					8.571428571428669,
					0
				],
				[
					25.71428571428578,
					-2.857142857142776
				],
				[
					31.42857142857156,
					-5.714285714285666
				],
				[
					40,
					-8.571428571428555
				],
				[
					45.71428571428578,
					-11.428571428571445
				],
				[
					48.57142857142867,
					-14.285714285714334
				],
				[
					48.57142857142867,
					-14.285714285714334
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				48.57142857142867,
				-14.285714285714334
			]
		},
		{
			"id": "1YsCEeLZddaY9rTo01jOj",
			"type": "freedraw",
			"x": 1783.5004823247405,
			"y": -737.1209077380952,
			"width": 54.28571428571422,
			"height": 145.71428571428567,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 816156221,
			"version": 23,
			"versionNonce": 1857468029,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285779,
					-5.714285714285666
				],
				[
					11.428571428571558,
					-5.714285714285666
				],
				[
					20,
					5.714285714285779
				],
				[
					31.42857142857156,
					22.85714285714289
				],
				[
					37.14285714285734,
					48.57142857142867
				],
				[
					42.85714285714312,
					74.28571428571433
				],
				[
					45.71428571428578,
					85.71428571428578
				],
				[
					51.42857142857156,
					108.57142857142867
				],
				[
					54.28571428571422,
					122.85714285714289
				],
				[
					51.42857142857156,
					131.42857142857156
				],
				[
					40,
					137.14285714285722
				],
				[
					25.71428571428578,
					140
				],
				[
					14.285714285714448,
					140
				],
				[
					2.8571428571428896,
					140
				],
				[
					2.8571428571428896,
					137.14285714285722
				],
				[
					2.8571428571428896,
					137.14285714285722
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.8571428571428896,
				137.14285714285722
			]
		},
		{
			"id": "4EWsiDDLpVblZm3Ti0Tpw",
			"type": "freedraw",
			"x": 1132.0719108961691,
			"y": -534.2637648809523,
			"width": 699.9999999999998,
			"height": 11.428571428571445,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1313116573,
			"version": 17,
			"versionNonce": 101956563,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					22.85714285714289,
					0
				],
				[
					51.42857142857133,
					0
				],
				[
					97.14285714285711,
					0
				],
				[
					194.28571428571422,
					0
				],
				[
					254.28571428571422,
					2.8571428571428896
				],
				[
					380,
					8.571428571428555
				],
				[
					665.7142857142858,
					11.428571428571445
				],
				[
					699.9999999999998,
					8.571428571428555
				],
				[
					679.9999999999998,
					5.714285714285779
				],
				[
					679.9999999999998,
					5.714285714285779
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				679.9999999999998,
				5.714285714285779
			]
		},
		{
			"id": "uTA6D8smdeCaLX-bm_evN",
			"type": "freedraw",
			"x": 1263.5004823247405,
			"y": -485.69233630952374,
			"width": 74.28571428571445,
			"height": 14.285714285714334,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 559151069,
			"version": 18,
			"versionNonce": 1660215005,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					2.8571428571428896
				],
				[
					-2.8571428571428896,
					5.714285714285779
				],
				[
					-5.714285714285779,
					5.714285714285779
				],
				[
					-5.714285714285779,
					8.571428571428669
				],
				[
					-2.8571428571428896,
					14.285714285714334
				],
				[
					20,
					11.428571428571445
				],
				[
					51.42857142857156,
					5.714285714285779
				],
				[
					57.14285714285711,
					5.714285714285779
				],
				[
					68.57142857142867,
					0
				],
				[
					54.28571428571422,
					0
				],
				[
					54.28571428571422,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				54.28571428571422,
				0
			]
		},
		{
			"id": "LuRSRGxhi6kKmafFXpfBX",
			"type": "freedraw",
			"x": 1257.7861966104547,
			"y": -471.4066220238094,
			"width": 74.28571428571422,
			"height": 120,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 236817971,
			"version": 21,
			"versionNonce": 443730291,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-11.428571428571331,
					28.571428571428555
				],
				[
					-14.28571428571422,
					42.85714285714289
				],
				[
					-14.28571428571422,
					74.28571428571433
				],
				[
					-11.428571428571331,
					94.28571428571433
				],
				[
					-8.571428571428442,
					105.71428571428578
				],
				[
					2.8571428571428896,
					117.14285714285711
				],
				[
					14.285714285714448,
					120
				],
				[
					28.57142857142867,
					120
				],
				[
					37.14285714285734,
					120
				],
				[
					51.42857142857156,
					114.28571428571433
				],
				[
					57.14285714285734,
					108.57142857142856
				],
				[
					60,
					105.71428571428578
				],
				[
					60,
					102.85714285714289
				],
				[
					60,
					102.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				60,
				102.85714285714289
			]
		},
		{
			"id": "oJvuWwa9aNvTjAhm-56dw",
			"type": "freedraw",
			"x": 1334.929053753312,
			"y": -457.12090773809507,
			"width": 2.8571428571426623,
			"height": 91.42857142857144,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 752216883,
			"version": 16,
			"versionNonce": 302971709,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571426623,
					5.714285714285666
				],
				[
					2.8571428571426623,
					11.428571428571331
				],
				[
					2.8571428571426623,
					31.428571428571445
				],
				[
					0,
					54.28571428571422
				],
				[
					0,
					74.28571428571422
				],
				[
					0,
					85.71428571428567
				],
				[
					0,
					91.42857142857144
				],
				[
					2.8571428571426623,
					88.57142857142856
				],
				[
					2.8571428571426623,
					88.57142857142856
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.8571428571426623,
				88.57142857142856
			]
		},
		{
			"id": "9v9UO5frVe47APtSROo50",
			"type": "freedraw",
			"x": 1386.3576251818833,
			"y": -465.69233630952374,
			"width": 11.428571428571331,
			"height": 105.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1464977245,
			"version": 17,
			"versionNonce": 383722259,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428669,
					11.428571428571445
				],
				[
					8.571428571428669,
					17.142857142857224
				],
				[
					5.714285714285779,
					45.71428571428578
				],
				[
					5.714285714285779,
					74.28571428571433
				],
				[
					8.571428571428669,
					94.28571428571433
				],
				[
					8.571428571428669,
					105.71428571428578
				],
				[
					11.428571428571331,
					105.71428571428578
				],
				[
					8.571428571428669,
					102.85714285714289
				],
				[
					2.8571428571428896,
					97.14285714285722
				],
				[
					2.8571428571428896,
					97.14285714285722
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.8571428571428896,
				97.14285714285722
			]
		},
		{
			"id": "kIqBmvaIHBcj57b97xCIY",
			"type": "freedraw",
			"x": 1346.3576251818833,
			"y": -405.6923363095236,
			"width": 65.71428571428578,
			"height": 2.8571428571428896,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1038998941,
			"version": 16,
			"versionNonce": 610700189,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8.571428571428669,
					0
				],
				[
					-5.714285714285779,
					0
				],
				[
					14.28571428571422,
					0
				],
				[
					25.71428571428578,
					0
				],
				[
					31.42857142857133,
					-2.8571428571428896
				],
				[
					45.71428571428578,
					-2.8571428571428896
				],
				[
					54.28571428571422,
					-2.8571428571428896
				],
				[
					57.14285714285711,
					-2.8571428571428896
				],
				[
					57.14285714285711,
					-2.8571428571428896
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				57.14285714285711,
				-2.8571428571428896
			]
		},
		{
			"id": "k2OSRoL0EDPnURCGYLDuG",
			"type": "freedraw",
			"x": 1437.7861966104547,
			"y": -388.5494791666665,
			"width": 48.57142857142867,
			"height": 74.28571428571433,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 828016339,
			"version": 25,
			"versionNonce": 600787123,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-14.285714285714334
				],
				[
					2.8571428571428896,
					-17.14285714285711
				],
				[
					8.571428571428669,
					-25.71428571428578
				],
				[
					22.85714285714289,
					-34.285714285714334
				],
				[
					31.42857142857156,
					-25.71428571428578
				],
				[
					25.71428571428578,
					5.714285714285666
				],
				[
					11.428571428571558,
					22.85714285714289
				],
				[
					-2.8571428571426623,
					34.28571428571422
				],
				[
					-11.428571428571331,
					31.428571428571445
				],
				[
					-11.428571428571331,
					25.714285714285666
				],
				[
					-5.714285714285552,
					22.85714285714289
				],
				[
					5.714285714285779,
					22.85714285714289
				],
				[
					17.142857142857338,
					25.714285714285666
				],
				[
					25.71428571428578,
					34.28571428571422
				],
				[
					31.42857142857156,
					40
				],
				[
					34.28571428571445,
					40
				],
				[
					37.14285714285734,
					40
				],
				[
					37.14285714285734,
					40
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				37.14285714285734,
				40
			]
		},
		{
			"id": "KiI7m6Vu9Au5VV9ZT_3BX",
			"type": "freedraw",
			"x": 1500.6433394675976,
			"y": -437.12090773809507,
			"width": 48.57142857142844,
			"height": 108.57142857142867,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 241281811,
			"version": 33,
			"versionNonce": 976031741,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5.714285714285666
				],
				[
					0,
					11.428571428571445
				],
				[
					0,
					17.14285714285711
				],
				[
					0,
					40
				],
				[
					0,
					60
				],
				[
					5.714285714285779,
					74.28571428571422
				],
				[
					5.714285714285779,
					80
				],
				[
					5.714285714285779,
					77.14285714285711
				],
				[
					5.714285714285779,
					71.42857142857144
				],
				[
					2.8571428571428896,
					57.14285714285711
				],
				[
					-2.8571428571428896,
					40
				],
				[
					-5.714285714285552,
					20
				],
				[
					-8.571428571428442,
					2.857142857142776
				],
				[
					-2.8571428571428896,
					-11.428571428571445
				],
				[
					5.714285714285779,
					-22.85714285714289
				],
				[
					17.14285714285711,
					-28.57142857142867
				],
				[
					28.57142857142867,
					-22.85714285714289
				],
				[
					37.14285714285711,
					-11.428571428571445
				],
				[
					40,
					2.857142857142776
				],
				[
					28.57142857142867,
					20
				],
				[
					14.285714285714448,
					28.571428571428555
				],
				[
					8.571428571428669,
					31.428571428571445
				],
				[
					-2.8571428571428896,
					31.428571428571445
				],
				[
					-2.8571428571428896,
					25.714285714285666
				],
				[
					-2.8571428571428896,
					22.857142857142776
				],
				[
					-2.8571428571428896,
					22.857142857142776
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-2.8571428571428896,
				22.857142857142776
			]
		},
		{
			"id": "-c3HfO0gySEUot18xtwhk",
			"type": "freedraw",
			"x": 1563.5004823247405,
			"y": -445.69233630952374,
			"width": 54.28571428571445,
			"height": 74.28571428571433,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 833404371,
			"version": 23,
			"versionNonce": 384416339,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-22.85714285714289,
					14.285714285714334
				],
				[
					-25.71428571428578,
					20.000000000000114
				],
				[
					-25.71428571428578,
					45.71428571428578
				],
				[
					-22.85714285714289,
					57.142857142857224
				],
				[
					-14.28571428571422,
					68.57142857142867
				],
				[
					-8.571428571428442,
					68.57142857142867
				],
				[
					8.571428571428669,
					68.57142857142867
				],
				[
					20,
					57.142857142857224
				],
				[
					28.57142857142867,
					37.142857142857224
				],
				[
					25.71428571428578,
					20.000000000000114
				],
				[
					11.428571428571558,
					2.8571428571428896
				],
				[
					-5.714285714285552,
					-5.714285714285666
				],
				[
					-14.28571428571422,
					0
				],
				[
					-14.28571428571422,
					2.8571428571428896
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-14.28571428571422,
				2.8571428571428896
			]
		},
		{
			"id": "8ThczdMeZj4F1VlRVfzG8",
			"type": "freedraw",
			"x": 1629.2147680390262,
			"y": -422.83519345238085,
			"width": 51.42857142857133,
			"height": 74.28571428571433,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1586669683,
			"version": 23,
			"versionNonce": 1902381149,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					34.285714285714334
				],
				[
					2.8571428571428896,
					40
				],
				[
					17.14285714285711,
					54.285714285714334
				],
				[
					34.28571428571422,
					54.285714285714334
				],
				[
					45.71428571428578,
					40
				],
				[
					51.42857142857133,
					25.71428571428578
				],
				[
					51.42857142857133,
					11.428571428571445
				],
				[
					48.57142857142867,
					5.714285714285779
				],
				[
					45.71428571428578,
					8.571428571428555
				],
				[
					42.85714285714289,
					22.85714285714289
				],
				[
					42.85714285714289,
					48.571428571428555
				],
				[
					42.85714285714289,
					62.85714285714289
				],
				[
					42.85714285714289,
					71.42857142857144
				],
				[
					42.85714285714289,
					74.28571428571433
				],
				[
					40,
					71.42857142857144
				],
				[
					40,
					71.42857142857144
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				40,
				71.42857142857144
			]
		},
		{
			"id": "td_O0-fT8q7TALV6E8s2w",
			"type": "freedraw",
			"x": 1700.6433394675976,
			"y": -431.4066220238094,
			"width": 37.14285714285734,
			"height": 11.428571428571445,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1420402451,
			"version": 12,
			"versionNonce": 1292171251,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					14.285714285714448,
					-5.714285714285666
				],
				[
					31.42857142857156,
					-5.714285714285666
				],
				[
					37.14285714285734,
					-8.571428571428555
				],
				[
					37.14285714285734,
					-11.428571428571445
				],
				[
					37.14285714285734,
					-11.428571428571445
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				37.14285714285734,
				-11.428571428571445
			]
		},
		{
			"id": "5NTqoiIq31M9zVrSDuuCk",
			"type": "freedraw",
			"x": 1743.5004823247405,
			"y": -451.4066220238094,
			"width": 42.85714285714289,
			"height": 125.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1176418493,
			"version": 23,
			"versionNonce": 735900861,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285779,
					-11.428571428571445
				],
				[
					11.428571428571558,
					-11.428571428571445
				],
				[
					14.285714285714448,
					-11.428571428571445
				],
				[
					25.71428571428578,
					-8.571428571428555
				],
				[
					34.28571428571445,
					5.714285714285666
				],
				[
					34.28571428571445,
					28.571428571428555
				],
				[
					34.28571428571445,
					51.428571428571445
				],
				[
					34.28571428571445,
					77.14285714285711
				],
				[
					34.28571428571445,
					97.14285714285711
				],
				[
					34.28571428571445,
					108.57142857142856
				],
				[
					28.57142857142867,
					114.28571428571433
				],
				[
					22.85714285714289,
					114.28571428571433
				],
				[
					17.14285714285711,
					114.28571428571433
				],
				[
					0,
					111.42857142857144
				],
				[
					-8.571428571428442,
					111.42857142857144
				],
				[
					-8.571428571428442,
					111.42857142857144
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-8.571428571428442,
				111.42857142857144
			]
		},
		{
			"id": "6ZhzmIWj8QUof1y1byz2K",
			"type": "freedraw",
			"x": 1952.071910896169,
			"y": -642.8351934523808,
			"width": 37.14285714285688,
			"height": 77.14285714285722,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1725033501,
			"version": 12,
			"versionNonce": 1143439763,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-34.28571428571422,
					71.42857142857144
				],
				[
					-37.14285714285688,
					77.14285714285722
				],
				[
					-37.14285714285688,
					71.42857142857144
				],
				[
					-37.14285714285688,
					62.85714285714289
				],
				[
					-37.14285714285688,
					62.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-37.14285714285688,
				62.85714285714289
			]
		},
		{
			"id": "UcI8o63iq7GMiB_7NWlAk",
			"type": "freedraw",
			"x": 1917.7861966104547,
			"y": -628.5494791666665,
			"width": 48.571428571428896,
			"height": 57.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 192911635,
			"version": 13,
			"versionNonce": 356078877,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					31.42857142857156,
					25.714285714285666
				],
				[
					34.28571428571422,
					31.42857142857133
				],
				[
					42.85714285714312,
					45.714285714285666
				],
				[
					45.71428571428578,
					51.42857142857133
				],
				[
					48.571428571428896,
					57.14285714285711
				],
				[
					48.571428571428896,
					57.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				48.571428571428896,
				57.14285714285711
			]
		},
		{
			"id": "nBP9mW4cnuwX51eE8adOO",
			"type": "freedraw",
			"x": 2054.929053753312,
			"y": -679.978050595238,
			"width": 77.14285714285688,
			"height": 140,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1641871251,
			"version": 24,
			"versionNonce": 1971836723,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285779,
					45.714285714285666
				],
				[
					34.28571428571422,
					62.857142857142776
				],
				[
					65.71428571428578,
					48.571428571428555
				],
				[
					71.42857142857156,
					28.571428571428555
				],
				[
					62.85714285714266,
					5.714285714285666
				],
				[
					54.28571428571422,
					-2.8571428571428896
				],
				[
					54.28571428571422,
					25.714285714285666
				],
				[
					62.85714285714266,
					54.285714285714334
				],
				[
					74.28571428571422,
					85.71428571428567
				],
				[
					77.14285714285688,
					108.57142857142856
				],
				[
					77.14285714285688,
					125.71428571428567
				],
				[
					62.85714285714266,
					137.1428571428571
				],
				[
					48.57142857142844,
					134.28571428571422
				],
				[
					34.28571428571422,
					128.57142857142856
				],
				[
					25.71428571428578,
					117.14285714285711
				],
				[
					28.57142857142844,
					108.57142857142856
				],
				[
					28.57142857142844,
					108.57142857142856
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				28.57142857142844,
				108.57142857142856
			]
		},
		{
			"id": "cFGQnYqV0xbPvfzxuZd1W",
			"type": "freedraw",
			"x": 2174.929053753312,
			"y": -645.6923363095236,
			"width": 8.571428571428442,
			"height": 85.71428571428567,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1456031357,
			"version": 16,
			"versionNonce": 1760209277,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571426623,
					5.714285714285666
				],
				[
					2.8571428571426623,
					25.714285714285666
				],
				[
					2.8571428571426623,
					34.28571428571422
				],
				[
					5.714285714285779,
					57.14285714285711
				],
				[
					5.714285714285779,
					77.14285714285711
				],
				[
					8.571428571428442,
					85.71428571428567
				],
				[
					8.571428571428442,
					82.85714285714278
				],
				[
					8.571428571428442,
					80
				],
				[
					8.571428571428442,
					80
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428442,
				80
			]
		},
		{
			"id": "P3ABEpiOzb35ZbAx4W9hk",
			"type": "freedraw",
			"x": 2203.5004823247405,
			"y": -645.6923363095236,
			"width": 20,
			"height": 88.57142857142844,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1927155,
			"version": 15,
			"versionNonce": 1871476947,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					11.428571428571558,
					0
				],
				[
					14.28571428571422,
					5.714285714285666
				],
				[
					14.28571428571422,
					40
				],
				[
					17.142857142857338,
					57.14285714285711
				],
				[
					20,
					80
				],
				[
					20,
					88.57142857142844
				],
				[
					17.142857142857338,
					82.85714285714278
				],
				[
					17.142857142857338,
					82.85714285714278
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				17.142857142857338,
				82.85714285714278
			]
		},
		{
			"id": "W5RjkkQZUIQg7fDYw00dV",
			"type": "freedraw",
			"x": 2189.2147680390262,
			"y": -588.5494791666665,
			"width": 51.42857142857156,
			"height": 22.85714285714289,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1121914899,
			"version": 14,
			"versionNonce": 2016571869,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.714285714285779,
					-11.428571428571445
				],
				[
					0,
					-11.428571428571445
				],
				[
					5.714285714285779,
					-14.285714285714334
				],
				[
					20,
					-14.285714285714334
				],
				[
					40,
					-17.14285714285711
				],
				[
					45.71428571428578,
					-22.85714285714289
				],
				[
					45.71428571428578,
					-22.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428578,
				-22.85714285714289
			]
		},
		{
			"id": "G1OjlXRd86Xqti_hHcOOC",
			"type": "freedraw",
			"x": 2260.643339467598,
			"y": -665.6923363095236,
			"width": 8.571428571428442,
			"height": 82.85714285714278,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 435238941,
			"version": 17,
			"versionNonce": 801891955,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8.571428571428442
				],
				[
					0,
					14.28571428571422
				],
				[
					0,
					20
				],
				[
					2.8571428571426623,
					34.28571428571422
				],
				[
					5.714285714285779,
					62.857142857142776
				],
				[
					8.571428571428442,
					77.14285714285711
				],
				[
					8.571428571428442,
					82.85714285714278
				],
				[
					8.571428571428442,
					80
				],
				[
					8.571428571428442,
					74.28571428571422
				],
				[
					8.571428571428442,
					74.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428442,
				74.28571428571422
			]
		},
		{
			"id": "DylKngpkDedvTgHH528db",
			"type": "freedraw",
			"x": 2243.5004823247405,
			"y": -622.8351934523808,
			"width": 40,
			"height": 20,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2112994909,
			"version": 13,
			"versionNonce": 1881288253,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					25.71428571428578,
					-8.571428571428555
				],
				[
					31.42857142857156,
					-11.428571428571445
				],
				[
					37.14285714285734,
					-14.285714285714334
				],
				[
					40,
					-17.14285714285711
				],
				[
					40,
					-20
				],
				[
					40,
					-20
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				40,
				-20
			]
		},
		{
			"id": "g7zdR1dwhuI8l08F_IcR0",
			"type": "freedraw",
			"x": 2340.643339467598,
			"y": -679.978050595238,
			"width": 80,
			"height": 142.8571428571429,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 758458333,
			"version": 24,
			"versionNonce": 1024237587,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428442,
					60
				],
				[
					14.28571428571422,
					62.857142857142776
				],
				[
					40,
					65.71428571428567
				],
				[
					54.28571428571422,
					57.14285714285711
				],
				[
					60,
					37.14285714285711
				],
				[
					60,
					22.857142857142776
				],
				[
					54.28571428571422,
					11.428571428571445
				],
				[
					51.42857142857156,
					8.571428571428555
				],
				[
					51.42857142857156,
					22.857142857142776
				],
				[
					62.85714285714266,
					60
				],
				[
					74.28571428571422,
					88.57142857142856
				],
				[
					80,
					122.85714285714278
				],
				[
					48.57142857142844,
					142.8571428571429
				],
				[
					22.857142857142662,
					134.28571428571422
				],
				[
					17.142857142856883,
					131.42857142857144
				],
				[
					14.28571428571422,
					108.57142857142856
				],
				[
					14.28571428571422,
					108.57142857142856
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				14.28571428571422,
				108.57142857142856
			]
		},
		{
			"id": "wVGEddfkmr_CCbbk9L0pE",
			"type": "freedraw",
			"x": 2457.7861966104547,
			"y": -659.978050595238,
			"width": 8.571428571428896,
			"height": 97.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1590265619,
			"version": 12,
			"versionNonce": 1604017821,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285779,
					40
				],
				[
					8.571428571428896,
					74.28571428571433
				],
				[
					8.571428571428896,
					91.42857142857144
				],
				[
					8.571428571428896,
					97.14285714285711
				],
				[
					8.571428571428896,
					97.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428896,
				97.14285714285711
			]
		},
		{
			"id": "8CaLcjEoYGAVXmgUcewJW",
			"type": "freedraw",
			"x": 2483.5004823247405,
			"y": -645.6923363095236,
			"width": 14.28571428571422,
			"height": 85.71428571428567,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 691556541,
			"version": 15,
			"versionNonce": 21308851,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428896,
					2.857142857142776
				],
				[
					8.571428571428896,
					37.14285714285711
				],
				[
					11.428571428571558,
					62.857142857142776
				],
				[
					14.28571428571422,
					80
				],
				[
					14.28571428571422,
					85.71428571428567
				],
				[
					14.28571428571422,
					82.85714285714278
				],
				[
					11.428571428571558,
					80
				],
				[
					11.428571428571558,
					80
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				11.428571428571558,
				80
			]
		},
		{
			"id": "bS48KHzVticvQ3BPeM0hL",
			"type": "freedraw",
			"x": 2463.5004823247405,
			"y": -597.1209077380952,
			"width": 48.57142857142844,
			"height": 17.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1281178269,
			"version": 15,
			"versionNonce": 2102362877,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.8571428571426623,
					-2.857142857142776
				],
				[
					0,
					-2.857142857142776
				],
				[
					14.28571428571422,
					-5.714285714285666
				],
				[
					25.71428571428578,
					-8.571428571428442
				],
				[
					37.14285714285734,
					-11.428571428571331
				],
				[
					45.71428571428578,
					-14.28571428571422
				],
				[
					45.71428571428578,
					-17.14285714285711
				],
				[
					45.71428571428578,
					-17.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428578,
				-17.14285714285711
			]
		},
		{
			"id": "EVEhDev7PdQpHjEEvpINc",
			"type": "freedraw",
			"x": 2537.7861966104547,
			"y": -642.8351934523808,
			"width": 45.71428571428578,
			"height": 108.57142857142844,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 903084157,
			"version": 26,
			"versionNonce": 1671165779,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.7142857142853245,
					5.714285714285666
				],
				[
					-5.7142857142853245,
					11.428571428571445
				],
				[
					-5.7142857142853245,
					45.714285714285666
				],
				[
					-5.7142857142853245,
					74.28571428571433
				],
				[
					-2.8571428571426623,
					85.71428571428567
				],
				[
					-5.7142857142853245,
					85.71428571428567
				],
				[
					-14.28571428571422,
					62.85714285714289
				],
				[
					-17.142857142856883,
					37.142857142857224
				],
				[
					-20,
					2.8571428571428896
				],
				[
					-17.142857142856883,
					-14.285714285714334
				],
				[
					-5.7142857142853245,
					-22.857142857142776
				],
				[
					8.571428571428896,
					-17.14285714285711
				],
				[
					25.71428571428578,
					0
				],
				[
					25.71428571428578,
					20
				],
				[
					5.714285714285779,
					37.142857142857224
				],
				[
					2.857142857143117,
					37.142857142857224
				],
				[
					-14.28571428571422,
					31.428571428571445
				],
				[
					-14.28571428571422,
					28.571428571428555
				],
				[
					-14.28571428571422,
					28.571428571428555
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-14.28571428571422,
				28.571428571428555
			]
		},
		{
			"id": "UQhhvFttdmrdjHswMtAuY",
			"type": "freedraw",
			"x": 2560.643339467598,
			"y": -645.6923363095236,
			"width": 54.28571428571422,
			"height": 80,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1849622035,
			"version": 17,
			"versionNonce": 767564637,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					34.28571428571422,
					80
				],
				[
					51.42857142857156,
					62.857142857142776
				],
				[
					54.28571428571422,
					37.14285714285711
				],
				[
					42.85714285714266,
					20
				],
				[
					28.57142857142844,
					5.714285714285666
				],
				[
					11.428571428571558,
					2.857142857142776
				],
				[
					8.571428571428442,
					8.571428571428442
				],
				[
					8.571428571428442,
					11.428571428571331
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428442,
				11.428571428571331
			]
		},
		{
			"id": "FHEcca74AcY50VFTj8-jl",
			"type": "freedraw",
			"x": 2609.2147680390262,
			"y": -622.8351934523808,
			"width": 60,
			"height": 88.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 571216851,
			"version": 23,
			"versionNonce": 577213683,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428442,
					45.714285714285666
				],
				[
					11.428571428571558,
					51.428571428571445
				],
				[
					20,
					57.142857142857224
				],
				[
					22.857142857143117,
					60
				],
				[
					42.85714285714312,
					60
				],
				[
					54.28571428571422,
					48.571428571428555
				],
				[
					60,
					28.571428571428555
				],
				[
					60,
					14.285714285714334
				],
				[
					57.14285714285734,
					5.714285714285666
				],
				[
					48.57142857142844,
					28.571428571428555
				],
				[
					48.57142857142844,
					48.571428571428555
				],
				[
					48.57142857142844,
					68.57142857142856
				],
				[
					51.42857142857156,
					85.71428571428578
				],
				[
					51.42857142857156,
					88.57142857142856
				],
				[
					51.42857142857156,
					85.71428571428578
				],
				[
					51.42857142857156,
					85.71428571428578
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				51.42857142857156,
				85.71428571428578
			]
		},
		{
			"id": "Gxe3fRdHLpewkc703T_22",
			"type": "freedraw",
			"x": 2689.2147680390262,
			"y": -659.978050595238,
			"width": 51.42857142857156,
			"height": 80,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1445019251,
			"version": 26,
			"versionNonce": 1228842941,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-11.428571428571445
				],
				[
					0,
					-14.285714285714334
				],
				[
					5.714285714285779,
					-17.142857142857224
				],
				[
					22.857142857143117,
					-25.714285714285666
				],
				[
					34.28571428571422,
					-20
				],
				[
					40,
					-11.428571428571445
				],
				[
					40,
					11.428571428571445
				],
				[
					31.42857142857156,
					31.428571428571445
				],
				[
					11.428571428571558,
					45.714285714285666
				],
				[
					0,
					48.571428571428555
				],
				[
					-5.714285714285779,
					42.857142857142776
				],
				[
					-2.8571428571426623,
					34.285714285714334
				],
				[
					0,
					34.285714285714334
				],
				[
					2.857142857143117,
					34.285714285714334
				],
				[
					22.857142857143117,
					42.857142857142776
				],
				[
					40,
					54.285714285714334
				],
				[
					45.71428571428578,
					54.285714285714334
				],
				[
					45.71428571428578,
					51.428571428571445
				],
				[
					45.71428571428578,
					51.428571428571445
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428578,
				51.428571428571445
			]
		},
		{
			"id": "CnN172AsXl7IEZ9K7WwFJ",
			"type": "freedraw",
			"x": 2757.7861966104547,
			"y": -642.8351934523808,
			"width": 57.14285714285734,
			"height": 22.857142857142776,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 222895613,
			"version": 14,
			"versionNonce": 1831763603,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428896,
					-8.571428571428555
				],
				[
					22.857142857143117,
					-14.285714285714334
				],
				[
					42.85714285714312,
					-20
				],
				[
					57.14285714285734,
					-22.857142857142776
				],
				[
					54.285714285714675,
					-22.857142857142776
				],
				[
					45.71428571428578,
					-17.14285714285711
				],
				[
					45.71428571428578,
					-17.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428578,
				-17.14285714285711
			]
		},
		{
			"id": "_Klvzfx29x83i2wMEImq5",
			"type": "freedraw",
			"x": 2094.929053753312,
			"y": -482.83519345238085,
			"width": 742.8571428571431,
			"height": 31.428571428571445,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1560758995,
			"version": 24,
			"versionNonce": 569157661,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-25.71428571428578,
					2.8571428571428896
				],
				[
					-20,
					5.714285714285779
				],
				[
					14.28571428571422,
					5.714285714285779
				],
				[
					45.71428571428578,
					8.571428571428555
				],
				[
					142.85714285714266,
					5.714285714285779
				],
				[
					174.28571428571422,
					5.714285714285779
				],
				[
					277.14285714285734,
					2.8571428571428896
				],
				[
					385.7142857142858,
					-2.8571428571428896
				],
				[
					534.2857142857142,
					-8.571428571428555
				],
				[
					622.8571428571427,
					-14.28571428571422
				],
				[
					694.2857142857142,
					-20
				],
				[
					702.8571428571427,
					-20
				],
				[
					717.1428571428573,
					-20
				],
				[
					714.2857142857142,
					-20
				],
				[
					694.2857142857142,
					-22.85714285714289
				],
				[
					688.5714285714284,
					-22.85714285714289
				],
				[
					688.5714285714284,
					-22.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				688.5714285714284,
				-22.85714285714289
			]
		},
		{
			"id": "UTdK_Dr9bpHDUQfIsEuxL",
			"type": "freedraw",
			"x": 2254.929053753312,
			"y": -397.12090773809507,
			"width": 68.57142857142844,
			"height": 114.28571428571433,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 853405501,
			"version": 25,
			"versionNonce": 1051145267,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					42.85714285714266,
					54.28571428571422
				],
				[
					51.42857142857156,
					45.714285714285666
				],
				[
					54.28571428571422,
					25.714285714285666
				],
				[
					51.42857142857156,
					8.571428571428555
				],
				[
					42.85714285714266,
					-2.8571428571428896
				],
				[
					42.85714285714266,
					0
				],
				[
					42.85714285714266,
					17.14285714285711
				],
				[
					48.57142857142844,
					42.857142857142776
				],
				[
					57.14285714285688,
					77.14285714285711
				],
				[
					54.28571428571422,
					97.14285714285711
				],
				[
					48.57142857142844,
					108.57142857142856
				],
				[
					31.42857142857156,
					111.42857142857144
				],
				[
					25.71428571428578,
					108.57142857142856
				],
				[
					8.571428571428442,
					102.85714285714278
				],
				[
					-5.714285714285779,
					91.42857142857144
				],
				[
					-11.428571428571558,
					80
				],
				[
					-5.714285714285779,
					74.28571428571422
				],
				[
					-5.714285714285779,
					74.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-5.714285714285779,
				74.28571428571422
			]
		},
		{
			"id": "mUHJ7OJTP90iYz6p0nT2B",
			"type": "freedraw",
			"x": 2369.2147680390262,
			"y": -399.97805059523796,
			"width": 2.857142857143117,
			"height": 88.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1304262397,
			"version": 14,
			"versionNonce": 1237032061,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					42.85714285714289
				],
				[
					0,
					51.428571428571445
				],
				[
					0,
					80
				],
				[
					0,
					85.71428571428567
				],
				[
					0,
					88.57142857142856
				],
				[
					2.857142857143117,
					82.85714285714289
				],
				[
					2.857142857143117,
					82.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.857142857143117,
				82.85714285714289
			]
		},
		{
			"id": "g10zDgt1X8-Ei-Wx6gXi-",
			"type": "freedraw",
			"x": 2397.7861966104547,
			"y": -391.4066220238094,
			"width": 17.142857142857338,
			"height": 88.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1162707411,
			"version": 15,
			"versionNonce": 1991783891,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					11.428571428571558,
					8.571428571428555
				],
				[
					11.428571428571558,
					17.14285714285711
				],
				[
					14.285714285714675,
					45.71428571428578
				],
				[
					17.142857142857338,
					68.57142857142856
				],
				[
					17.142857142857338,
					85.71428571428578
				],
				[
					17.142857142857338,
					88.57142857142856
				],
				[
					17.142857142857338,
					85.71428571428578
				],
				[
					17.142857142857338,
					85.71428571428578
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				17.142857142857338,
				85.71428571428578
			]
		},
		{
			"id": "3CIpJkDobY3eD9mdOBhwN",
			"type": "freedraw",
			"x": 2397.7861966104547,
			"y": -331.4066220238094,
			"width": 54.28571428571422,
			"height": 25.714285714285666,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 828571123,
			"version": 14,
			"versionNonce": 409797853,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8.571428571428442,
					-17.14285714285711
				],
				[
					-5.7142857142853245,
					-17.14285714285711
				],
				[
					5.714285714285779,
					-20
				],
				[
					22.857142857143117,
					-25.714285714285666
				],
				[
					37.14285714285734,
					-25.714285714285666
				],
				[
					45.71428571428578,
					-25.714285714285666
				],
				[
					45.71428571428578,
					-25.714285714285666
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428578,
				-25.714285714285666
			]
		},
		{
			"id": "WTtr6lQTujpEHtLVuMYLQ",
			"type": "freedraw",
			"x": 2440.643339467598,
			"y": -345.6923363095236,
			"width": 71.4285714285711,
			"height": 71.42857142857144,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 110266429,
			"version": 28,
			"versionNonce": 880280435,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8.571428571428442,
					0
				],
				[
					-8.571428571428442,
					-2.8571428571428896
				],
				[
					2.8571428571426623,
					-14.285714285714334
				],
				[
					8.571428571428442,
					-17.142857142857224
				],
				[
					25.71428571428578,
					-25.71428571428578
				],
				[
					40,
					-17.142857142857224
				],
				[
					42.85714285714266,
					0
				],
				[
					34.28571428571422,
					20
				],
				[
					31.42857142857156,
					25.714285714285666
				],
				[
					14.28571428571422,
					40
				],
				[
					2.8571428571426623,
					42.857142857142776
				],
				[
					-2.857142857143117,
					42.857142857142776
				],
				[
					0,
					28.571428571428555
				],
				[
					8.571428571428442,
					22.857142857142776
				],
				[
					25.71428571428578,
					22.857142857142776
				],
				[
					31.42857142857156,
					25.714285714285666
				],
				[
					42.85714285714266,
					37.14285714285711
				],
				[
					54.28571428571422,
					45.714285714285666
				],
				[
					60,
					45.714285714285666
				],
				[
					62.85714285714266,
					42.857142857142776
				],
				[
					62.85714285714266,
					42.857142857142776
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				62.85714285714266,
				42.857142857142776
			]
		},
		{
			"id": "yBry0UmidM-HY4FgKBGTa",
			"type": "freedraw",
			"x": 2532.0719108961694,
			"y": -388.5494791666665,
			"width": 8.571428571428442,
			"height": 68.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 170866675,
			"version": 11,
			"versionNonce": 1416372253,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713359189,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.7142857142853245,
					8.571428571428555
				],
				[
					8.571428571428442,
					37.14285714285711
				],
				[
					8.571428571428442,
					57.14285714285711
				],
				[
					8.571428571428442,
					68.57142857142856
				],
				[
					5.7142857142853245,
					68.57142857142856
				],
				[
					5.7142857142853245,
					68.57142857142856
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				5.7142857142853245,
				68.57142857142856
			]
		},
		{
			"id": "wz2d478xOckA9uVF7-Hwn",
			"type": "freedraw",
			"x": 2526.3576251818836,
			"y": -348.5494791666665,
			"width": 54.28571428571422,
			"height": 34.285714285714334,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1708533363,
			"version": 13,
			"versionNonce": 1793068381,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713358834,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					54.28571428571422,
					-34.285714285714334
				],
				[
					51.428571428571104,
					-28.571428571428555
				],
				[
					31.428571428571104,
					-5.714285714285779
				],
				[
					14.28571428571422,
					-2.8571428571428896
				],
				[
					11.428571428571104,
					-2.8571428571428896
				],
				[
					2.8571428571426623,
					-5.714285714285779
				],
				[
					2.8571428571426623,
					-11.428571428571445
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.8571428571426623,
				-11.428571428571445
			]
		},
		{
			"id": "xY6ymK2Orx-Gs2ECzI9WF",
			"type": "freedraw",
			"x": 2600.643339467598,
			"y": -388.5494791666665,
			"width": 54.28571428571422,
			"height": 88.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 747530269,
			"version": 19,
			"versionNonce": 1466070035,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713358339,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-11.428571428571558,
					11.428571428571445
				],
				[
					-14.28571428571422,
					17.14285714285711
				],
				[
					-17.142857142857338,
					42.85714285714289
				],
				[
					-14.28571428571422,
					60
				],
				[
					5.714285714285779,
					68.57142857142856
				],
				[
					25.71428571428578,
					57.14285714285711
				],
				[
					34.28571428571422,
					40
				],
				[
					37.14285714285688,
					14.28571428571422
				],
				[
					28.57142857142844,
					-5.714285714285779
				],
				[
					14.28571428571422,
					-20
				],
				[
					8.571428571428442,
					-20
				],
				[
					-5.714285714285779,
					-14.285714285714334
				],
				[
					-11.428571428571558,
					-8.571428571428555
				],
				[
					-14.28571428571422,
					0
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-14.28571428571422,
				0
			]
		},
		{
			"id": "-IvDJhirtw3j7rc6ZpPhb",
			"type": "freedraw",
			"x": 2514.929053753312,
			"y": -385.6923363095236,
			"width": 57.14285714285734,
			"height": 117.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 268123187,
			"version": 28,
			"versionNonce": 1905418557,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571426623,
					91.42857142857133
				],
				[
					2.8571428571426623,
					97.14285714285711
				],
				[
					0,
					97.14285714285711
				],
				[
					0,
					94.28571428571422
				],
				[
					-5.714285714285779,
					71.42857142857133
				],
				[
					-5.714285714285779,
					65.71428571428567
				],
				[
					-11.428571428571558,
					40
				],
				[
					-11.428571428571558,
					22.857142857142776
				],
				[
					-11.428571428571558,
					2.857142857142776
				],
				[
					-5.714285714285779,
					-8.571428571428669
				],
				[
					-2.8571428571426623,
					-11.428571428571445
				],
				[
					11.428571428571558,
					-20
				],
				[
					17.142857142857338,
					-20
				],
				[
					34.28571428571422,
					-14.285714285714334
				],
				[
					45.71428571428578,
					0
				],
				[
					45.71428571428578,
					8.571428571428555
				],
				[
					42.85714285714266,
					28.571428571428555
				],
				[
					34.28571428571422,
					37.14285714285711
				],
				[
					22.857142857142662,
					48.571428571428555
				],
				[
					8.571428571428442,
					48.571428571428555
				],
				[
					2.8571428571426623,
					48.571428571428555
				],
				[
					0,
					45.714285714285666
				],
				[
					0,
					37.14285714285711
				],
				[
					0,
					37.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0,
				37.14285714285711
			]
		},
		{
			"id": "6KSsmqXecUS7SB5hvwdVo",
			"type": "freedraw",
			"x": 2580.643339467598,
			"y": -359.97805059523796,
			"width": 62.85714285714312,
			"height": 80,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 752908627,
			"version": 20,
			"versionNonce": 1882004755,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432216,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-11.428571428571558,
					5.714285714285666
				],
				[
					-17.142857142857338,
					20
				],
				[
					-17.142857142857338,
					37.14285714285711
				],
				[
					-11.428571428571558,
					45.714285714285666
				],
				[
					2.8571428571426623,
					51.428571428571445
				],
				[
					22.857142857142662,
					42.85714285714289
				],
				[
					37.14285714285688,
					34.285714285714334
				],
				[
					45.71428571428578,
					14.285714285714334
				],
				[
					42.85714285714266,
					-14.285714285714334
				],
				[
					40,
					-20
				],
				[
					34.28571428571422,
					-25.714285714285666
				],
				[
					11.428571428571558,
					-28.571428571428555
				],
				[
					-8.571428571428442,
					-2.8571428571428896
				],
				[
					-8.571428571428442,
					5.714285714285666
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-8.571428571428442,
				5.714285714285666
			]
		},
		{
			"id": "pxKzLNykiEgPzScJkGbyF",
			"type": "freedraw",
			"x": 2640.643339467598,
			"y": -354.2637648809523,
			"width": 51.42857142857156,
			"height": 82.85714285714278,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 488600563,
			"version": 30,
			"versionNonce": 1250767261,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713432217,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-2.857142857142776
				],
				[
					0,
					0
				],
				[
					-5.714285714285779,
					5.714285714285779
				],
				[
					-8.571428571428442,
					17.142857142857224
				],
				[
					-11.428571428571558,
					31.428571428571445
				],
				[
					-8.571428571428442,
					40
				],
				[
					0,
					42.85714285714289
				],
				[
					11.428571428571558,
					40
				],
				[
					25.71428571428578,
					31.428571428571445
				],
				[
					34.28571428571422,
					22.85714285714289
				],
				[
					40,
					11.428571428571445
				],
				[
					40,
					5.714285714285779
				],
				[
					40,
					-2.857142857142776
				],
				[
					37.14285714285688,
					-8.571428571428555
				],
				[
					31.42857142857156,
					-11.428571428571331
				],
				[
					28.57142857142844,
					-11.428571428571331
				],
				[
					28.57142857142844,
					-8.571428571428555
				],
				[
					25.71428571428578,
					5.714285714285779
				],
				[
					25.71428571428578,
					31.428571428571445
				],
				[
					28.57142857142844,
					45.71428571428578
				],
				[
					28.57142857142844,
					62.85714285714289
				],
				[
					28.57142857142844,
					68.57142857142867
				],
				[
					28.57142857142844,
					71.42857142857144
				],
				[
					28.57142857142844,
					68.57142857142867
				],
				[
					28.57142857142844,
					65.71428571428578
				],
				[
					28.57142857142844,
					65.71428571428578
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				28.57142857142844,
				65.71428571428578
			]
		},
		{
			"id": "qJ1hGWy76oXGBiwNtaekH",
			"type": "freedraw",
			"x": 1380.6433394675976,
			"y": -65.69233630952363,
			"width": 65.71428571428578,
			"height": 94.28571428571422,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 69172915,
			"version": 16,
			"versionNonce": 1410335997,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-11.428571428571331,
					80
				],
				[
					-8.571428571428442,
					74.28571428571422
				],
				[
					-2.8571428571428896,
					48.57142857142844
				],
				[
					5.714285714285779,
					22.85714285714289
				],
				[
					8.571428571428669,
					14.28571428571422
				],
				[
					20,
					0
				],
				[
					31.42857142857156,
					5.714285714285666
				],
				[
					40,
					37.14285714285711
				],
				[
					42.85714285714289,
					65.71428571428578
				],
				[
					51.42857142857156,
					85.71428571428578
				],
				[
					54.28571428571445,
					94.28571428571422
				],
				[
					54.28571428571445,
					94.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				54.28571428571445,
				94.28571428571422
			]
		},
		{
			"id": "LCwLxT_PTs2nJr_WxrPw2",
			"type": "freedraw",
			"x": 1469.2147680390262,
			"y": -39.978050595237846,
			"width": 42.85714285714289,
			"height": 82.85714285714289,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 433427987,
			"version": 18,
			"versionNonce": 949785939,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8.571428571428669,
					51.42857142857133
				],
				[
					-8.571428571428669,
					60
				],
				[
					0,
					80
				],
				[
					11.428571428571331,
					80
				],
				[
					22.85714285714289,
					68.57142857142844
				],
				[
					28.57142857142844,
					65.71428571428555
				],
				[
					34.28571428571422,
					45.71428571428555
				],
				[
					31.42857142857133,
					25.714285714285552
				],
				[
					17.14285714285711,
					2.8571428571426623
				],
				[
					2.8571428571428896,
					-2.8571428571428896
				],
				[
					-5.714285714285779,
					-2.8571428571428896
				],
				[
					-5.714285714285779,
					0
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-5.714285714285779,
				0
			]
		},
		{
			"id": "6e5IhxAnGBgH0TaCbG6LN",
			"type": "freedraw",
			"x": 1540.6433394675976,
			"y": -99.97805059523796,
			"width": 25.71428571428578,
			"height": 134.28571428571433,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1545605907,
			"version": 8,
			"versionNonce": 488660317,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-22.85714285714289,
					108.57142857142856
				],
				[
					-8.571428571428442,
					134.28571428571433
				],
				[
					2.8571428571428896,
					134.28571428571433
				],
				[
					2.8571428571428896,
					134.28571428571433
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.8571428571428896,
				134.28571428571433
			]
		},
		{
			"id": "HFtEFf3dNK7r-oI4ZpOk5",
			"type": "freedraw",
			"x": 1583.5004823247405,
			"y": -19.978050595237846,
			"width": 77.14285714285711,
			"height": 88.57142857142844,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1688987635,
			"version": 16,
			"versionNonce": 161772275,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-40,
					37.14285714285711
				],
				[
					-40,
					60
				],
				[
					-22.85714285714289,
					71.42857142857133
				],
				[
					-5.714285714285552,
					60
				],
				[
					11.428571428571558,
					42.85714285714266
				],
				[
					17.14285714285711,
					25.714285714285552
				],
				[
					17.14285714285711,
					11.428571428571331
				],
				[
					14.285714285714448,
					17.14285714285711
				],
				[
					14.285714285714448,
					34.28571428571422
				],
				[
					31.42857142857156,
					82.85714285714266
				],
				[
					37.14285714285711,
					88.57142857142844
				],
				[
					37.14285714285711,
					88.57142857142844
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				37.14285714285711,
				88.57142857142844
			]
		},
		{
			"id": "hixFkvigskhP3p8cN0FGM",
			"type": "freedraw",
			"x": 1952.071910896169,
			"y": -137.12090773809507,
			"width": 242.85714285714266,
			"height": 322.8571428571428,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1500571475,
			"version": 41,
			"versionNonce": 658942397,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-97.14285714285688,
					105.71428571428567
				],
				[
					-105.71428571428532,
					157.14285714285722
				],
				[
					-100,
					202.85714285714278
				],
				[
					-74.28571428571422,
					257.1428571428572
				],
				[
					-45.714285714285325,
					279.9999999999999
				],
				[
					-2.8571428571426623,
					297.1428571428572
				],
				[
					31.42857142857156,
					294.28571428571433
				],
				[
					71.42857142857156,
					274.28571428571433
				],
				[
					97.14285714285734,
					251.42857142857144
				],
				[
					102.85714285714312,
					242.85714285714278
				],
				[
					122.85714285714312,
					217.14285714285722
				],
				[
					131.42857142857156,
					202.85714285714278
				],
				[
					137.14285714285734,
					197.14285714285722
				],
				[
					137.14285714285734,
					194.28571428571433
				],
				[
					131.42857142857156,
					205.71428571428567
				],
				[
					122.85714285714312,
					222.85714285714278
				],
				[
					105.71428571428578,
					248.57142857142856
				],
				[
					68.5714285714289,
					288.57142857142856
				],
				[
					34.285714285714675,
					299.9999999999999
				],
				[
					25.71428571428578,
					299.9999999999999
				],
				[
					-40,
					288.57142857142856
				],
				[
					-65.71428571428532,
					262.8571428571428
				],
				[
					-71.4285714285711,
					254.28571428571433
				],
				[
					-82.85714285714266,
					211.42857142857144
				],
				[
					-85.71428571428532,
					199.9999999999999
				],
				[
					-85.71428571428532,
					148.57142857142856
				],
				[
					-82.85714285714266,
					139.9999999999999
				],
				[
					-60,
					80
				],
				[
					-25.714285714285325,
					31.428571428571445
				],
				[
					-20,
					22.85714285714289
				],
				[
					14.285714285714675,
					-5.714285714285779
				],
				[
					40,
					-20
				],
				[
					57.14285714285734,
					-22.85714285714289
				],
				[
					57.14285714285734,
					-20
				],
				[
					54.285714285714675,
					-11.428571428571445
				],
				[
					48.571428571428896,
					-8.571428571428555
				],
				[
					48.571428571428896,
					-8.571428571428555
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				48.571428571428896,
				-8.571428571428555
			]
		},
		{
			"id": "Q1qWkD87U_o9Fn5mb5n56",
			"type": "freedraw",
			"x": 1943.5004823247405,
			"y": 34.307663690476375,
			"width": 60,
			"height": 88.57142857142844,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 968921725,
			"version": 36,
			"versionNonce": 1428135059,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					37.14285714285734,
					-25.71428571428578
				],
				[
					40,
					-22.85714285714289
				],
				[
					45.71428571428578,
					-11.428571428571558
				],
				[
					42.85714285714312,
					14.28571428571422
				],
				[
					34.28571428571422,
					34.28571428571422
				],
				[
					22.857142857143117,
					42.85714285714289
				],
				[
					8.571428571428442,
					45.71428571428578
				],
				[
					0,
					40
				],
				[
					-11.428571428571558,
					25.71428571428578
				],
				[
					-14.28571428571422,
					8.571428571428442
				],
				[
					-5.714285714285779,
					-17.14285714285711
				],
				[
					11.428571428571558,
					-34.28571428571422
				],
				[
					25.71428571428578,
					-34.28571428571422
				],
				[
					40,
					-17.14285714285711
				],
				[
					45.71428571428578,
					2.8571428571428896
				],
				[
					45.71428571428578,
					8.571428571428442
				],
				[
					42.85714285714312,
					25.71428571428578
				],
				[
					37.14285714285734,
					40
				],
				[
					22.857142857143117,
					54.28571428571422
				],
				[
					8.571428571428442,
					51.42857142857133
				],
				[
					-2.8571428571426623,
					31.42857142857133
				],
				[
					0,
					8.571428571428442
				],
				[
					22.857142857143117,
					-22.85714285714289
				],
				[
					25.71428571428578,
					-22.85714285714289
				],
				[
					37.14285714285734,
					-20
				],
				[
					45.71428571428578,
					11.428571428571331
				],
				[
					40,
					34.28571428571422
				],
				[
					28.57142857142844,
					42.85714285714289
				],
				[
					14.28571428571422,
					40
				],
				[
					11.428571428571558,
					31.42857142857133
				],
				[
					11.428571428571558,
					22.85714285714289
				],
				[
					11.428571428571558,
					22.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				11.428571428571558,
				22.85714285714289
			]
		},
		{
			"id": "g4YD8YqFe9SB-nHWWL93b",
			"type": "freedraw",
			"x": 2354.929053753312,
			"y": -165.69233630952363,
			"width": 274.2857142857142,
			"height": 388.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1201889501,
			"version": 74,
			"versionNonce": 1134848541,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-14.28571428571422,
					-14.285714285714334
				],
				[
					-8.571428571428442,
					-5.714285714285779
				],
				[
					14.28571428571422,
					22.857142857142776
				],
				[
					45.71428571428578,
					57.14285714285711
				],
				[
					85.71428571428578,
					108.57142857142856
				],
				[
					108.57142857142844,
					154.28571428571422
				],
				[
					114.28571428571422,
					168.57142857142844
				],
				[
					122.85714285714266,
					211.42857142857133
				],
				[
					111.42857142857156,
					288.57142857142844
				],
				[
					80,
					325.7142857142858
				],
				[
					34.28571428571422,
					348.57142857142844
				],
				[
					25.71428571428578,
					351.42857142857133
				],
				[
					-25.71428571428578,
					354.2857142857142
				],
				[
					-71.42857142857156,
					348.57142857142844
				],
				[
					-108.57142857142844,
					322.8571428571429
				],
				[
					-122.85714285714312,
					305.7142857142858
				],
				[
					-128.57142857142844,
					300
				],
				[
					-128.57142857142844,
					302.8571428571429
				],
				[
					-128.57142857142844,
					311.42857142857133
				],
				[
					-122.85714285714312,
					331.42857142857133
				],
				[
					-108.57142857142844,
					345.7142857142858
				],
				[
					-88.57142857142844,
					360
				],
				[
					-71.42857142857156,
					368.57142857142844
				],
				[
					-48.57142857142844,
					374.2857142857142
				],
				[
					-17.142857142857338,
					374.2857142857142
				],
				[
					8.571428571428442,
					368.57142857142844
				],
				[
					31.42857142857156,
					360
				],
				[
					62.85714285714266,
					337.1428571428571
				],
				[
					82.85714285714266,
					320
				],
				[
					102.85714285714266,
					297.1428571428571
				],
				[
					114.28571428571422,
					277.1428571428571
				],
				[
					122.85714285714266,
					254.28571428571422
				],
				[
					125.71428571428578,
					225.71428571428578
				],
				[
					120,
					188.57142857142844
				],
				[
					114.28571428571422,
					162.8571428571429
				],
				[
					108.57142857142844,
					142.8571428571429
				],
				[
					105.71428571428578,
					137.1428571428571
				],
				[
					94.28571428571422,
					114.28571428571422
				],
				[
					80,
					94.28571428571422
				],
				[
					65.71428571428578,
					71.42857142857144
				],
				[
					54.28571428571422,
					54.28571428571422
				],
				[
					42.85714285714266,
					34.28571428571422
				],
				[
					31.42857142857156,
					17.14285714285711
				],
				[
					25.71428571428578,
					8.571428571428555
				],
				[
					22.857142857142662,
					2.857142857142776
				],
				[
					17.142857142857338,
					-2.8571428571428896
				],
				[
					14.28571428571422,
					-5.714285714285779
				],
				[
					8.571428571428442,
					-8.571428571428669
				],
				[
					8.571428571428442,
					-5.714285714285779
				],
				[
					14.28571428571422,
					-2.8571428571428896
				],
				[
					22.857142857142662,
					11.428571428571445
				],
				[
					48.57142857142844,
					51.428571428571445
				],
				[
					62.85714285714266,
					71.42857142857144
				],
				[
					85.71428571428578,
					117.14285714285711
				],
				[
					88.57142857142844,
					128.57142857142844
				],
				[
					97.14285714285734,
					165.71428571428578
				],
				[
					102.85714285714266,
					202.8571428571429
				],
				[
					100,
					248.57142857142844
				],
				[
					94.28571428571422,
					277.1428571428571
				],
				[
					82.85714285714266,
					308.57142857142844
				],
				[
					80,
					314.2857142857142
				],
				[
					65.71428571428578,
					328.57142857142844
				],
				[
					51.42857142857156,
					342.8571428571429
				],
				[
					28.57142857142844,
					354.2857142857142
				],
				[
					-42.85714285714312,
					357.1428571428571
				],
				[
					-88.57142857142844,
					354.2857142857142
				],
				[
					-122.85714285714312,
					320
				],
				[
					-148.57142857142844,
					268.57142857142844
				],
				[
					-145.71428571428578,
					248.57142857142844
				],
				[
					-145.71428571428578,
					248.57142857142844
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-145.71428571428578,
				248.57142857142844
			]
		},
		{
			"id": "am7E8cVGMQs6Ged-62aWA",
			"type": "freedraw",
			"x": 2329.2147680390262,
			"y": 45.736235119047706,
			"width": 85.71428571428578,
			"height": 100,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 966252125,
			"version": 43,
			"versionNonce": 113545779,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					60,
					-22.85714285714289
				],
				[
					68.57142857142844,
					-14.28571428571422
				],
				[
					74.28571428571422,
					-2.8571428571428896
				],
				[
					77.14285714285734,
					20
				],
				[
					65.71428571428578,
					42.85714285714289
				],
				[
					48.57142857142844,
					51.42857142857156
				],
				[
					25.71428571428578,
					51.42857142857156
				],
				[
					14.28571428571422,
					45.71428571428578
				],
				[
					8.571428571428442,
					34.28571428571445
				],
				[
					5.714285714285779,
					14.285714285714448
				],
				[
					11.428571428571558,
					0
				],
				[
					20,
					-14.28571428571422
				],
				[
					34.28571428571422,
					-31.42857142857133
				],
				[
					42.85714285714312,
					-34.28571428571422
				],
				[
					57.14285714285734,
					-34.28571428571422
				],
				[
					65.71428571428578,
					-28.57142857142844
				],
				[
					77.14285714285734,
					-17.14285714285711
				],
				[
					85.71428571428578,
					2.8571428571428896
				],
				[
					85.71428571428578,
					20
				],
				[
					80,
					34.28571428571445
				],
				[
					68.57142857142844,
					54.28571428571445
				],
				[
					54.28571428571422,
					62.85714285714289
				],
				[
					34.28571428571422,
					65.71428571428578
				],
				[
					20,
					60
				],
				[
					11.428571428571558,
					48.57142857142867
				],
				[
					8.571428571428442,
					28.57142857142867
				],
				[
					14.28571428571422,
					2.8571428571428896
				],
				[
					20,
					-8.571428571428442
				],
				[
					22.857142857143117,
					-11.428571428571331
				],
				[
					34.28571428571422,
					-20
				],
				[
					42.85714285714312,
					-20
				],
				[
					54.28571428571422,
					-8.571428571428442
				],
				[
					57.14285714285734,
					5.714285714285779
				],
				[
					57.14285714285734,
					22.85714285714289
				],
				[
					51.42857142857156,
					34.28571428571445
				],
				[
					37.14285714285734,
					37.14285714285711
				],
				[
					31.42857142857156,
					37.14285714285711
				],
				[
					25.71428571428578,
					34.28571428571445
				],
				[
					25.71428571428578,
					34.28571428571445
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				25.71428571428578,
				34.28571428571445
			]
		},
		{
			"id": "c4vOT6Yrt-Ehv06QvZC7g",
			"type": "freedraw",
			"x": 1986.3576251818836,
			"y": 160.02194940476215,
			"width": 25.71428571428578,
			"height": 174.28571428571422,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 514994803,
			"version": 15,
			"versionNonce": 590028413,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.7142857142853245,
					20
				],
				[
					5.7142857142853245,
					31.42857142857133
				],
				[
					11.428571428571104,
					80
				],
				[
					11.428571428571104,
					114.28571428571422
				],
				[
					2.8571428571426623,
					151.42857142857133
				],
				[
					-2.857142857143117,
					168.57142857142844
				],
				[
					-8.571428571428896,
					174.28571428571422
				],
				[
					-14.285714285714675,
					171.42857142857133
				],
				[
					-14.285714285714675,
					160
				],
				[
					-14.285714285714675,
					157.1428571428571
				],
				[
					-14.285714285714675,
					157.1428571428571
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-14.285714285714675,
				157.1428571428571
			]
		},
		{
			"id": "5-XUFbJNrreAs28A2B9nk",
			"type": "freedraw",
			"x": 1983.5004823247405,
			"y": 157.16480654761926,
			"width": 28.571428571428896,
			"height": 242.8571428571429,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 524882045,
			"version": 15,
			"versionNonce": 1333384147,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428442,
					-8.571428571428669
				],
				[
					8.571428571428442,
					-5.714285714285779
				],
				[
					17.142857142857338,
					25.714285714285552
				],
				[
					22.857142857143117,
					74.28571428571422
				],
				[
					22.857142857143117,
					131.42857142857133
				],
				[
					17.142857142857338,
					171.42857142857133
				],
				[
					5.714285714285779,
					214.28571428571422
				],
				[
					0,
					231.42857142857133
				],
				[
					-5.714285714285779,
					234.28571428571422
				],
				[
					-5.714285714285779,
					228.57142857142844
				],
				[
					-5.714285714285779,
					228.57142857142844
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-5.714285714285779,
				228.57142857142844
			]
		},
		{
			"id": "43ALTH1ZWsP5M-MmP9P2z",
			"type": "freedraw",
			"x": 2340.643339467598,
			"y": 191.45052083333348,
			"width": 108.5714285714289,
			"height": 268.57142857142867,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 781404051,
			"version": 46,
			"versionNonce": 1553745629,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-34.28571428571422,
					48.57142857142867
				],
				[
					-37.14285714285734,
					100
				],
				[
					-25.71428571428578,
					148.57142857142867
				],
				[
					0,
					191.42857142857156
				],
				[
					5.714285714285779,
					194.28571428571422
				],
				[
					5.714285714285779,
					191.42857142857156
				],
				[
					5.714285714285779,
					177.1428571428571
				],
				[
					5.714285714285779,
					171.42857142857156
				],
				[
					8.571428571428442,
					140
				],
				[
					2.8571428571426623,
					100
				],
				[
					2.8571428571426623,
					65.71428571428578
				],
				[
					8.571428571428442,
					42.85714285714289
				],
				[
					8.571428571428442,
					37.14285714285711
				],
				[
					14.28571428571422,
					14.28571428571422
				],
				[
					14.28571428571422,
					8.571428571428669
				],
				[
					8.571428571428442,
					14.28571428571422
				],
				[
					2.8571428571426623,
					31.42857142857156
				],
				[
					-5.714285714285779,
					74.28571428571422
				],
				[
					-5.714285714285779,
					128.57142857142867
				],
				[
					0,
					162.8571428571429
				],
				[
					14.28571428571422,
					197.1428571428571
				],
				[
					22.857142857142662,
					211.42857142857156
				],
				[
					31.42857142857156,
					220
				],
				[
					31.42857142857156,
					217.1428571428571
				],
				[
					31.42857142857156,
					211.42857142857156
				],
				[
					31.42857142857156,
					194.28571428571422
				],
				[
					31.42857142857156,
					174.28571428571422
				],
				[
					22.857142857142662,
					134.28571428571422
				],
				[
					14.28571428571422,
					105.71428571428578
				],
				[
					8.571428571428442,
					74.28571428571422
				],
				[
					5.714285714285779,
					57.14285714285711
				],
				[
					0,
					65.71428571428578
				],
				[
					0,
					77.14285714285711
				],
				[
					-2.857142857143117,
					88.57142857142867
				],
				[
					2.8571428571426623,
					137.1428571428571
				],
				[
					11.428571428571558,
					174.28571428571422
				],
				[
					28.57142857142844,
					217.1428571428571
				],
				[
					45.71428571428578,
					240
				],
				[
					60,
					254.28571428571422
				],
				[
					71.42857142857156,
					265.7142857142858
				],
				[
					71.42857142857156,
					268.57142857142867
				],
				[
					71.42857142857156,
					268.57142857142867
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				71.42857142857156,
				268.57142857142867
			]
		},
		{
			"id": "5_E5-SOaTFkwFIhB26b5l",
			"type": "freedraw",
			"x": 1974.929053753312,
			"y": 360.02194940476215,
			"width": 148.57142857142844,
			"height": 225.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 682407763,
			"version": 36,
			"versionNonce": 2136334707,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428442,
					-8.571428571428669
				],
				[
					2.8571428571426623,
					11.428571428571331
				],
				[
					0,
					17.14285714285711
				],
				[
					-25.71428571428578,
					54.28571428571422
				],
				[
					-31.42857142857156,
					60
				],
				[
					-54.28571428571422,
					74.28571428571422
				],
				[
					-91.42857142857156,
					94.28571428571422
				],
				[
					-97.14285714285734,
					94.28571428571422
				],
				[
					-105.71428571428578,
					100
				],
				[
					-108.57142857142844,
					102.85714285714289
				],
				[
					-108.57142857142844,
					111.42857142857133
				],
				[
					-105.71428571428578,
					111.42857142857133
				],
				[
					-100,
					108.57142857142844
				],
				[
					-94.28571428571422,
					102.85714285714289
				],
				[
					-94.28571428571422,
					100
				],
				[
					-82.85714285714312,
					85.71428571428555
				],
				[
					-80,
					77.14285714285711
				],
				[
					-80,
					71.42857142857133
				],
				[
					-82.85714285714312,
					71.42857142857133
				],
				[
					-94.28571428571422,
					88.57142857142844
				],
				[
					-105.71428571428578,
					108.57142857142844
				],
				[
					-117.14285714285734,
					137.1428571428571
				],
				[
					-131.42857142857156,
					177.1428571428571
				],
				[
					-137.14285714285734,
					205.71428571428555
				],
				[
					-140,
					217.1428571428571
				],
				[
					-140,
					214.28571428571422
				],
				[
					-140,
					202.8571428571429
				],
				[
					-140,
					200
				],
				[
					-137.14285714285734,
					188.57142857142844
				],
				[
					-134.28571428571422,
					177.1428571428571
				],
				[
					-134.28571428571422,
					171.42857142857133
				],
				[
					-134.28571428571422,
					171.42857142857133
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-134.28571428571422,
				171.42857142857133
			]
		},
		{
			"id": "l7cMxk54JKcESWjgcZtAq",
			"type": "freedraw",
			"x": 2057.7861966104547,
			"y": 588.5933779761906,
			"width": 168.57142857142844,
			"height": 88.57142857142844,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 253660915,
			"version": 64,
			"versionNonce": 847864637,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.714285714285779,
					-11.428571428571331
				],
				[
					2.857142857143117,
					2.8571428571428896
				],
				[
					11.428571428571558,
					11.428571428571558
				],
				[
					28.571428571428896,
					28.57142857142867
				],
				[
					40,
					37.14285714285711
				],
				[
					42.85714285714312,
					37.14285714285711
				],
				[
					42.85714285714312,
					34.28571428571445
				],
				[
					40,
					28.57142857142867
				],
				[
					37.14285714285734,
					25.71428571428578
				],
				[
					22.857142857143117,
					8.571428571428669
				],
				[
					14.28571428571422,
					-2.8571428571428896
				],
				[
					-2.8571428571426623,
					-20
				],
				[
					-11.428571428571104,
					-25.714285714285552
				],
				[
					-17.142857142856883,
					-31.42857142857133
				],
				[
					-14.28571428571422,
					-28.57142857142844
				],
				[
					-5.714285714285779,
					-14.28571428571422
				],
				[
					8.571428571428896,
					5.714285714285779
				],
				[
					31.42857142857156,
					28.57142857142867
				],
				[
					48.571428571428896,
					42.85714285714289
				],
				[
					54.28571428571422,
					45.71428571428578
				],
				[
					54.28571428571422,
					42.85714285714289
				],
				[
					45.71428571428578,
					37.14285714285711
				],
				[
					25.71428571428578,
					20
				],
				[
					20,
					17.14285714285711
				],
				[
					17.142857142857338,
					14.285714285714448
				],
				[
					8.571428571428896,
					11.428571428571558
				],
				[
					8.571428571428896,
					8.571428571428669
				],
				[
					8.571428571428896,
					11.428571428571558
				],
				[
					20,
					25.71428571428578
				],
				[
					34.28571428571422,
					37.14285714285711
				],
				[
					54.28571428571422,
					48.57142857142867
				],
				[
					65.71428571428578,
					54.28571428571445
				],
				[
					71.42857142857156,
					57.14285714285711
				],
				[
					71.42857142857156,
					54.28571428571445
				],
				[
					74.28571428571422,
					48.57142857142867
				],
				[
					77.14285714285734,
					37.14285714285711
				],
				[
					85.71428571428578,
					25.71428571428578
				],
				[
					102.85714285714312,
					5.714285714285779
				],
				[
					120,
					-14.28571428571422
				],
				[
					128.5714285714289,
					-25.714285714285552
				],
				[
					131.42857142857156,
					-28.57142857142844
				],
				[
					128.5714285714289,
					-25.714285714285552
				],
				[
					125.71428571428578,
					-20
				],
				[
					117.14285714285734,
					-8.571428571428442
				],
				[
					108.5714285714289,
					8.571428571428669
				],
				[
					97.14285714285734,
					25.71428571428578
				],
				[
					85.71428571428578,
					37.14285714285711
				],
				[
					77.14285714285734,
					45.71428571428578
				],
				[
					71.42857142857156,
					48.57142857142867
				],
				[
					71.42857142857156,
					45.71428571428578
				],
				[
					80,
					31.42857142857156
				],
				[
					85.71428571428578,
					25.71428571428578
				],
				[
					120,
					-5.714285714285552
				],
				[
					148.5714285714289,
					-28.57142857142844
				],
				[
					151.42857142857156,
					-28.57142857142844
				],
				[
					148.5714285714289,
					-28.57142857142844
				],
				[
					140,
					-20
				],
				[
					131.42857142857156,
					-14.28571428571422
				],
				[
					128.5714285714289,
					-14.28571428571422
				],
				[
					128.5714285714289,
					-14.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				128.5714285714289,
				-14.28571428571422
			]
		},
		{
			"id": "-JEgnY0K0Acx3EAZnMoXY",
			"type": "freedraw",
			"x": 2132.071910896169,
			"y": 574.3076636904764,
			"width": 17.142857142856883,
			"height": 94.28571428571422,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2139694419,
			"version": 31,
			"versionNonce": 530529043,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					2.8571428571428896
				],
				[
					0,
					22.85714285714289
				],
				[
					0,
					37.14285714285711
				],
				[
					0,
					51.42857142857133
				],
				[
					0,
					60
				],
				[
					-2.8571428571426623,
					62.85714285714289
				],
				[
					-5.7142857142853245,
					60
				],
				[
					-5.7142857142853245,
					51.42857142857133
				],
				[
					-5.7142857142853245,
					40
				],
				[
					-5.7142857142853245,
					25.71428571428578
				],
				[
					-5.7142857142853245,
					5.714285714285779
				],
				[
					-2.8571428571426623,
					-5.714285714285779
				],
				[
					0,
					-20
				],
				[
					0,
					-25.71428571428578
				],
				[
					0,
					-31.42857142857133
				],
				[
					0,
					-28.57142857142867
				],
				[
					0,
					-14.28571428571422
				],
				[
					-2.8571428571426623,
					22.85714285714289
				],
				[
					-2.8571428571426623,
					40
				],
				[
					0,
					51.42857142857133
				],
				[
					2.857142857143117,
					54.28571428571422
				],
				[
					8.571428571428896,
					60
				],
				[
					11.428571428571558,
					60
				],
				[
					11.428571428571558,
					54.28571428571422
				],
				[
					11.428571428571558,
					51.42857142857133
				],
				[
					2.857142857143117,
					51.42857142857133
				],
				[
					2.857142857143117,
					51.42857142857133
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.857142857143117,
				51.42857142857133
			]
		},
		{
			"id": "WiXmGyNcVQ4ikypgxgH6S",
			"type": "freedraw",
			"x": 2103.5004823247405,
			"y": 634.3076636904764,
			"width": 14.28571428571422,
			"height": 105.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1963013789,
			"version": 41,
			"versionNonce": 424932253,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-2.8571428571428896
				],
				[
					-2.8571428571426623,
					-2.8571428571428896
				],
				[
					-2.8571428571426623,
					-5.714285714285779
				],
				[
					-2.8571428571426623,
					-8.571428571428669
				],
				[
					-2.8571428571426623,
					-11.428571428571331
				],
				[
					-2.8571428571426623,
					-17.14285714285711
				],
				[
					0,
					-25.71428571428578
				],
				[
					0,
					-37.14285714285711
				],
				[
					5.714285714285779,
					-54.28571428571422
				],
				[
					8.571428571428442,
					-74.28571428571422
				],
				[
					8.571428571428442,
					-82.85714285714289
				],
				[
					8.571428571428442,
					-85.71428571428578
				],
				[
					8.571428571428442,
					-82.85714285714289
				],
				[
					5.714285714285779,
					-80
				],
				[
					5.714285714285779,
					-77.14285714285711
				],
				[
					5.714285714285779,
					-74.28571428571422
				],
				[
					5.714285714285779,
					-80
				],
				[
					0,
					-91.42857142857133
				],
				[
					0,
					-97.14285714285711
				],
				[
					0,
					-88.57142857142867
				],
				[
					0,
					-57.14285714285711
				],
				[
					5.714285714285779,
					-28.57142857142867
				],
				[
					11.428571428571558,
					-8.571428571428669
				],
				[
					11.428571428571558,
					-5.714285714285779
				],
				[
					11.428571428571558,
					2.8571428571428896
				],
				[
					8.571428571428442,
					5.714285714285779
				],
				[
					5.714285714285779,
					2.8571428571428896
				],
				[
					5.714285714285779,
					-14.28571428571422
				],
				[
					5.714285714285779,
					-22.85714285714289
				],
				[
					5.714285714285779,
					-25.71428571428578
				],
				[
					8.571428571428442,
					-14.28571428571422
				],
				[
					8.571428571428442,
					-2.8571428571428896
				],
				[
					8.571428571428442,
					0
				],
				[
					11.428571428571558,
					5.714285714285779
				],
				[
					11.428571428571558,
					8.571428571428669
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				11.428571428571558,
				8.571428571428669
			]
		},
		{
			"id": "CqetRTpLcEu61G4GEnaDQ",
			"type": "freedraw",
			"x": 2172.071910896169,
			"y": 631.4505208333335,
			"width": 68.5714285714289,
			"height": 54.28571428571422,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1720328339,
			"version": 12,
			"versionNonce": 1288462515,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					37.14285714285734,
					48.57142857142867
				],
				[
					42.85714285714312,
					51.42857142857156
				],
				[
					57.14285714285734,
					54.28571428571422
				],
				[
					65.71428571428578,
					54.28571428571422
				],
				[
					68.5714285714289,
					54.28571428571422
				],
				[
					65.71428571428578,
					51.42857142857156
				],
				[
					60,
					48.57142857142867
				],
				[
					60,
					48.57142857142867
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				60,
				48.57142857142867
			]
		},
		{
			"id": "tfA1DmiqlFGPEOt6H0ASP",
			"type": "freedraw",
			"x": 2174.929053753312,
			"y": 662.879092261905,
			"width": 68.57142857142844,
			"height": 45.71428571428555,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 388261043,
			"version": 14,
			"versionNonce": 2100131837,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.714285714285779,
					2.8571428571426623
				],
				[
					0,
					11.428571428571331
				],
				[
					17.142857142856883,
					25.714285714285552
				],
				[
					31.42857142857156,
					37.14285714285711
				],
				[
					48.57142857142844,
					45.71428571428555
				],
				[
					57.14285714285688,
					45.71428571428555
				],
				[
					62.85714285714266,
					42.85714285714266
				],
				[
					62.85714285714266,
					37.14285714285711
				],
				[
					62.85714285714266,
					34.28571428571422
				],
				[
					62.85714285714266,
					34.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				62.85714285714266,
				34.28571428571422
			]
		},
		{
			"id": "LN-W_nCwLgi_EMQhyPBZu",
			"type": "freedraw",
			"x": 963.5004823247405,
			"y": -77.12090773809507,
			"width": 28.57142857142867,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2140930675,
			"version": 43,
			"versionNonce": 1350816339,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					-5.714285714285779
				],
				[
					2.8571428571428896,
					-2.8571428571428896
				],
				[
					2.8571428571428896,
					0
				],
				[
					2.8571428571428896,
					-2.8571428571428896
				],
				[
					11.428571428571331,
					-17.14285714285711
				],
				[
					20,
					-22.85714285714289
				],
				[
					22.85714285714289,
					-11.428571428571445
				],
				[
					17.14285714285711,
					0
				],
				[
					5.714285714285779,
					2.8571428571428896
				],
				[
					0,
					-2.8571428571428896
				],
				[
					0,
					-14.285714285714334
				],
				[
					11.428571428571331,
					-31.428571428571445
				],
				[
					20,
					-37.14285714285711
				],
				[
					25.71428571428578,
					-25.71428571428578
				],
				[
					25.71428571428578,
					-8.571428571428555
				],
				[
					25.71428571428578,
					5.714285714285666
				],
				[
					20,
					11.428571428571445
				],
				[
					17.14285714285711,
					14.28571428571422
				],
				[
					8.571428571428669,
					14.28571428571422
				],
				[
					0,
					11.428571428571445
				],
				[
					-2.8571428571428896,
					0
				],
				[
					-2.8571428571428896,
					-17.14285714285711
				],
				[
					0,
					-22.85714285714289
				],
				[
					0,
					-25.71428571428578
				],
				[
					5.714285714285779,
					-31.428571428571445
				],
				[
					14.28571428571422,
					-40
				],
				[
					20,
					-34.285714285714334
				],
				[
					25.71428571428578,
					-17.14285714285711
				],
				[
					25.71428571428578,
					0
				],
				[
					20,
					11.428571428571445
				],
				[
					8.571428571428669,
					20
				],
				[
					0,
					14.28571428571422
				],
				[
					0,
					-11.428571428571445
				],
				[
					11.428571428571331,
					-28.571428571428555
				],
				[
					25.71428571428578,
					-22.85714285714289
				],
				[
					25.71428571428578,
					-2.8571428571428896
				],
				[
					17.14285714285711,
					8.571428571428555
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				17.14285714285711,
				8.571428571428555
			]
		},
		{
			"id": "J7Nu01Ngs8SOeTckEXEHB",
			"type": "freedraw",
			"x": 994.9290537533118,
			"y": -119.97805059523796,
			"width": 20,
			"height": 42.85714285714289,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2125377981,
			"version": 11,
			"versionNonce": 1209495645,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					14.285714285714448,
					-8.571428571428555
				],
				[
					14.285714285714448,
					-5.714285714285666
				],
				[
					20,
					8.571428571428555
				],
				[
					20,
					25.71428571428578
				],
				[
					11.428571428571558,
					34.285714285714334
				],
				[
					8.571428571428669,
					34.285714285714334
				],
				[
					8.571428571428669,
					34.285714285714334
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428669,
				34.285714285714334
			]
		},
		{
			"id": "wDHUqy1lxtGup0KyGeC3U",
			"type": "freedraw",
			"x": 834.9290537533118,
			"y": 105.7362351190477,
			"width": 28.57142857142844,
			"height": 111.42857142857156,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 446673683,
			"version": 11,
			"versionNonce": 2073825267,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-25.714285714285552,
					28.57142857142867
				],
				[
					-28.57142857142844,
					37.14285714285711
				],
				[
					-28.57142857142844,
					65.71428571428578
				],
				[
					-22.857142857142662,
					97.14285714285711
				],
				[
					-11.428571428571331,
					108.57142857142867
				],
				[
					0,
					111.42857142857156
				],
				[
					0,
					111.42857142857156
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0,
				111.42857142857156
			]
		},
		{
			"id": "ykUpfJJgCviOisSsAJZb5",
			"type": "freedraw",
			"x": 812.0719108961691,
			"y": 117.16480654761926,
			"width": 71.42857142857133,
			"height": 122.85714285714289,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1943127325,
			"version": 13,
			"versionNonce": 669211837,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8.571428571428669,
					37.14285714285711
				],
				[
					-8.571428571428669,
					45.71428571428555
				],
				[
					0,
					82.85714285714289
				],
				[
					11.428571428571331,
					102.85714285714289
				],
				[
					28.57142857142844,
					120
				],
				[
					48.57142857142844,
					122.85714285714289
				],
				[
					60,
					117.14285714285711
				],
				[
					62.85714285714266,
					114.28571428571422
				],
				[
					62.85714285714266,
					114.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				62.85714285714266,
				114.28571428571422
			]
		},
		{
			"id": "vHi0CrImPtye-BEen7jWG",
			"type": "freedraw",
			"x": 857.7861966104547,
			"y": 217.16480654761926,
			"width": 62.85714285714289,
			"height": 162.8571428571429,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 719882067,
			"version": 15,
			"versionNonce": 1075550611,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.714285714285552,
					11.428571428571331
				],
				[
					-14.28571428571422,
					14.28571428571422
				],
				[
					-25.714285714285552,
					8.571428571428442
				],
				[
					-40,
					-14.285714285714448
				],
				[
					-54.28571428571422,
					-60
				],
				[
					-51.42857142857133,
					-68.57142857142867
				],
				[
					-31.42857142857133,
					-108.57142857142867
				],
				[
					-25.714285714285552,
					-114.28571428571445
				],
				[
					5.714285714285779,
					-145.71428571428578
				],
				[
					8.571428571428669,
					-148.57142857142867
				],
				[
					8.571428571428669,
					-148.57142857142867
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428669,
				-148.57142857142867
			]
		},
		{
			"id": "nmzi2YkJlN1VLn0kmQkWc",
			"type": "freedraw",
			"x": 854.9290537533118,
			"y": 88.5933779761906,
			"width": 62.85714285714289,
			"height": 17.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1711120797,
			"version": 10,
			"versionNonce": 338869533,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					25.71428571428578,
					-11.428571428571331
				],
				[
					31.42857142857156,
					-14.28571428571422
				],
				[
					45.71428571428578,
					-17.14285714285711
				],
				[
					60,
					-14.28571428571422
				],
				[
					62.85714285714289,
					-8.571428571428442
				],
				[
					62.85714285714289,
					-8.571428571428442
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				62.85714285714289,
				-8.571428571428442
			]
		},
		{
			"id": "oKFkCs2LxGUOfu6J2hKUK",
			"type": "freedraw",
			"x": 906.3576251818833,
			"y": 80.02194940476215,
			"width": 48.57142857142844,
			"height": 25.714285714285552,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2140498717,
			"version": 10,
			"versionNonce": 188280627,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					20,
					-2.8571428571428896
				],
				[
					34.28571428571422,
					2.8571428571426623
				],
				[
					45.71428571428578,
					14.28571428571422
				],
				[
					48.57142857142844,
					20
				],
				[
					42.85714285714289,
					22.857142857142662
				],
				[
					42.85714285714289,
					22.857142857142662
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				42.85714285714289,
				22.857142857142662
			]
		},
		{
			"id": "H-08z32HpHXThiOdLFNVa",
			"type": "freedraw",
			"x": 932.0719108961691,
			"y": 85.7362351190477,
			"width": 17.14285714285711,
			"height": 17.142857142857338,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1748792477,
			"version": 11,
			"versionNonce": 343347581,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285552,
					-2.8571428571428896
				],
				[
					8.571428571428442,
					0
				],
				[
					11.428571428571331,
					0
				],
				[
					14.28571428571422,
					8.571428571428669
				],
				[
					17.14285714285711,
					14.285714285714448
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				17.14285714285711,
				14.285714285714448
			]
		},
		{
			"id": "N6V__18Bww5flp5a5pAqn",
			"type": "freedraw",
			"x": 932.0719108961691,
			"y": 94.30766369047637,
			"width": 51.42857142857133,
			"height": 14.28571428571422,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1406500403,
			"version": 13,
			"versionNonce": 1599770835,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428442,
					-11.428571428571558
				],
				[
					11.428571428571331,
					-11.428571428571558
				],
				[
					14.28571428571422,
					-14.28571428571422
				],
				[
					28.57142857142844,
					-14.28571428571422
				],
				[
					40,
					-8.571428571428669
				],
				[
					48.57142857142844,
					-5.714285714285779
				],
				[
					51.42857142857133,
					-2.8571428571428896
				],
				[
					45.71428571428555,
					0
				],
				[
					45.71428571428555,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				45.71428571428555,
				0
			]
		},
		{
			"id": "2RrDIG37JjcPOwaQ4DThq",
			"type": "freedraw",
			"x": 949.2147680390262,
			"y": 85.7362351190477,
			"width": 20,
			"height": 8.571428571428442,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 150389853,
			"version": 9,
			"versionNonce": 1173477853,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285552,
					-8.571428571428442
				],
				[
					17.14285714285711,
					-8.571428571428442
				],
				[
					20,
					-8.571428571428442
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				20,
				-8.571428571428442
			]
		},
		{
			"id": "-qXwBiJQqxArfYpRorh6l",
			"type": "freedraw",
			"x": 977.7861966104547,
			"y": 82.87909226190482,
			"width": 25.71428571428578,
			"height": 11.428571428571558,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 406977747,
			"version": 7,
			"versionNonce": 773258867,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					20,
					8.571428571428669
				],
				[
					25.71428571428578,
					11.428571428571558
				],
				[
					25.71428571428578,
					11.428571428571558
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				25.71428571428578,
				11.428571428571558
			]
		},
		{
			"id": "ERNXwoqvbEMSo2yBsMqmn",
			"type": "freedraw",
			"x": 983.5004823247405,
			"y": 91.45052083333348,
			"width": 88.57142857142867,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 821107357,
			"version": 25,
			"versionNonce": 565483069,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					40,
					-2.8571428571428896
				],
				[
					45.71428571428578,
					0
				],
				[
					62.85714285714289,
					5.714285714285779
				],
				[
					68.57142857142867,
					8.571428571428669
				],
				[
					82.85714285714289,
					14.28571428571422
				],
				[
					88.57142857142867,
					17.14285714285711
				],
				[
					85.71428571428578,
					17.14285714285711
				],
				[
					77.14285714285711,
					17.14285714285711
				],
				[
					65.71428571428578,
					14.28571428571422
				],
				[
					54.28571428571422,
					5.714285714285779
				],
				[
					51.42857142857133,
					0
				],
				[
					57.14285714285711,
					-2.8571428571428896
				],
				[
					65.71428571428578,
					0
				],
				[
					74.28571428571422,
					11.428571428571331
				],
				[
					85.71428571428578,
					25.71428571428578
				],
				[
					88.57142857142867,
					40
				],
				[
					88.57142857142867,
					42.85714285714289
				],
				[
					82.85714285714289,
					51.42857142857133
				],
				[
					80,
					54.28571428571422
				],
				[
					80,
					57.14285714285711
				],
				[
					80,
					57.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				80,
				57.14285714285711
			]
		},
		{
			"id": "_tQEBxyUoh2E7Xr7tit7S",
			"type": "freedraw",
			"x": 952.0719108961691,
			"y": 240.02194940476215,
			"width": 51.42857142857133,
			"height": 25.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 799473555,
			"version": 11,
			"versionNonce": 1916057619,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571426623,
					-2.8571428571428896
				],
				[
					5.714285714285552,
					0
				],
				[
					31.42857142857133,
					22.85714285714289
				],
				[
					37.14285714285711,
					22.85714285714289
				],
				[
					42.85714285714266,
					22.85714285714289
				],
				[
					51.42857142857133,
					14.28571428571422
				],
				[
					51.42857142857133,
					14.28571428571422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				51.42857142857133,
				14.28571428571422
			]
		},
		{
			"id": "qaxYAXrQIiUvOne58wxeS",
			"type": "freedraw",
			"x": 972.0719108961691,
			"y": 254.30766369047637,
			"width": 80,
			"height": 5.714285714285779,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 681164957,
			"version": 6,
			"versionNonce": 44091037,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					80,
					-5.714285714285779
				],
				[
					80,
					-5.714285714285779
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				80,
				-5.714285714285779
			]
		},
		{
			"id": "lephGWuIa5n1j3q76UrPz",
			"type": "freedraw",
			"x": 1037.7861966104547,
			"y": 257.16480654761926,
			"width": 45.71428571428578,
			"height": 25.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 806223197,
			"version": 9,
			"versionNonce": 162151859,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					45.71428571428578,
					-25.71428571428578
				],
				[
					37.14285714285734,
					-20
				],
				[
					0,
					-2.8571428571428896
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0,
				-2.8571428571428896
			]
		},
		{
			"id": "RUl2pY6iusbKC1IAWUPsg",
			"type": "freedraw",
			"x": 874.9290537533118,
			"y": 260.02194940476215,
			"width": 14.285714285714448,
			"height": 82.85714285714289,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 881996755,
			"version": 20,
			"versionNonce": 1801972477,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					25.714285714285552
				],
				[
					2.8571428571428896,
					34.28571428571422
				],
				[
					2.8571428571428896,
					37.14285714285711
				],
				[
					0,
					37.14285714285711
				],
				[
					0,
					34.28571428571422
				],
				[
					0,
					25.714285714285552
				],
				[
					0,
					14.28571428571422
				],
				[
					2.8571428571428896,
					5.714285714285552
				],
				[
					2.8571428571428896,
					2.8571428571428896
				],
				[
					5.714285714285779,
					14.28571428571422
				],
				[
					5.714285714285779,
					31.42857142857133
				],
				[
					11.428571428571558,
					71.42857142857133
				],
				[
					11.428571428571558,
					74.28571428571422
				],
				[
					14.285714285714448,
					82.85714285714289
				],
				[
					11.428571428571558,
					82.85714285714289
				],
				[
					11.428571428571558,
					82.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				11.428571428571558,
				82.85714285714289
			]
		},
		{
			"id": "2GXr9fxWEjoc85aibEixe",
			"type": "freedraw",
			"x": 872.0719108961691,
			"y": 248.5933779761906,
			"width": 17.14285714285711,
			"height": 111.42857142857156,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1992515187,
			"version": 10,
			"versionNonce": 1335758675,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					17.14285714285711,
					57.14285714285711
				],
				[
					17.14285714285711,
					65.71428571428578
				],
				[
					17.14285714285711,
					108.57142857142867
				],
				[
					11.428571428571331,
					111.42857142857156
				],
				[
					8.571428571428442,
					111.42857142857156
				],
				[
					8.571428571428442,
					111.42857142857156
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				8.571428571428442,
				111.42857142857156
			]
		},
		{
			"id": "7IThRWmdWPpfFDHYrLhop",
			"type": "freedraw",
			"x": 872.0719108961691,
			"y": 254.30766369047637,
			"width": 22.857142857142662,
			"height": 117.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1440943347,
			"version": 11,
			"versionNonce": 210469725,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8.571428571428669
				],
				[
					0,
					14.28571428571422
				],
				[
					8.571428571428442,
					54.28571428571422
				],
				[
					14.28571428571422,
					85.71428571428578
				],
				[
					22.857142857142662,
					111.42857142857133
				],
				[
					22.857142857142662,
					117.14285714285711
				],
				[
					22.857142857142662,
					117.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				22.857142857142662,
				117.14285714285711
			]
		},
		{
			"id": "P5MYE_3CTmYzbDnQxZ-xY",
			"type": "freedraw",
			"x": 883.5004823247405,
			"y": 242.87909226190504,
			"width": 8.571428571428669,
			"height": 145.71428571428555,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 795240765,
			"version": 13,
			"versionNonce": 1986440435,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.8571428571428896,
					48.57142857142844
				],
				[
					-2.8571428571428896,
					57.14285714285711
				],
				[
					-2.8571428571428896,
					100
				],
				[
					2.8571428571428896,
					131.42857142857133
				],
				[
					5.714285714285779,
					142.85714285714266
				],
				[
					5.714285714285779,
					145.71428571428555
				],
				[
					5.714285714285779,
					142.85714285714266
				],
				[
					2.8571428571428896,
					142.85714285714266
				],
				[
					2.8571428571428896,
					142.85714285714266
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				2.8571428571428896,
				142.85714285714266
			]
		},
		{
			"id": "Zkv_69i6U-WVk_k-lSxEB",
			"type": "freedraw",
			"x": 866.3576251818833,
			"y": 262.87909226190504,
			"width": 22.85714285714289,
			"height": 154.28571428571422,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1658784051,
			"version": 12,
			"versionNonce": 173871037,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.8571428571428896,
					51.42857142857133
				],
				[
					0,
					94.28571428571422
				],
				[
					5.714285714285779,
					131.42857142857133
				],
				[
					14.28571428571422,
					148.57142857142844
				],
				[
					17.14285714285711,
					151.42857142857133
				],
				[
					20,
					154.28571428571422
				],
				[
					20,
					151.42857142857133
				],
				[
					20,
					151.42857142857133
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				20,
				151.42857142857133
			]
		},
		{
			"id": "XCmIH5dgh4LZdYFi3l62i",
			"type": "freedraw",
			"x": 977.7861966104547,
			"y": 257.16480654761926,
			"width": 20,
			"height": 131.42857142857133,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1513351507,
			"version": 13,
			"versionNonce": 562730643,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285779,
					-2.8571428571428896
				],
				[
					8.571428571428669,
					0
				],
				[
					14.285714285714448,
					22.85714285714289
				],
				[
					20,
					60
				],
				[
					20,
					88.57142857142844
				],
				[
					20,
					114.28571428571422
				],
				[
					17.14285714285711,
					125.71428571428578
				],
				[
					14.285714285714448,
					128.57142857142844
				],
				[
					14.285714285714448,
					128.57142857142844
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				14.285714285714448,
				128.57142857142844
			]
		},
		{
			"id": "cPfn_obaNs95JhEZvWd_A",
			"type": "freedraw",
			"x": 989.2147680390262,
			"y": 254.30766369047637,
			"width": 14.28571428571422,
			"height": 162.8571428571429,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 994955069,
			"version": 14,
			"versionNonce": 50204701,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.571428571428442,
					22.85714285714289
				],
				[
					8.571428571428442,
					31.42857142857133
				],
				[
					14.28571428571422,
					68.57142857142867
				],
				[
					14.28571428571422,
					111.42857142857133
				],
				[
					11.428571428571331,
					142.8571428571429
				],
				[
					8.571428571428442,
					160
				],
				[
					8.571428571428442,
					162.8571428571429
				],
				[
					5.714285714285552,
					160
				],
				[
					5.714285714285552,
					157.1428571428571
				],
				[
					5.714285714285552,
					157.1428571428571
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				5.714285714285552,
				157.1428571428571
			]
		},
		{
			"id": "ZkPyGfgZP6EljF37gtoJ8",
			"type": "freedraw",
			"x": 1006.3576251818833,
			"y": 268.5933779761906,
			"width": 8.571428571428669,
			"height": 145.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 301628797,
			"version": 16,
			"versionNonce": 1069567027,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					0
				],
				[
					5.714285714285779,
					25.71428571428578
				],
				[
					5.714285714285779,
					54.28571428571445
				],
				[
					5.714285714285779,
					94.28571428571445
				],
				[
					2.8571428571428896,
					128.57142857142867
				],
				[
					0,
					140
				],
				[
					0,
					145.71428571428578
				],
				[
					-2.8571428571428896,
					145.71428571428578
				],
				[
					-2.8571428571428896,
					142.8571428571429
				],
				[
					-2.8571428571428896,
					137.1428571428571
				],
				[
					-2.8571428571428896,
					131.42857142857156
				],
				[
					-2.8571428571428896,
					131.42857142857156
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-2.8571428571428896,
				131.42857142857156
			]
		},
		{
			"id": "ChxpfVe-I4XoJ-DBcxIsX",
			"type": "freedraw",
			"x": 1000.6433394675976,
			"y": 282.87909226190504,
			"width": 20,
			"height": 200,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1725103133,
			"version": 12,
			"versionNonce": 1415578749,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571428896,
					62.85714285714266
				],
				[
					2.8571428571428896,
					74.28571428571422
				],
				[
					2.8571428571428896,
					131.42857142857133
				],
				[
					0,
					151.42857142857133
				],
				[
					-2.8571428571428896,
					180
				],
				[
					-8.571428571428442,
					200
				],
				[
					-17.14285714285711,
					200
				],
				[
					-17.14285714285711,
					200
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-17.14285714285711,
				200
			]
		},
		{
			"id": "QgC9Y1xuFglnJaWXJEV0f",
			"type": "freedraw",
			"x": 900.6433394675976,
			"y": 420.02194940476215,
			"width": 42.85714285714289,
			"height": 80,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 922798589,
			"version": 38,
			"versionNonce": 619597267,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-14.28571428571422,
					-17.14285714285711
				],
				[
					-14.28571428571422,
					-14.285714285714448
				],
				[
					-17.14285714285711,
					-2.8571428571428896
				],
				[
					-17.14285714285711,
					5.714285714285552
				],
				[
					-17.14285714285711,
					17.14285714285711
				],
				[
					-17.14285714285711,
					20
				],
				[
					-20,
					17.14285714285711
				],
				[
					-22.85714285714289,
					8.571428571428442
				],
				[
					-25.71428571428578,
					0
				],
				[
					-25.71428571428578,
					-2.8571428571428896
				],
				[
					-25.71428571428578,
					8.571428571428442
				],
				[
					-20,
					34.28571428571422
				],
				[
					-17.14285714285711,
					51.42857142857133
				],
				[
					-14.28571428571422,
					54.28571428571422
				],
				[
					-14.28571428571422,
					45.71428571428555
				],
				[
					-17.14285714285711,
					31.42857142857133
				],
				[
					-20,
					17.14285714285711
				],
				[
					-20,
					14.28571428571422
				],
				[
					-17.14285714285711,
					20
				],
				[
					-11.428571428571331,
					34.28571428571422
				],
				[
					-5.714285714285779,
					42.85714285714289
				],
				[
					-5.714285714285779,
					45.71428571428555
				],
				[
					-8.571428571428442,
					48.57142857142844
				],
				[
					-11.428571428571331,
					48.57142857142844
				],
				[
					-14.28571428571422,
					48.57142857142844
				],
				[
					-17.14285714285711,
					51.42857142857133
				],
				[
					-20,
					54.28571428571422
				],
				[
					-20,
					57.14285714285711
				],
				[
					-11.428571428571331,
					60
				],
				[
					8.571428571428669,
					60
				],
				[
					11.428571428571558,
					60
				],
				[
					17.14285714285711,
					60
				],
				[
					14.28571428571422,
					62.85714285714289
				],
				[
					14.28571428571422,
					62.85714285714289
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				14.28571428571422,
				62.85714285714289
			]
		},
		{
			"id": "dawmr0Vz3JGU_waOu0lYo",
			"type": "freedraw",
			"x": 900.6433394675976,
			"y": 485.7362351190477,
			"width": 25.71428571428578,
			"height": 17.142857142857338,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1735824573,
			"version": 7,
			"versionNonce": 574909661,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					25.71428571428578,
					17.142857142857338
				],
				[
					25.71428571428578,
					14.285714285714448
				],
				[
					25.71428571428578,
					14.285714285714448
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				25.71428571428578,
				14.285714285714448
			]
		},
		{
			"id": "Sg-VAROlFdDzoEHpOD5qt",
			"type": "freedraw",
			"x": 923.5004823247405,
			"y": 517.1648065476193,
			"width": 22.85714285714289,
			"height": 37.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 994367699,
			"version": 10,
			"versionNonce": 1680546675,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5.714285714285779
				],
				[
					2.8571428571428896,
					-11.428571428571558
				],
				[
					8.571428571428669,
					-20
				],
				[
					17.14285714285711,
					-34.28571428571422
				],
				[
					22.85714285714289,
					-37.14285714285711
				],
				[
					22.85714285714289,
					-37.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				22.85714285714289,
				-37.14285714285711
			]
		},
		{
			"id": "FTXwU_5AP9y59l44TT6CO",
			"type": "freedraw",
			"x": 937.7861966104547,
			"y": 482.87909226190504,
			"width": 2.8571428571428896,
			"height": 51.42857142857133,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1612994387,
			"version": 14,
			"versionNonce": 473745725,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.8571428571428896,
					11.428571428571331
				],
				[
					-2.8571428571428896,
					14.28571428571422
				],
				[
					-2.8571428571428896,
					25.714285714285552
				],
				[
					-2.8571428571428896,
					40
				],
				[
					-2.8571428571428896,
					45.71428571428555
				],
				[
					-2.8571428571428896,
					51.42857142857133
				],
				[
					0,
					51.42857142857133
				],
				[
					0,
					45.71428571428555
				],
				[
					0,
					42.85714285714266
				],
				[
					0,
					42.85714285714266
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0,
				42.85714285714266
			]
		},
		{
			"id": "6zDSlcivPzNti2kVNcuxV",
			"type": "freedraw",
			"x": 926.3576251818833,
			"y": 505.7362351190477,
			"width": 74.28571428571422,
			"height": 68.57142857142844,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1122860307,
			"version": 41,
			"versionNonce": 1774007571,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					17.142857142857338
				],
				[
					0,
					22.85714285714289
				],
				[
					0,
					25.71428571428578
				],
				[
					0,
					22.85714285714289
				],
				[
					0,
					17.142857142857338
				],
				[
					0,
					8.571428571428669
				],
				[
					5.714285714285779,
					-5.714285714285552
				],
				[
					14.28571428571422,
					-20
				],
				[
					25.71428571428578,
					-34.28571428571422
				],
				[
					31.42857142857133,
					-40
				],
				[
					37.14285714285711,
					-42.85714285714266
				],
				[
					37.14285714285711,
					-40
				],
				[
					37.14285714285711,
					-34.28571428571422
				],
				[
					34.28571428571422,
					-34.28571428571422
				],
				[
					28.57142857142844,
					-31.42857142857133
				],
				[
					34.28571428571422,
					-34.28571428571422
				],
				[
					40,
					-37.14285714285711
				],
				[
					48.57142857142844,
					-37.14285714285711
				],
				[
					57.14285714285711,
					-37.14285714285711
				],
				[
					60,
					-34.28571428571422
				],
				[
					60,
					-31.42857142857133
				],
				[
					57.14285714285711,
					-31.42857142857133
				],
				[
					54.28571428571422,
					-34.28571428571422
				],
				[
					57.14285714285711,
					-37.14285714285711
				],
				[
					60,
					-37.14285714285711
				],
				[
					62.85714285714289,
					-37.14285714285711
				],
				[
					68.57142857142844,
					-31.42857142857133
				],
				[
					71.42857142857133,
					-28.57142857142844
				],
				[
					68.57142857142844,
					-28.57142857142844
				],
				[
					68.57142857142844,
					-40
				],
				[
					71.42857142857133,
					-40
				],
				[
					74.28571428571422,
					-34.28571428571422
				],
				[
					74.28571428571422,
					-31.42857142857133
				],
				[
					74.28571428571422,
					-20
				],
				[
					65.71428571428578,
					-14.28571428571422
				],
				[
					60,
					-11.428571428571331
				],
				[
					60,
					-11.428571428571331
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				60,
				-11.428571428571331
			]
		},
		{
			"id": "VsD6hOc_jQtrcXOILFDu3",
			"type": "freedraw",
			"x": 906.3576251818833,
			"y": 488.5933779761906,
			"width": 77.14285714285711,
			"height": 94.28571428571445,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 128671933,
			"version": 40,
			"versionNonce": 61512093,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5.714285714285779,
					-11.428571428571331
				],
				[
					-8.571428571428669,
					-14.28571428571422
				],
				[
					-8.571428571428669,
					-17.14285714285711
				],
				[
					-14.28571428571422,
					-22.85714285714289
				],
				[
					-17.14285714285711,
					-22.85714285714289
				],
				[
					-20,
					-20
				],
				[
					-22.85714285714289,
					-11.428571428571331
				],
				[
					-22.85714285714289,
					-2.8571428571428896
				],
				[
					-25.71428571428578,
					-5.714285714285552
				],
				[
					-28.57142857142867,
					-8.571428571428442
				],
				[
					-34.28571428571422,
					-8.571428571428442
				],
				[
					-34.28571428571422,
					-5.714285714285552
				],
				[
					-34.28571428571422,
					0
				],
				[
					-31.42857142857156,
					14.285714285714448
				],
				[
					-22.85714285714289,
					31.42857142857156
				],
				[
					-14.28571428571422,
					37.14285714285711
				],
				[
					-8.571428571428669,
					40
				],
				[
					-8.571428571428669,
					37.14285714285711
				],
				[
					-11.428571428571558,
					34.28571428571445
				],
				[
					-17.14285714285711,
					28.57142857142867
				],
				[
					-20,
					25.71428571428578
				],
				[
					-20,
					28.57142857142867
				],
				[
					-14.28571428571422,
					37.14285714285711
				],
				[
					-2.8571428571428896,
					45.71428571428578
				],
				[
					8.571428571428442,
					57.14285714285711
				],
				[
					17.14285714285711,
					62.85714285714289
				],
				[
					20,
					62.85714285714289
				],
				[
					20,
					60
				],
				[
					20,
					57.14285714285711
				],
				[
					20,
					54.28571428571445
				],
				[
					20,
					57.14285714285711
				],
				[
					22.85714285714289,
					62.85714285714289
				],
				[
					31.42857142857133,
					71.42857142857156
				],
				[
					37.14285714285711,
					71.42857142857156
				],
				[
					42.85714285714289,
					71.42857142857156
				],
				[
					42.85714285714289,
					71.42857142857156
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				42.85714285714289,
				71.42857142857156
			]
		},
		{
			"id": "fecFlo1843eb-L-qmWhVh",
			"type": "freedraw",
			"x": 1009.2147680390262,
			"y": 477.16480654761926,
			"width": 57.14285714285711,
			"height": 85.71428571428578,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1277330397,
			"version": 34,
			"versionNonce": 1427839667,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5.714285714285779
				],
				[
					0,
					0
				],
				[
					0,
					5.714285714285779
				],
				[
					-2.8571428571428896,
					25.71428571428578
				],
				[
					-5.714285714285779,
					37.14285714285711
				],
				[
					-14.285714285714448,
					54.28571428571422
				],
				[
					-20,
					65.71428571428578
				],
				[
					-22.85714285714289,
					71.42857142857133
				],
				[
					-25.71428571428578,
					71.42857142857133
				],
				[
					-25.71428571428578,
					68.57142857142844
				],
				[
					-25.71428571428578,
					62.85714285714289
				],
				[
					-22.85714285714289,
					54.28571428571422
				],
				[
					-17.14285714285711,
					42.85714285714289
				],
				[
					-14.285714285714448,
					37.14285714285711
				],
				[
					-17.14285714285711,
					40
				],
				[
					-20,
					45.71428571428578
				],
				[
					-28.57142857142867,
					57.14285714285711
				],
				[
					-37.14285714285711,
					68.57142857142844
				],
				[
					-40,
					71.42857142857133
				],
				[
					-45.71428571428578,
					77.14285714285711
				],
				[
					-51.42857142857156,
					80
				],
				[
					-51.42857142857156,
					77.14285714285711
				],
				[
					-51.42857142857156,
					74.28571428571422
				],
				[
					-51.42857142857156,
					71.42857142857133
				],
				[
					-51.42857142857156,
					74.28571428571422
				],
				[
					-54.28571428571445,
					77.14285714285711
				],
				[
					-57.14285714285711,
					77.14285714285711
				],
				[
					-57.14285714285711,
					74.28571428571422
				],
				[
					-57.14285714285711,
					68.57142857142844
				],
				[
					-57.14285714285711,
					68.57142857142844
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-57.14285714285711,
				68.57142857142844
			]
		},
		{
			"id": "Aobml-FZ3Gk0Sq0CzLuD1",
			"type": "freedraw",
			"x": 1054.929053753312,
			"y": 105.7362351190477,
			"width": 22.85714285714289,
			"height": 108.57142857142867,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 523282909,
			"version": 16,
			"versionNonce": 1908366845,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					14.285714285714448
				],
				[
					2.8571428571426623,
					20
				],
				[
					8.571428571428442,
					31.42857142857156
				],
				[
					8.571428571428442,
					45.71428571428578
				],
				[
					8.571428571428442,
					51.42857142857156
				],
				[
					8.571428571428442,
					60
				],
				[
					8.571428571428442,
					71.42857142857156
				],
				[
					-2.8571428571428896,
					94.28571428571445
				],
				[
					-8.571428571428669,
					105.71428571428578
				],
				[
					-11.428571428571558,
					108.57142857142867
				],
				[
					-14.285714285714448,
					108.57142857142867
				],
				[
					-14.285714285714448,
					108.57142857142867
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-14.285714285714448,
				108.57142857142867
			]
		},
		{
			"id": "BEP8WVBzBKx7BmfhRzYsa",
			"type": "freedraw",
			"x": 1074.929053753312,
			"y": 148.5933779761906,
			"width": 11.428571428571331,
			"height": 77.14285714285711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 526963837,
			"version": 9,
			"versionNonce": 317410387,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.8571428571426623,
					40
				],
				[
					0,
					45.71428571428578
				],
				[
					-2.8571428571428896,
					68.57142857142867
				],
				[
					-8.571428571428669,
					77.14285714285711
				],
				[
					-8.571428571428669,
					77.14285714285711
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-8.571428571428669,
				77.14285714285711
			]
		},
		{
			"id": "gkejbtH13ELFrNEv7SaYV",
			"type": "freedraw",
			"x": 980.6433394675976,
			"y": -48.549479166666515,
			"width": 151.42857142857156,
			"height": 68.57142857142856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 49629875,
			"version": 13,
			"versionNonce": 1568446045,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					14.28571428571422,
					-22.85714285714289
				],
				[
					42.85714285714289,
					-40
				],
				[
					68.57142857142867,
					-51.428571428571445
				],
				[
					77.14285714285711,
					-54.285714285714334
				],
				[
					120,
					-62.85714285714289
				],
				[
					145.71428571428578,
					-68.57142857142856
				],
				[
					151.42857142857156,
					-68.57142857142856
				],
				[
					145.71428571428578,
					-65.71428571428567
				],
				[
					145.71428571428578,
					-65.71428571428567
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				145.71428571428578,
				-65.71428571428567
			]
		},
		{
			"id": "3tWq2Itsx0X7FB5SyVrM8",
			"type": "freedraw",
			"x": 992.0719108961691,
			"y": -65.69233630952363,
			"width": 234.28571428571422,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 2117259229,
			"version": 12,
			"versionNonce": 923027955,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5.714285714285552,
					-11.428571428571445
				],
				[
					11.428571428571331,
					-14.285714285714334
				],
				[
					45.71428571428555,
					-31.428571428571445
				],
				[
					160,
					-54.285714285714334
				],
				[
					225.71428571428555,
					-60
				],
				[
					234.28571428571422,
					-48.571428571428555
				],
				[
					217.1428571428571,
					-40
				],
				[
					217.1428571428571,
					-40
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				217.1428571428571,
				-40
			]
		},
		{
			"id": "r_X1w-Iskj8qH6l_plAFd",
			"type": "freedraw",
			"x": 1092.0719108961691,
			"y": -91.4066220238094,
			"width": 302.8571428571429,
			"height": 108.57142857142867,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1833190845,
			"version": 15,
			"versionNonce": 1639170749,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					45.71428571428555,
					-20
				],
				[
					54.28571428571422,
					-20
				],
				[
					102.85714285714289,
					-20
				],
				[
					162.8571428571429,
					-8.571428571428555
				],
				[
					214.28571428571422,
					5.714285714285779
				],
				[
					280,
					37.142857142857224
				],
				[
					302.8571428571429,
					62.85714285714289
				],
				[
					302.8571428571429,
					80
				],
				[
					282.8571428571429,
					85.71428571428578
				],
				[
					277.1428571428571,
					88.57142857142867
				],
				[
					277.1428571428571,
					88.57142857142867
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				277.1428571428571,
				88.57142857142867
			]
		},
		{
			"id": "4f0tKwdZ-IrWITPX9o9ro",
			"type": "freedraw",
			"x": 1303.5004823247405,
			"y": -54.26376488095218,
			"width": 157.1428571428571,
			"height": 271.42857142857133,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1725101651,
			"version": 15,
			"versionNonce": 376214419,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					37.14285714285711,
					-11.428571428571445
				],
				[
					54.28571428571422,
					-5.714285714285779
				],
				[
					91.42857142857156,
					28.571428571428555
				],
				[
					100,
					39.999999999999886
				],
				[
					125.71428571428578,
					77.142857142857
				],
				[
					151.42857142857156,
					145.71428571428567
				],
				[
					157.1428571428571,
					199.9999999999999
				],
				[
					154.28571428571422,
					237.142857142857
				],
				[
					145.71428571428578,
					257.142857142857
				],
				[
					137.1428571428571,
					259.9999999999999
				],
				[
					137.1428571428571,
					259.9999999999999
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				137.1428571428571,
				259.9999999999999
			]
		},
		{
			"id": "s2s4zBj3sOGU1ryq4CoCU",
			"type": "freedraw",
			"x": 1454.929053753312,
			"y": 77.16480654761926,
			"width": 54.28571428571422,
			"height": 274.2857142857142,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 935387805,
			"version": 15,
			"versionNonce": 1124492061,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					17.14285714285711,
					25.714285714285552
				],
				[
					20,
					34.28571428571422
				],
				[
					25.714285714285552,
					80
				],
				[
					28.57142857142844,
					91.42857142857133
				],
				[
					31.42857142857133,
					148.57142857142844
				],
				[
					25.714285714285552,
					191.42857142857133
				],
				[
					14.28571428571422,
					234.28571428571422
				],
				[
					2.8571428571426623,
					260
				],
				[
					-14.285714285714448,
					274.2857142857142
				],
				[
					-22.85714285714289,
					271.42857142857133
				],
				[
					-22.85714285714289,
					271.42857142857133
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-22.85714285714289,
				271.42857142857133
			]
		},
		{
			"id": "3ZFye2gFvU3UpAb3oIHA1",
			"type": "freedraw",
			"x": 1440.6433394675976,
			"y": 308.5933779761906,
			"width": 174.28571428571422,
			"height": 300,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1386200947,
			"version": 31,
			"versionNonce": 559589683,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-94.28571428571422,
					137.1428571428571
				],
				[
					-102.85714285714289,
					142.8571428571429
				],
				[
					-128.57142857142844,
					160
				],
				[
					-120,
					137.1428571428571
				],
				[
					-102.85714285714289,
					122.85714285714289
				],
				[
					-94.28571428571422,
					120
				],
				[
					-91.42857142857133,
					122.85714285714289
				],
				[
					-105.71428571428555,
					148.57142857142867
				],
				[
					-122.85714285714289,
					171.42857142857156
				],
				[
					-142.8571428571429,
					197.1428571428571
				],
				[
					-160,
					208.57142857142867
				],
				[
					-168.57142857142844,
					211.42857142857156
				],
				[
					-171.42857142857133,
					211.42857142857156
				],
				[
					-171.42857142857133,
					214.28571428571445
				],
				[
					-171.42857142857133,
					220
				],
				[
					-174.28571428571422,
					225.71428571428578
				],
				[
					-171.42857142857133,
					222.8571428571429
				],
				[
					-162.8571428571429,
					211.42857142857156
				],
				[
					-148.57142857142844,
					205.71428571428578
				],
				[
					-145.71428571428555,
					217.1428571428571
				],
				[
					-154.28571428571422,
					260
				],
				[
					-160,
					282.8571428571429
				],
				[
					-160,
					288.57142857142867
				],
				[
					-162.8571428571429,
					300
				],
				[
					-168.57142857142844,
					300
				],
				[
					-174.28571428571422,
					297.1428571428571
				],
				[
					-174.28571428571422,
					297.1428571428571
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-174.28571428571422,
				297.1428571428571
			]
		},
		{
			"id": "xZrB5-VtTgY37YyVWC7gH",
			"type": "freedraw",
			"x": 937.7861966104547,
			"y": -94.26376488095218,
			"width": 211.42857142857133,
			"height": 77.14285714285722,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1054836349,
			"version": 10,
			"versionNonce": 904263549,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-20,
					-57.142857142857224
				],
				[
					-31.42857142857133,
					-62.85714285714289
				],
				[
					-114.28571428571422,
					-77.14285714285722
				],
				[
					-177.1428571428571,
					-62.85714285714289
				],
				[
					-211.42857142857133,
					-37.142857142857224
				],
				[
					-211.42857142857133,
					-37.142857142857224
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-211.42857142857133,
				-37.142857142857224
			]
		},
		{
			"id": "nr4XpcocQBwO5xsBGjSDX",
			"type": "freedraw",
			"x": 800.6433394675976,
			"y": -154.26376488095218,
			"width": 188.57142857142856,
			"height": 125.71428571428567,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 124641277,
			"version": 14,
			"versionNonce": 2100628179,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-40,
					0
				],
				[
					-48.571428571428555,
					0
				],
				[
					-91.42857142857144,
					17.14285714285711
				],
				[
					-140,
					54.28571428571422
				],
				[
					-151.42857142857144,
					62.857142857142776
				],
				[
					-180,
					100
				],
				[
					-188.57142857142856,
					119.99999999999989
				],
				[
					-188.57142857142856,
					122.85714285714278
				],
				[
					-182.8571428571429,
					125.71428571428567
				],
				[
					-182.8571428571429,
					125.71428571428567
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-182.8571428571429,
				125.71428571428567
			]
		},
		{
			"id": "KUdiuQBnUI8fVXCUGFwxc",
			"type": "freedraw",
			"x": 666.3576251818833,
			"y": -102.83519345238085,
			"width": 148.57142857142867,
			"height": 277.1428571428572,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 713489981,
			"version": 11,
			"versionNonce": 1687420893,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-88.57142857142867,
					71.42857142857144
				],
				[
					-97.14285714285722,
					85.71428571428567
				],
				[
					-137.14285714285722,
					174.28571428571433
				],
				[
					-148.57142857142867,
					240.0000000000001
				],
				[
					-148.57142857142867,
					251.42857142857144
				],
				[
					-140,
					277.1428571428572
				],
				[
					-140,
					277.1428571428572
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-140,
				277.1428571428572
			]
		},
		{
			"id": "aYTi9BHEPXgGC9SxLzObx",
			"type": "freedraw",
			"x": 537.7861966104547,
			"y": 68.5933779761906,
			"width": 37.142857142857224,
			"height": 271.42857142857156,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 849784467,
			"version": 10,
			"versionNonce": 1586641011,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-20,
					125.71428571428578
				],
				[
					-20,
					142.8571428571429
				],
				[
					-11.428571428571331,
					220
				],
				[
					5.714285714285779,
					262.8571428571429
				],
				[
					17.142857142857224,
					271.42857142857156
				],
				[
					17.142857142857224,
					271.42857142857156
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				17.142857142857224,
				271.42857142857156
			]
		},
		{
			"id": "Za-yXSJt5AeSr_InoZ46b",
			"type": "freedraw",
			"x": 534.9290537533119,
			"y": 268.5933779761906,
			"width": 111.42857142857144,
			"height": 331.42857142857156,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"roundness": null,
			"seed": 1611484435,
			"version": 24,
			"versionNonce": 891419709,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680713426421,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					54.28571428571422,
					200
				],
				[
					45.714285714285666,
					182.8571428571429
				],
				[
					31.428571428571445,
					154.28571428571445
				],
				[
					31.428571428571445,
					157.1428571428571
				],
				[
					31.428571428571445,
					160
				],
				[
					40,
					185.71428571428578
				],
				[
					62.857142857142776,
					231.42857142857156
				],
				[
					68.57142857142856,
					240
				],
				[
					88.57142857142856,
					265.7142857142858
				],
				[
					94.28571428571422,
					268.57142857142867
				],
				[
					91.42857142857144,
					262.8571428571429
				],
				[
					88.57142857142856,
					254.28571428571445
				],
				[
					88.57142857142856,
					242.8571428571429
				],
				[
					88.57142857142856,
					240
				],
				[
					91.42857142857144,
					242.8571428571429
				],
				[
					94.28571428571422,
					262.8571428571429
				],
				[
					102.85714285714278,
					294.28571428571445
				],
				[
					111.42857142857144,
					320
				],
				[
					111.42857142857144,
					331.42857142857156
				],
				[
					111.42857142857144,
					331.42857142857156
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				111.42857142857144,
				331.42857142857156
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 1302.2138033895458,
		"scrollY": 346.09412202380923,
		"zoom": {
			"value": 0.35
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%