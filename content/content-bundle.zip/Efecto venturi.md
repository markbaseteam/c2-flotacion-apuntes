Porqué ingresa el aire? Es porque existe un delta de presión, con la presión externa mayor a la presión interna 
$$P_{0}>P_{1} $$
Se generan burbujas en presencia de espumantes, es un principio para generar burbujas.

[[Generación de burbujas en máquinas de flotación]]