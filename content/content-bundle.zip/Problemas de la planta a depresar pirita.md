- A pH muy alto puede ser de que baje la recuperación.
[[Clase Flotación 29 Nov-Depresión de la pirita]]
