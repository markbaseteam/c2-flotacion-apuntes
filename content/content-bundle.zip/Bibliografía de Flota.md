![[Pasted image 20221213214433.png]]

- [x] 1. El primer libro lo pude descargar.  
- [x] 2. El segundo libro lo encontré solamente como los avances de la froth flotation en un siglo de tiempo.
- [x] 3. El tercero lo tiene el profe en la última edición lo subió a los archivos del curso.
4. El cuarto no lo pude encontrar.
5. El quinto se ve bueno.
6. El 6to también se ve bueno, no lo he pillado igual
7. El 7mo es demasiado difícil de pillar
8. El octavo y último, no lo tengo pero debe ser fácil de encontrar.