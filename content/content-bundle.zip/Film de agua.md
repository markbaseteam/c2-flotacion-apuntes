### ¿Qué pasaría si ustedes saltan en una gran burbuja y hay un film de agua alrededor?
Van a deslizarle alrededor de la burbuja, ese tiempo en donde se ustedes van a estar deslizándose alrededor de la burbuja se llama tiempo de colisión. 
"Las partículas se mueven alrededor de la burbuja hasta que el film se rompe"
"El tiempo que tarda en romperse se llama tiempo de colisión"
Si se mueven en un tiempo mayor al que tarda en romperse un film, si el film se rompe antes, ustedes se van a adherir a la burbuja, por acción de la fuerza centrífuga. 
### ¿Una partícula hidrofílica puede chocar contra una burbuja?
"Una partícula de cuarzo puede chocar con una burbuja, pero no va a haber adhesión"
"O capaz que haya adhesión, pero ese agregado partícula-burbuja no es termodinámicamente estable"
"Existe aún una probabilidad de que una partícula hidrofóbica se desadhiera"
### ¿Porqué una partícula se puede desadherir?
Depende del tamaño de partícula, de la hidrodinámica, de la densidad o diferencia entre densidades. Es proporcional a la razón entre el diámetro de la partícula y el diámetro de burbuja. 
"Las partículas gruesas tienen mayor probabilidad de desadherirse"
### ¿Qué pasa con la presión interna de la burbuja si disminuye el diámetro?
"La presión interna aumenta considerablemente"
Cuando tenemos partículas finas de 40 micrómetros, necesitamos burbujas de 400 micrómetros. 