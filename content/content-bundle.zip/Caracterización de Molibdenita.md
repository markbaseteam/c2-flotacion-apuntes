- Comportamiento anisotrópico a nivel superficial.
- Las burbujas no se adhieren a los bordes hidrofílicos. 
- Se generan muchos finos en la pulpa. 
- [[Problemas de la molibdenita]]
- Diesel recubre los microbordes de la molibdenita (colector no polar). [[Como emulsión]]. 
![[Pasted image 20221206113522.png]]
- [[Rol del espumante]]
- [[Qué te llama la atención de este circuito]]
[[Desarrollo de C2 de Flotación 2017]]