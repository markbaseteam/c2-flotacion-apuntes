- PLS 8 g / L de cobre, está impuro con hierro y un montón de cosas, necesitamos sacar el cobre y purificar la solución
- Concentración requerida para Electroobtención 40 45 g/L cobre
- El orgánico pesca solamente el cobre
- [[El PLS se transforma en refino]] para volver a lix
- Todos los procesos en contracorriente son más eficientes 
- Sale de SX a EW, con muy baja presencia de impurezas

[[Clase flotación 25 Nov - Flotación Columnar]]

- [[Clase-de-Hidro-20_06]] Se usa un reactivo orgánico con un diluyente tipo parafina
- Hay un intercambio de iones en la intefase de ambos líquidos
- El Cu que está en el [[El PLS se transforma en refino]]
- La reacción es de la forma: 2H+ + SO4 2- + CuR2 = Cu2+ +SO4 2- +2HR
- Hay una etapa de lavado del orgánico
	- Mezclar el orgánico con agua para poder atrapar gotitas de PLS o refino que quede en el orgánico
		- El refino tiene las impurezas, y se deben de lavar para evitar que se vayan al [[Qué se entiende por EW]]
	- Luego va a piscinas para que sedimenten, el orgánico baja
- 