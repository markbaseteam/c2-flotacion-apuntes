Va a ir pasando por entre las burbujas o poros a las part. de ganga por arrastre, y se van con las burbujas, subiendo la ley y estabilizando la espuma

### ¿Conviene gotitas finas o gruesas?
- SI es muy chiquitita, entonces no puede atravesar la espuma (BIAS)
- Si son muy gruesas, sin área suficiente, y desestabiliza la espuma, rompe burbujas, son goterones.
- Mayor flujo de agua para agregar BIAS, hay cantidad de agua que va a rebalsar, pero se puede inspeccionar fácilmente. 
- La mayoría de las veces lo que sale de las columnas es el concentrado final.
- ¿Qué significa que el % de sólidos sea mayor en el concentrado?
- ==Más agua que espesar y más agua que filtrar==
- Problemas por la capacidad, si se mandan más agua a los filtros, se reducen su capacidad.
- Impacto final en filtros, el queque sale + húmedo. ==La capacidad de filtro es constante==

Sistema interno
- No permite inspección visual
- Parámetros de diseño de columnas [[Clase flotación 25 Nov - Flotación Columnar]]

Capacidad de Levante: Carrying capacity
- Tiene que ver con el caudal de aire, tamaño de burbuja.  [[Capacidad de levante]]

[[Impacto de la humedad en el concentrado]]

[[Sistema de inyección de aire columnas]]