-Si hay cobre en la solución drenaje ácido, pirita se activa, molécula de FeS2 reacciona con el cobre y formamos un 
1. CuS con el hierro en solución Fe2+
2. El CuS se forma en superficie de la pirita, es prácticamente un sulfuro de cobre y eso flota mucho mejor que la pirita, se conoce como la PIRITA ACTIVADA. 
3. Los iones en solución vienen de iones de cobre de drenaje ácido de mina.
4. Los ingenieros hidráulicos que no saben de metalurgia.


[[Clase Flotación 29 Nov-Depresión de la pirita]]
