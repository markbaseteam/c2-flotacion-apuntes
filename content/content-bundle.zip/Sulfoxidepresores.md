- Hacen que el dixantógeno se reduzca?, sí, [[Activación de la pirita]]

[[Clase Flotación 29 Nov-Depresión de la pirita]]