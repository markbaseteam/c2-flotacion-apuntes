Es la fracción volumétrica de aire en la zona de colección de la celda de flotación
1. En celdas columnares no debe de existir un gradiente de concentración entre la fracción volumétrica.

$$\varepsilon_{g} $$
[[Clase flotación 25 Nov - Flotación Columnar]]
