La canaleta y el diseño es importante, para no rebalsar la canaleta.

[[Partes de una celda mecánica]]

[[Objetivos máquina flotación y diseño]]

[[Pérdida de carga]]

[[Modelos de celda]]
