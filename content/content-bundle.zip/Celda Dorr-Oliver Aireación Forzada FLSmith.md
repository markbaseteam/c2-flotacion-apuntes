Se parece mucho al modelo Wemco, privilegia la alta turbulencia en aireación forzada, similar al metso outuotec y altamente usado en la industria.

### ¿Si hay tanta turbulencia, afectará a la zona de espuma en la parte superior?
- Recordar que, en la etapa de limpieza se usan colchones de espuma profundos; en la etapa de limpieza se privilegia la ley.

[[Celdas neumáticas]]
