#### ¿Cómo se generan las burbujas?
1. Rompiendo mecánicamente el aire a través del uso de aspas o impulsores (celdas mecánicas, burbujas de 1-5 mm). Las burbujas son generadas por rompimiento en las aspas de un impulsor que rota en forma continua.
[[cizalle del agitador]]
2. Haciendo pasar aire a través de un material poroso, en presencia de aire. (Se usa en celdas columnares) [[Celdas columnares]]
3. Succión por la acción de un jet de líquido dirigido a alta velocidad sobre una superficie líquida. [[Efecto venturi]]
4. Nucleación de burbujas desde una solución, [[vacuum flotation]] [[dissolved aire flotation]] [[microflotation]]. [[tacho con agua oxígeno disuelto]]
5. Generar burbujas por electrólisis [[Reacción anódica electroobtención]]

[[Máquinas de Flotación]]

