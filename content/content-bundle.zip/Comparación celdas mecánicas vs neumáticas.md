Team celdas mecánicas.
- Mayores casos de éxito
- Altas recuperaciones
- Colchones de espuma pequeños
- Bajo costo en contexto de gran minería.
### ¿Cuánto cuesta una celda de 300 m3?
- De 5 a 6 millones de dólares [[PIM Proyecto de Ing Metalúrgica]]
- 100M SAG
- 40 línea de flotación
- Toda la planta de flotación unos 200 molinos de bolas 100M
- Solo la planta cuesta unos 1000 M de USD.
- Más las mantenciones periódicas, etc.
- Las partes internas se van manteniendo.
- El cascarón es el que perdura.

Team Celdas neumáticas: Desventajas
- Cuesta tener burbujas menores a 1 mm 
- Menor selectividad, ninguna tiene sistema de agua de lavado!!
- Mantención es difícil, hay que parar toda la línea si falla una.
- Neumáticas no trabajan en serie [[Celdas neumáticas]]
- Muy pocas _variables de operación_

Team celdas neumáticas:
- Permiten generar burbujas pequeñas, mejora probabilidad colisión adhesión
- Agua de lavado, concentrado de alta ley, pero baja recuperación, se usa en etapas de limpieza.
- Alta selectividad, en una etapa se puede llegar al concentrado final.
- No deja de operar si hay que mantener una.

Teams celdas neumáticas:
- Cambios en la minería muy lentos y conservadores, menores recuperaciones (no hay problema)
- Es de un 20 - 30 % más caro.
