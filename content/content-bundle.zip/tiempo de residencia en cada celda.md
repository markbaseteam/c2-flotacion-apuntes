### ¿Qué pasa si el rotor se rompe o destruye?
_La curva cinética va a disminuir, si falla el rotor más cercano al primero, la recuperación se pierde de inmediato._
No es menor el tema de las mantenciones.

[[Variables importantes de celdas mecánicas]]
