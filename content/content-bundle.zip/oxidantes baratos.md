- El aire todavía es gratis jsjsjs
no es el férrico xk es caro
- Sistemas de preaireación de la pulpa, entonces se inyecta aire a alta presión para oxidar preferencialmente a la pirita y los otros sulfuros tienden a oxidarse mucho menos que la pirita.
- Cl2(g), ejemplo para FeCl2 en piro, CuCl2, Fe(OH)2
[[Clase Flotación 29 Nov-Depresión de la pirita]]


#### Precipitación del As3+ a As5+
- Se puede oxidar con oxígeno, pero bajo la presencia de un catalizador
- El peróxido es efectivo a alto pH, mientras que a bajo pH es necesario aumentar la temperatura
- El O3 es efectivo en todo rango de pH y temperatura
- otros oxidantes son el Permanganato y el Cloro
- Mezcla SO2-O2 efectiva a pH 8. En medio ácido es más efectiva en presencia de hierro y T°