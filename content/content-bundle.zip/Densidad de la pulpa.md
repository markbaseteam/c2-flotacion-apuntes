$$\frac{\rho_{s}\rho_l}{\rho_{s}(1-X)+\rho_fX} $$
[[Sistema de inyección de aire columnas]]
