![[Pasted image 20221209223126.png]]
Están malos los datos supuestamente, la primera opción es ignorar esto y no considerar para los siguientes análisis

O bien considerarlo y explicar el error humano en las mediciones. 