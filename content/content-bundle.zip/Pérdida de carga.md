"Es cuando se pierde energía cinética y se disipa como calor y una fracción no se convierte en energía potencial"

[[Transporte de pulpa]]

"Bernoulli mucha energía cinética y baja potencial".

"Es más fácil que sedimente pero se embarca en canaleta de relaves"
[[Objetivos máquina flotación y diseño]]
"Genera rebalse"

[[Zonas del espesador]]

[[Celda Outotec_Aireación Forzada]]