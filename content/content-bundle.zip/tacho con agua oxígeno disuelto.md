- Se generan burbujas por nucleación muy pequeñitas.

[[Generación de burbujas en máquinas de flotación]]