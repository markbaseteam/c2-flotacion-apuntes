---
repeat: spaced every 36 hours
due_at: 2022-12-17T04:42:30.185-03:00
---
- Una o más celdas comparten el mismo nivel de altura, una por sí sola también es un banco. 
- ![[Pasted image 20221202135054.png]]
- La etapa Rougher posee un arreglo de 1-2-2-2. 
- Cada línea tiene celdas de 300 m3 Outotec, Metso, Wemco.
- Ventajas de usar bancos: 
1. Ahorro en obra civil en la construcción de la planta, menos escalones.
2. Ahorro en el costo de instrumentación para control de nivel. Un solo sistema de control para ambas.
3. En las celdas de limpieza es mejor usar una celda por banco, pero puede ser costoso. 


