![[Pasted image 20221208190618.png]]
- La recuperación en peso en la etapa Rougher debería ser la misma para cada elemento, tanto el cobre como el molibdeno.