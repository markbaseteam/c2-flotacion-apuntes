Profesor Jameson, 95 años, él inventó la celda hae 50 años.
- La pulpa se distribuye hacia los downcomers, que se distribuye hacia abajo.
- Dependiendo del número de downcomers, la cantidad de pulpa alimentada es mayor.
- La entrada de pulpa a alta velocidad genera un vacío que permite la entrada del aire sin requerir de un compresor. 
- En la minería del cobre recién está entrando
- Privilegia mucho la flotación de finos! burbujas de 300 micras.
- Es muy cara, son inestables ante alimentación, el sistema de control es complejo.

### ¿Qué pasa si f1 con 8% de cobre y aumentamos a f2 12% de cobre? ¿Recuperación?
- Por este lado sí, por este lado no... para responder el certamen.
- Si entran muchas partículas disminuye la recuperación, dado que no hay burbujas suficientes para levantar el concentrado. "Capacidad de levante" 
- Lo mismo para un bus..
- Si aumenta inyección de aire, se genera mayor turbulencia.
- Metalurgia del platino en Australia
[[Celdas columnares]]
