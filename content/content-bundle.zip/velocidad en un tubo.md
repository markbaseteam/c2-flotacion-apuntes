- Si conozco Q y el área de SC transversal, entonces es Q/Sc
[[Modelo Imhoflot-V Cell TIpo A]]