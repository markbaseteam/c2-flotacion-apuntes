- "Se da el aumento de la conductividad del agua producto de la interacción con la pirita" 
- #### ¿El agua interactúa con la pirita?
- Esta interacción de las especies con la pirita hace que se formen especies oxidadas
- Estas especies son iones Cu Pb Fe
- Estas especies oxidadas interactúan con colector 
- Si expecies oxidadas interactúan con el colector, entonces lo agotan. 

