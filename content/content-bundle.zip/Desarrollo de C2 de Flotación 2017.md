![[Pasted image 20221210191725.png]]
[[Clase Flotación 06 Dic]]
[[Clase Flotación 29 Nov-Depresión de la pirita]]

- La pirita es importante depresarla del punto de vista del uso de la cal, ya que esta eleva el pH y en condiciones de pH elevado se puede lograr la depresión, puesto que se puede utilizar tanto el NaOH como la cal para lograr esto, la cal se ocupa en mayor cantidad de 2 a 5 kg / t pero es más barata que la NaOH. La pirita es importante depresarla en las etapas de limpieza para poder subir la ley de concentrado de cobre, que es el principal producto minero. 
- La pirita como cualquier sulfuro metálico puede oxidarse en medio ácido o básico, si ocurre el primer caso, entonces se genera M1-nS el que es un compuesto que genera zonas hidrofóbicas, además de hacer que el catión M2+ se extienda hacia la superficie y quede en solución. En cambio, para el segundo caso de oxidación de pirita en medio básico, se debe formar un hidróxido del metal el que es un compuesto químicamente hidrofílico, por ende, hace que la pirita se deprese, el control para lo último es mediante la cal, que sube el pH y mediante los cationes Ca2+ que son veneno para la pirita. Esto último sube la ley de concentrado en las etapas cleaner (por eso se sube el pH) y hace que la pirita se vaya por las colas de la flot cleaner.



![[Pasted image 20221210192220.png]]
[[NaSH es un reductor]]
[[Caracterización de Molibdenita]]
[[Clase Flotación 06 Dic]]
a)
- A medida que se va separando la partícula de MoS2 se van generando nuevas partículas
- Esto es lo mismo que se generen más finos
- Entre mayor finos de Molibdenita, pierde hidrofobicidad. 
- La molibdenita es anisotrópica, lo que quiere decir que cambian sus propiedades superficiales.
- Se utiliza diesel para recubrir las caras con regiones hidrofílicas de la MoS2.

b) 
- Los mecanismos del NaSH son 2:
- Destruye el compuesto xantato metálico en la superficie de mineral sulfurado.
- Reduce el dixantógeno a xantato
- NaSH no afecta a la flotabilidad de molibdenita
- Hay que bajar el pH para depresar el cobre? NO
- Esto porque a pH ácido predomina la especie H2S la cual es altamente tóxica, 
- debe haber un pH entre 8 y 12.
- El kps bajo de CuS hace que este precipite y sea un compuesto estable. 
- Sin embargo, en presencia de iones S2- el CuX2 ya no es estable.
- Esto, por el pH mayor a 12
-  Como el kps de CuX2 es mayor (10e-20) que el kps de CuS (10e-30), se relaciona con la estabilidad
- La estabilidad de CuX2 es menor y se rompe formando CuS cuyo kps es más bajo



![[Pasted image 20221210192253.png]]
[[Pregunta 3 C2 flotación 2017]]
c) Esto significa que si hubo un aumeno de la conductividad del agua, este puede tener un impacto debido a la presencia de iones Cu Pb o Fe S en el agua, esto provoca que reaccionen estos iones con los colectores xantatos, provocando su rápido consumo y desgaste. Esto a su vez provoca la activación de la pirita producto de la interacción con el medio, a pesar de tener un caracter refractario, bajo estas condiciones puede ser que ocurra. Finalmente, la pirita estaría teniendo recubrimiento hidrofóbico haciendo que se active y pueda flotar por el concentrado, lo que baja la ley de mineral y a su vez sube la recuperación. 

### Describir el comportamiento fluidodinámico de las distintas zonas de la celda de flotación
Se basa en 4 zonas, las que son importantes para el proceso de flotación.
1. Zona de Espuma
- Se observa que sube el agregado partícula burbuja como concentrado.
- Por coalescencia pueden retornar a la pulpa.
- La coalescencia es cuando el tamaño de la burbuja aumenta. 
- Los finos pueden subir por arrastre mecánico, estos son hidrofílicos.
2. Zona tranquila
- Se produce una separación
- Esta separación es entre el agregado partícula burbuja. 
3. Zona de transición:
- Es cuando comienza la separación de los agregados de partícula brubuja
4. Zona de Mezcla
- Se producen las colisiones entre partíucla y burbuja
- Requiere de harta agitación para generar alta colisión
- Esta colisión es importante para las partículas finas. 


#### Cuál es la función del estator? rotor?
- la del rotor es de romper el aire producto de la fuerza de cizalle. 
- La del estator hacer que la pulpa esté continuamente moviéndose
- Generar zonas tranquilas
- Fondo falso hace que la pulpa no se quede estancda [[Máquinas de Flotación]]


#### Describir cómo la presencia de arcillas puede afectar al proceso de flotación






#### Métodos de inyección de aire en la flotación columnar?
- Son dos, la primera es la generación externa de bubujas y la otra es al interna
- La generación interna se inyecta el aire a través de varios orificios perforados
- Estos orificios pueden ser uno, varios o muchos.
- O en reemplazo de los orificios, puede ser inyección a través de un tubo de un material poroso.
- Si es externa, las burbujas son generadas fuera de la columna
- Se deben de inyectar en la columna en el caso de ser externas.
- Se inyecta agua y aire en el ingreso de aire externo. 
- Esta mezcla se inyecta a través de lanzas
- Generación externa del aire tiene la ventaja de que se puede inspeccionar
- En el interno, solamente aire. 


#### Efecto del espumante en la flotación columnar?
- Agregar espumante impacta en la fracción de aire
- Esta fracción de aire aumenta en la zona de colección debido a que se agregó espumante
- Esto funciona para un mismo flujo de aire.
- pero, si el flujo del aire cambia, este parámetro se relaciona directamente con el hold up
- aumenta si doy mayor aire y disminuye si le quito Jg.


#### Cómo puede afectar a la flotacion columnar un aumento del flujo de aire Jg?
- El aumento del flujo de aire Jg impacta en el flujo de agua 
- Si aumenta el flujo de aire, se reduce el flujo de agua
- esta agua pasa a través de la espuma, si se reduce, entonces disminuye el BIAS.
![[Pasted image 20221216124256.png]]


#### Qué relación hay en el aumento del flujo de aire Jg en la recuperación de la zona de limpieza o espuma? efecto del diámetro de la columna?
- El aumento de Jg mejora la recuperación en la zona de limpieza de espuma Rf
- Si mayor es el diámetro de columna dc, esto impacta en Rf
- A mayor diámetro de columna, baja la recuperación en zona de limpieza. 
- Si aumenta la altura de la zona de limpieza, baja la recuperación. 
![[Pasted image 20221216124118.png]]


#### Es bueno aumentar el flujo de aire Jg para la recuperación de cobre? Qué ocurre si es que operacionalmente se dan valores muy altos?
- El aumento del flujo de aire Jg es positivo para la recuperación de Cu global
- Esto es beneficioso hasta cierto límite
- A valores muy altos de Jg que es velocidad sueperficial de gas, aumenta la [[coalescencia de las burbujas]]
- Este aumento en la coalescencia provoca que la espuma se desestabilice
- La espuma desestabilizada impacta negativamente en recuperación global. 

![[Pasted image 20221216123747.png]]

#### 

[[Presencia de iones Ca2+ Pb2+ y Cu2+ en conductividad del agua]]

[[Presencia de las arcillas]]

[[Nota final de ramo de flotación-2022-2]]