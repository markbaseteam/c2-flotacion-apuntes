El aire se inyecta de forma controlada 

[[Celdas mecánicas]]
