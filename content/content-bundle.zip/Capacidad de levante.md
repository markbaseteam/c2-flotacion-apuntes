- Es la máx velocidad de transporte y descarga de concentrado por unidad de área seccional 
$$(t/h)/m^2 $$
- Cuánto concentrado podemos sacar de la celda, levantamos concentrado de la celda.
[[Sistema de adición de agua de lavado]]
