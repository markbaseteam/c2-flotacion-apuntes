- Afecta a toda la pulpa, incluyendo el agua, en cambio los colectores van solamente a las superficies de sulfuros de cobre.

[[Clase Flotación 29 Nov-Depresión de la pirita]]


### Ing ambiental // Neutralización con Cal
- Se neutraliza el ácido sulfúrico del drenaje ácido
- Ca(OH)2 como cuando se usa la cal para neutralizar el FeCl2
	- No como para oxidarlo nuevamente a FeCl3
	- H2SO4 + Ca(OH)2 = Ca2+ +SO4 2- + 2H2O
		- El calcio se va como Ca2+
		- sulfato como SO4 2- 
		- El (OH)2 como 2H2O del lado contrario, lado derecho
	- Si excede el producto de solubilidad del yeso, entonces se forma, en vez de disolverse
	- CaSO4 x 2H2O

#### Ing ambiental // Precipitación del As3+ y del As5+
- Tanto los dos se pueden precipitar con cal, son dos reacciones
- El primer compuesto, el arsenito, viene en H3AsO3
- Mientras que el segundo, el arseniato, viene en H3AsO4
- En los dos casos, el número de protones sigue siendo de 3