[[Circuito Planta Collahuasi]]
- La usan para regar, puede ser un tema no menor. Cuando la planta moly está cerca entonces se puede reusar el agua.