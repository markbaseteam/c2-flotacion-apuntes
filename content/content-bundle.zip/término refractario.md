- Que reacciona poco a las condiciones del medio.
- ejemplo: no reaccionan al calor, ladrillos refractarios.

[[Clase Flotación 29 Nov-Depresión de la pirita]]