1. Fácil alimentación de la pulpa y en forma contínua
- Se refiere porque a nivel industrial recibir 50 k o 100 k ton, la primera recibe una cantidad de 50 k ton al día. 
[[Problema de planta líneas flotación]]
2. Proveer eficiente transporte de pulpa alimentada, concentrado y cola.
3. Mantener las partículas minerales de la pulpa en suspensión (Zona de Mezcla).
4. Promover el proceso de colisión y adhesión partícula-burbuja (Zona de Mezcla.)
5. Separación adecuada de concentrado y relave.
6. No existan gradientes de hold up.
7. Mantener quietud en la zona bajo el colchón de espuma.
8. Mecanismo de control de altura de la pulpa y espuma, aereación de la pulpa y grado de agitación.
### ¿Porqué no se filtran los relaves?
Porque habría que tener un área muy grande.
### Ejemplo:
_Al diluirlo la velocidad de sedimentación es más alta_
### Cómo transportan los relaves
[[Transporte de pulpa]]
### Generación de burbujas en máquinas de flotación
[[Generación de burbujas en máquinas de flotación]]

