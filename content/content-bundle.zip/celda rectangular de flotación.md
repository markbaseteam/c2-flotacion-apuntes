Se genera acumulación de material y zonas muertas, el volumen útil disminuiría, y el tiempo de residencia baja; baja la recuperación.
_Puede incluso afectar al rotor_.

[[Variables importantes de celdas mecánicas]]

[[Cosas por hacer 24_11]]
