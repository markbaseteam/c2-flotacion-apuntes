- El hold up aumenta en las condiciones de haber bajado el flujo volumétrico dado que:
- "Se bajó o cortó la cantidad de agua, lo que subió el % de sólidos y al mismo tiempo elevó la viscosidad".
- Si se elevó la viscosidad entonces las burbujas se hacen más grandes (porque aumenta el hold up) y;
"Disminuye la estabilidad de la espuma"
"El tiempo de residencia baja y la recuperación baja." 

Al subir el aire, entran mas burbujas y por [[coalescencia se crean burbujas mas grandes]], las burbujas comienzan a chocar entre ellas y se obstaculiza, y les cuesta subir por la zona de espuma