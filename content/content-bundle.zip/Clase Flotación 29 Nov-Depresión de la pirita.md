---
repeat: spaced every 24 hours
due_at: 2022-12-16T17:04:08.256-03:00
---

- Todos los sulfuros metálicos dependiendo del PH y potencial, forman sulfuros metálicos no estequiométricos.
- a pH bajos se forman hidrofóbicos.
- a pH alcalino sulfuros tienden a hidrofilizarse.
- La pirita tiende oxidarse más fácil a nivel superficial. [[término refractario]]
- El último término aprovechamos en la industria para depresarla.
- El calcio es el veneno de la pirita.
- pH básico genera especies alta hidrofilicidad.

### ¿Porqué se hidrofobiza la Pirita? (Cómo se depresa). -
- El colector X- se oxida a dixantógeno producto de reducción del hidróxido de hierro, Fe3+ se reduce a ferroso y se oxida xantato a dixantógeno, entonces es la explicación de porqué la pirita se () con estos colectores.
- Hay que oxidar primero la pirita de forma que la reacción siguiente no ocurra
- Si no es semiconductora entonces no se transfieren los electrones por superficie y no ocurre la reacción. Cuál reacción???
- En flotación de minerales de cobre se flota por encima del pH 11 muy alcalino.
- La oxidación de los sulfuros metálicos viene por la reacción de especies superficiales con el medio
- El medio contiene agua y oxígeno.

[[La Cal]] No depresa la pirita activada

1. Control de Ph
2. con hidróxido pero es más caro, NaOH
3. Oxidación de la pulpa (Debo agregar un oxidante) [[oxidantes baratos]]
4. Con cianuro, es muy bueno para depresar pirita. NaCN pero temas ambientales no se usa.
5. Metabisulfito [[Minera centinela sulfuros AMSA]]
$$S_{2}O_{5}^{2-} $$
6. El azufre se puede usar como depresor de la pirita.
7. Por lejos la cal.
8. Los polisacáridos depresan la molibenita y no sirve.
9. Presencia de Ca2+ y Ca(OH)2.

- Especie reductora baja el potencial redox.
10. Depresantes orgánicos, aunque no se usan en la industria todavía.
[[Sulfoxidepresores]]

[[Problemas de la planta a depresar pirita]]

[[PIM Proyecto de Ing Metalúrgica]]

[[Diagrama Eh-PH de la Pirita]]

[[Clase de Flotación 02 Dic]]

[[Clase flotación 17 Nov]]

[[Pregunta e-Listado3-de-Flotación ]]

[[Dudas de flotación C2]]
