---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Condición de mínimo para la Función ^J8za8WoP

[[Condición de mínimo para la función]] ^Bn1Hf1tS

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"id": "IAWy8UYYtgMEhcVx0Shrq",
			"type": "freedraw",
			"x": -314.2365056818187,
			"y": -33.10038709463049,
			"width": 72.00000000000011,
			"height": 84.00000000000011,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1050995586,
			"version": 28,
			"versionNonce": 1142249666,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139038,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-8,
					8
				],
				[
					-12,
					20
				],
				[
					-12,
					40.000000000000114
				],
				[
					-8,
					56.000000000000114
				],
				[
					0,
					72.00000000000011
				],
				[
					12.000000000000057,
					76.00000000000011
				],
				[
					28.000000000000057,
					76.00000000000011
				],
				[
					40.000000000000114,
					68.00000000000011
				],
				[
					52.000000000000114,
					52.000000000000114
				],
				[
					60.000000000000114,
					36.000000000000114
				],
				[
					56.000000000000114,
					12
				],
				[
					44.000000000000114,
					0
				],
				[
					32.000000000000114,
					-8
				],
				[
					16.000000000000057,
					-8
				],
				[
					4,
					-4
				],
				[
					-4,
					4
				],
				[
					-4,
					8
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0185546875,
				0.1826171875,
				0.255859375,
				0.296875,
				0.3251953125,
				0.357421875,
				0.365234375,
				0.369140625,
				0.37890625,
				0.390625,
				0.41796875,
				0.4482421875,
				0.4609375,
				0.466796875,
				0.466796875,
				0.4111328125,
				0.263671875,
				0.16796875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-4,
				8
			]
		},
		{
			"id": "Ukcp2JPVJ0P_xbkfz1qOw",
			"type": "freedraw",
			"x": -270.2365056818186,
			"y": -81.10038709463049,
			"width": 52.000000000000114,
			"height": 172.00000000000023,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 697972766,
			"version": 18,
			"versionNonce": 890965086,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139038,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					12
				],
				[
					-12,
					40
				],
				[
					-24.000000000000057,
					76.00000000000011
				],
				[
					-36.00000000000006,
					116.00000000000011
				],
				[
					-48.000000000000114,
					148.0000000000001
				],
				[
					-52.000000000000114,
					164.00000000000023
				],
				[
					-52.000000000000114,
					168.00000000000023
				],
				[
					-52.000000000000114,
					172.00000000000023
				],
				[
					-52.000000000000114,
					172.00000000000023
				]
			],
			"pressures": [
				0.005859375,
				0.2119140625,
				0.3251953125,
				0.4140625,
				0.470703125,
				0.5048828125,
				0.4892578125,
				0.4169921875,
				0.337890625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-52.000000000000114,
				172.00000000000023
			]
		},
		{
			"id": "9knY1UBVxt6tDREr10g1h",
			"type": "freedraw",
			"x": -238.23650568181856,
			"y": -9.100387094630491,
			"width": 52.00000000000006,
			"height": 4,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 2057086850,
			"version": 17,
			"versionNonce": 120647810,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139038,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					12,
					0
				],
				[
					24.00000000000003,
					-4
				],
				[
					32.00000000000003,
					-4
				],
				[
					40.00000000000003,
					-4
				],
				[
					48.00000000000006,
					-4
				],
				[
					52.00000000000006,
					-4
				],
				[
					52.00000000000006,
					-4
				]
			],
			"pressures": [
				0.0146484375,
				0.3701171875,
				0.42578125,
				0.4541015625,
				0.4619140625,
				0.45703125,
				0.359375,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				52.00000000000006,
				-4
			]
		},
		{
			"id": "THd7hr5UNEk1ccPUxBxHF",
			"type": "freedraw",
			"x": -230.23650568181856,
			"y": 14.899612905369622,
			"width": 44.00000000000006,
			"height": 4,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 2071574082,
			"version": 17,
			"versionNonce": 1962266782,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139038,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					4
				],
				[
					12.000000000000028,
					4
				],
				[
					24.00000000000003,
					0
				],
				[
					32.00000000000003,
					0
				],
				[
					36.00000000000006,
					0
				],
				[
					44.00000000000006,
					0
				],
				[
					44.00000000000006,
					0
				]
			],
			"pressures": [
				0,
				0.240234375,
				0.296875,
				0.3525390625,
				0.3916015625,
				0.4033203125,
				0.3779296875,
				0.1474609375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				44.00000000000006,
				0
			]
		},
		{
			"id": "w1wZfnlToqFZd-WuLf5R5",
			"type": "freedraw",
			"x": -130.23650568181841,
			"y": -81.10038709463049,
			"width": 24.000000000000057,
			"height": 128.0000000000001,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1049988354,
			"version": 19,
			"versionNonce": 1518571586,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-12,
					16
				],
				[
					-16.000000000000057,
					40
				],
				[
					-20.000000000000057,
					64
				],
				[
					-20.000000000000057,
					88.00000000000011
				],
				[
					-12,
					108.00000000000011
				],
				[
					-8,
					120.00000000000011
				],
				[
					-4,
					124.00000000000011
				],
				[
					4,
					128.0000000000001
				],
				[
					4,
					128.0000000000001
				]
			],
			"pressures": [
				0,
				0.0625,
				0.1748046875,
				0.25390625,
				0.306640625,
				0.345703125,
				0.3642578125,
				0.3603515625,
				0.333984375,
				0.1416015625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				4,
				128.0000000000001
			]
		},
		{
			"id": "OlYWqtlKzx54gyeP94OMr",
			"type": "freedraw",
			"x": -118.23650568181841,
			"y": -45.10038709463049,
			"width": 80.00000000000011,
			"height": 24,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1906074498,
			"version": 17,
			"versionNonce": 762186974,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					20.000000000000057,
					-4
				],
				[
					40.00000000000006,
					-12
				],
				[
					64.00000000000011,
					-16
				],
				[
					76.00000000000011,
					-20
				],
				[
					80.00000000000011,
					-24
				],
				[
					80.00000000000011,
					-24
				]
			],
			"pressures": [
				0.009765625,
				0.228515625,
				0.2373046875,
				0.2822265625,
				0.31640625,
				0.3359375,
				0.30078125,
				0.208984375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				80.00000000000011,
				-24
			]
		},
		{
			"id": "-E3zWraR02hNifaPXj0_i",
			"type": "freedraw",
			"x": -94.23650568181836,
			"y": -53.10038709463049,
			"width": 4,
			"height": 84.00000000000011,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1864626754,
			"version": 17,
			"versionNonce": 837564418,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					20
				],
				[
					0,
					40
				],
				[
					4,
					60.000000000000114
				],
				[
					4,
					72.00000000000011
				],
				[
					4,
					80.00000000000011
				],
				[
					4,
					84.00000000000011
				],
				[
					4,
					84.00000000000011
				]
			],
			"pressures": [
				0,
				0.1142578125,
				0.2333984375,
				0.3037109375,
				0.333984375,
				0.3251953125,
				0.2744140625,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				4,
				84.00000000000011
			]
		},
		{
			"id": "vd9EkS71nS_tTln2URYh3",
			"type": "freedraw",
			"x": -106.23650568181841,
			"y": 2.8996129053696222,
			"width": 32.00000000000006,
			"height": 16.000000000000114,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1952073986,
			"version": 15,
			"versionNonce": 1544864030,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					16.000000000000057,
					-12.000000000000114
				],
				[
					24.000000000000057,
					-16.000000000000114
				],
				[
					32.00000000000006,
					-16.000000000000114
				],
				[
					32.00000000000006,
					-16.000000000000114
				]
			],
			"pressures": [
				0,
				0.0419921875,
				0.171875,
				0.23046875,
				0.2255859375,
				0.1025390625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				32.00000000000006,
				-16.000000000000114
			]
		},
		{
			"id": "kRvi2sMfB94lAMzoeK4ah",
			"type": "freedraw",
			"x": -46.2365056818183,
			"y": -17.10038709463049,
			"width": 8,
			"height": 52.000000000000114,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1620359170,
			"version": 17,
			"versionNonce": 761915330,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					16.000000000000114
				],
				[
					-4,
					28.000000000000114
				],
				[
					-4,
					36.000000000000114
				],
				[
					-8,
					44.000000000000114
				],
				[
					-8,
					48.000000000000114
				],
				[
					-8,
					52.000000000000114
				],
				[
					-8,
					52.000000000000114
				]
			],
			"pressures": [
				0.017578125,
				0.140625,
				0.29296875,
				0.3544921875,
				0.3720703125,
				0.3798828125,
				0.3564453125,
				0.1435546875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-8,
				52.000000000000114
			]
		},
		{
			"id": "35OpPwS4Orpo3zx0QTSUL",
			"type": "freedraw",
			"x": -6.236505681818244,
			"y": -5.100387094630378,
			"width": 16.000000000000057,
			"height": 44,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 567768770,
			"version": 16,
			"versionNonce": 609938782,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					8
				],
				[
					0,
					12
				],
				[
					-8,
					24
				],
				[
					-12.000000000000057,
					36
				],
				[
					-12.000000000000057,
					40
				],
				[
					-16.000000000000057,
					44
				],
				[
					-16.000000000000057,
					44
				]
			],
			"pressures": [
				0,
				0.248046875,
				0.2685546875,
				0.3486328125,
				0.373046875,
				0.3779296875,
				0.298828125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-16.000000000000057,
				44
			]
		},
		{
			"id": "ZDWUW-2i3I56U7yE5uwJI",
			"type": "freedraw",
			"x": 29.763494318181813,
			"y": -57.10038709463049,
			"width": 72.00000000000006,
			"height": 16,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1734389598,
			"version": 16,
			"versionNonce": 354131842,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					12,
					-4
				],
				[
					28,
					-8
				],
				[
					48.00000000000006,
					-12
				],
				[
					60.00000000000006,
					-16
				],
				[
					68.00000000000006,
					-16
				],
				[
					72.00000000000006,
					-16
				],
				[
					72.00000000000006,
					-16
				]
			],
			"pressures": [
				0.0029296875,
				0.2744140625,
				0.2998046875,
				0.3125,
				0.2978515625,
				0.208984375,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				72.00000000000006,
				-16
			]
		},
		{
			"id": "pq7eTR-AN5V6r-oYgDKPC",
			"type": "freedraw",
			"x": 49.76349431818181,
			"y": -69.10038709463049,
			"width": 4,
			"height": 96.00000000000011,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 768027778,
			"version": 16,
			"versionNonce": 328307102,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					-4,
					20
				],
				[
					-4,
					44
				],
				[
					-4,
					68.00000000000011
				],
				[
					-4,
					84.00000000000011
				],
				[
					0,
					96.00000000000011
				],
				[
					0,
					96.00000000000011
				]
			],
			"pressures": [
				0.03125,
				0.1201171875,
				0.271484375,
				0.349609375,
				0.3935546875,
				0.365234375,
				0.2705078125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				0,
				96.00000000000011
			]
		},
		{
			"id": "j_pWSpA0JcItExMzRgJQk",
			"type": "freedraw",
			"x": 25.763494318181756,
			"y": -1.1003870946303778,
			"width": 48.000000000000114,
			"height": 20.000000000000114,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 699078046,
			"version": 16,
			"versionNonce": 1430282050,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4.000000000000057,
					-4
				],
				[
					12.000000000000057,
					-8.000000000000114
				],
				[
					28.000000000000057,
					-12.000000000000114
				],
				[
					40.00000000000006,
					-16.000000000000114
				],
				[
					48.000000000000114,
					-20.000000000000114
				],
				[
					48.000000000000114,
					-20.000000000000114
				]
			],
			"pressures": [
				0.0087890625,
				0.1962890625,
				0.2294921875,
				0.2646484375,
				0.2734375,
				0.2236328125,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				48.000000000000114,
				-20.000000000000114
			]
		},
		{
			"id": "7E--Nz7Ne9QJO8wxphgXs",
			"type": "freedraw",
			"x": 89.76349431818187,
			"y": -1.1003870946303778,
			"width": 32,
			"height": 68.00000000000011,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 412117570,
			"version": 30,
			"versionNonce": 1693035998,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-8,
					4
				],
				[
					-8,
					0
				],
				[
					-4,
					-8.000000000000114
				],
				[
					4,
					-16.000000000000114
				],
				[
					12,
					-12.000000000000114
				],
				[
					16,
					-4
				],
				[
					20,
					8
				],
				[
					16,
					20
				],
				[
					8,
					32
				],
				[
					0,
					40
				],
				[
					-4,
					40
				],
				[
					-8,
					40
				],
				[
					-8,
					36
				],
				[
					-8,
					32
				],
				[
					-4,
					32
				],
				[
					8,
					40
				],
				[
					16,
					44
				],
				[
					20,
					48
				],
				[
					24,
					52
				],
				[
					24,
					52
				]
			],
			"pressures": [
				0.0263671875,
				0.107421875,
				0.2421875,
				0.33203125,
				0.333984375,
				0.3427734375,
				0.361328125,
				0.3818359375,
				0.400390625,
				0.41796875,
				0.4306640625,
				0.435546875,
				0.4345703125,
				0.423828125,
				0.416015625,
				0.4169921875,
				0.4296875,
				0.4365234375,
				0.4267578125,
				0.376953125,
				0.154296875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				24,
				52
			]
		},
		{
			"id": "A8IqFrkFkGlAVwFuzumuY",
			"type": "freedraw",
			"x": 149.76349431818198,
			"y": 18.899612905369622,
			"width": 20.000000000000114,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1560091038,
			"version": 17,
			"versionNonce": 2050434818,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					0
				],
				[
					-4,
					8
				],
				[
					-12,
					24
				],
				[
					-16,
					28
				],
				[
					-16,
					36
				],
				[
					-20.000000000000114,
					36
				],
				[
					-20.000000000000114,
					36
				]
			],
			"pressures": [
				0.0087890625,
				0.1171875,
				0.404296875,
				0.4580078125,
				0.4912109375,
				0.474609375,
				0.3349609375,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-20.000000000000114,
				36
			]
		},
		{
			"id": "kKj9eWwLglW7IwpQHcR4w",
			"type": "freedraw",
			"x": 201.76349431818198,
			"y": 14.899612905369622,
			"width": 4,
			"height": 0,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 306403038,
			"version": 12,
			"versionNonce": 1165247006,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0400390625,
				0.13671875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				4,
				0
			]
		},
		{
			"id": "7uSIdQCsfcZZ7aGPL4PpZ",
			"type": "freedraw",
			"x": 241.7634943181821,
			"y": 14.899612905369622,
			"width": 12,
			"height": 4,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 200963458,
			"version": 14,
			"versionNonce": 746518210,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					12,
					-4
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0009765625,
				0.1162109375,
				0.2587890625,
				0.1201171875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				12,
				-4
			]
		},
		{
			"id": "3jCmSQVk81N58tVSxro9h",
			"type": "freedraw",
			"x": 273.7634943181821,
			"y": 14.899612905369622,
			"width": 16,
			"height": 4,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1391990878,
			"version": 14,
			"versionNonce": 404901470,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139039,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					12,
					4
				],
				[
					16,
					0
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.025390625,
				0.154296875,
				0.318359375,
				0.12890625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				16,
				0
			]
		},
		{
			"id": "cEzGUUjt3xAQFfZEU2dU9",
			"type": "freedraw",
			"x": 197.76349431818198,
			"y": 10.899612905369622,
			"width": 8,
			"height": 16,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1629494210,
			"version": 17,
			"versionNonce": 750177922,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					0
				],
				[
					8,
					4
				],
				[
					8,
					8
				],
				[
					8,
					12
				],
				[
					4,
					8
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0029296875,
				0.18359375,
				0.2509765625,
				0.2939453125,
				0.357421875,
				0.3916015625,
				0.3828125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				4,
				8
			]
		},
		{
			"id": "oPQujUyiXnSLluOsNJTrW",
			"type": "freedraw",
			"x": 317.7634943181822,
			"y": -57.10038709463049,
			"width": 76.00000000000011,
			"height": 16,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1141670530,
			"version": 16,
			"versionNonce": 969200286,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					8,
					-4
				],
				[
					28,
					-8
				],
				[
					52,
					-12
				],
				[
					68,
					-16
				],
				[
					72.00000000000011,
					-16
				],
				[
					72.00000000000011,
					-16
				]
			],
			"pressures": [
				0.0107421875,
				0.111328125,
				0.365234375,
				0.3876953125,
				0.3857421875,
				0.3125,
				0.2470703125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				72.00000000000011,
				-16
			]
		},
		{
			"id": "SHJhAgN-4pSQrk2MzA4qL",
			"type": "freedraw",
			"x": 345.7634943181822,
			"y": -69.10038709463049,
			"width": 8,
			"height": 96.00000000000011,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1052319646,
			"version": 17,
			"versionNonce": 1335733826,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					-4,
					12
				],
				[
					-8,
					28
				],
				[
					-8,
					52
				],
				[
					-8,
					72.00000000000011
				],
				[
					-4,
					92.00000000000011
				],
				[
					-4,
					96.00000000000011
				],
				[
					-4,
					96.00000000000011
				]
			],
			"pressures": [
				0,
				0.095703125,
				0.18359375,
				0.3203125,
				0.3857421875,
				0.41015625,
				0.361328125,
				0.3203125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-4,
				96.00000000000011
			]
		},
		{
			"id": "89jPuRGmPR3poSblghCwp",
			"type": "freedraw",
			"x": 317.7634943181822,
			"y": 10.899612905369622,
			"width": 36,
			"height": 16,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 2143001822,
			"version": 15,
			"versionNonce": 1158467294,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					4,
					-8
				],
				[
					16,
					-8
				],
				[
					24,
					-12
				],
				[
					36,
					-16
				],
				[
					36,
					-16
				]
			],
			"pressures": [
				0.0234375,
				0.193359375,
				0.25,
				0.265625,
				0.259765625,
				0.169921875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				36,
				-16
			]
		},
		{
			"id": "cl6boVR_fQLzXySY7VB3p",
			"type": "freedraw",
			"x": 373.7634943181822,
			"y": -5.100387094630378,
			"width": 36.000000000000114,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 468663774,
			"version": 25,
			"versionNonce": 2048038402,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					0,
					36
				],
				[
					0,
					40
				],
				[
					0,
					32
				],
				[
					4,
					12
				],
				[
					8,
					8
				],
				[
					12,
					4
				],
				[
					16.000000000000114,
					4
				],
				[
					24.000000000000114,
					16
				],
				[
					28.000000000000114,
					24
				],
				[
					32.000000000000114,
					32
				],
				[
					36.000000000000114,
					36
				],
				[
					36.000000000000114,
					40
				],
				[
					36.000000000000114,
					40
				]
			],
			"pressures": [
				0.0244140625,
				0.1787109375,
				0.3271484375,
				0.3818359375,
				0.419921875,
				0.4638671875,
				0.4755859375,
				0.4658203125,
				0.4609375,
				0.45703125,
				0.45703125,
				0.4541015625,
				0.4521484375,
				0.4150390625,
				0.3046875,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				36.000000000000114,
				40
			]
		},
		{
			"id": "ZsBt2puOjis0tlW40LtEZ",
			"type": "freedraw",
			"x": 401.7634943181823,
			"y": 18.899612905369622,
			"width": 44,
			"height": 44,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1591563294,
			"version": 23,
			"versionNonce": 1451967262,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					4,
					-8
				],
				[
					8,
					-12
				],
				[
					12,
					-16
				],
				[
					16,
					-20
				],
				[
					20,
					-24
				],
				[
					28,
					-16
				],
				[
					32,
					-4
				],
				[
					36,
					4
				],
				[
					36,
					8
				],
				[
					40,
					12
				],
				[
					40,
					16
				],
				[
					44,
					20
				],
				[
					44,
					20
				]
			],
			"pressures": [
				0,
				0.275390625,
				0.2802734375,
				0.28515625,
				0.2880859375,
				0.291015625,
				0.3095703125,
				0.353515625,
				0.390625,
				0.41015625,
				0.416015625,
				0.421875,
				0.421875,
				0.279296875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				44,
				20
			]
		},
		{
			"id": "0HSbb6oahmQi29xBWPxWT",
			"type": "freedraw",
			"x": 491.4301609848487,
			"y": 14.566279572036137,
			"width": 15,
			"height": 30,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1766905374,
			"version": 16,
			"versionNonce": 487884226,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					-5,
					15
				],
				[
					-10,
					20
				],
				[
					-10,
					25
				],
				[
					-15,
					30
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.013671875,
				0.083984375,
				0.16796875,
				0.20703125,
				0.2177734375,
				0.1865234375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-15,
				30
			]
		},
		{
			"id": "b3JirCg7wEaPBaZEtFqYK",
			"type": "freedraw",
			"x": 511.4301609848487,
			"y": -50.43372042796386,
			"width": 40,
			"height": 70,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 323301826,
			"version": 19,
			"versionNonce": 1353789278,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					-5
				],
				[
					5,
					0
				],
				[
					10,
					5
				],
				[
					25,
					20
				],
				[
					30,
					35
				],
				[
					35,
					45
				],
				[
					40,
					55
				],
				[
					40,
					60
				],
				[
					40,
					65
				],
				[
					40,
					65
				]
			],
			"pressures": [
				0,
				0.15625,
				0.220703125,
				0.263671875,
				0.3232421875,
				0.353515625,
				0.3642578125,
				0.3701171875,
				0.349609375,
				0.298828125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				40,
				65
			]
		},
		{
			"id": "SOKMTlLqdou19ZU5cgcy-",
			"type": "freedraw",
			"x": 541.4301609848487,
			"y": -20.433720427963863,
			"width": 25,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 251230274,
			"version": 16,
			"versionNonce": 834829698,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					5
				],
				[
					-15,
					10
				],
				[
					-20,
					20
				],
				[
					-25,
					30
				],
				[
					-25,
					40
				],
				[
					-25,
					45
				],
				[
					-25,
					45
				]
			],
			"pressures": [
				0.0078125,
				0.1767578125,
				0.236328125,
				0.2626953125,
				0.2900390625,
				0.291015625,
				0.2578125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-25,
				45
			]
		},
		{
			"id": "Et2lHvPOJDaAIQHuTQU_8",
			"type": "freedraw",
			"x": 576.4301609848487,
			"y": -20.433720427963863,
			"width": 0,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1511671262,
			"version": 17,
			"versionNonce": 533697438,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					0,
					10
				],
				[
					0,
					20
				],
				[
					0,
					30
				],
				[
					0,
					35
				],
				[
					0,
					40
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.013671875,
				0.220703125,
				0.267578125,
				0.33984375,
				0.3447265625,
				0.33984375,
				0.123046875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				0,
				40
			]
		},
		{
			"id": "wXrSd_bzTlLMaxztY4GXQ",
			"type": "freedraw",
			"x": 626.4301609848487,
			"y": -15.433720427963863,
			"width": 15,
			"height": 50,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 39639838,
			"version": 15,
			"versionNonce": 895188290,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					10
				],
				[
					-10,
					25
				],
				[
					-10,
					40
				],
				[
					-15,
					40
				],
				[
					-15,
					50
				],
				[
					-15,
					50
				]
			],
			"pressures": [
				0.0205078125,
				0.2607421875,
				0.3212890625,
				0.3369140625,
				0.3291015625,
				0.2021484375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-15,
				50
			]
		},
		{
			"id": "U9gfEkR8PU3PgxHAjU77c",
			"type": "freedraw",
			"x": 641.4301609848487,
			"y": -70.43372042796386,
			"width": 60,
			"height": 80,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 31415326,
			"version": 19,
			"versionNonce": 2115465182,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					-10
				],
				[
					15,
					-10
				],
				[
					25,
					5
				],
				[
					30,
					20
				],
				[
					40,
					35
				],
				[
					50,
					50
				],
				[
					50,
					60
				],
				[
					55,
					65
				],
				[
					60,
					70
				],
				[
					60,
					70
				]
			],
			"pressures": [
				0.0029296875,
				0.181640625,
				0.265625,
				0.361328125,
				0.412109375,
				0.4453125,
				0.4794921875,
				0.4814453125,
				0.458984375,
				0.333984375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				60,
				70
			]
		},
		{
			"id": "Clumh3Fc6LLwlYQvnkk0x",
			"type": "freedraw",
			"x": 681.4301609848487,
			"y": -40.43372042796386,
			"width": 30,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 463416734,
			"version": 17,
			"versionNonce": 624854274,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					0
				],
				[
					-10,
					5
				],
				[
					-15,
					15
				],
				[
					-20,
					30
				],
				[
					-25,
					45
				],
				[
					-25,
					55
				],
				[
					-30,
					60
				],
				[
					-30,
					60
				]
			],
			"pressures": [
				0.029296875,
				0.1142578125,
				0.212890625,
				0.3212890625,
				0.39453125,
				0.4208984375,
				0.421875,
				0.3857421875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-30,
				60
			]
		},
		{
			"id": "V39LL3kkINEaZnjqxCkO2",
			"type": "freedraw",
			"x": 696.4301609848487,
			"y": -10.433720427963863,
			"width": 50,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 85519070,
			"version": 26,
			"versionNonce": 932824094,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					5,
					-10
				],
				[
					15,
					-20
				],
				[
					20,
					-20
				],
				[
					25,
					-15
				],
				[
					30,
					-5
				],
				[
					30,
					5
				],
				[
					20,
					25
				],
				[
					15,
					30
				],
				[
					10,
					30
				],
				[
					5,
					35
				],
				[
					5,
					30
				],
				[
					5,
					25
				],
				[
					20,
					25
				],
				[
					45,
					40
				],
				[
					50,
					40
				],
				[
					50,
					40
				]
			],
			"pressures": [
				0.0087890625,
				0.1015625,
				0.169921875,
				0.2353515625,
				0.251953125,
				0.294921875,
				0.34375,
				0.365234375,
				0.388671875,
				0.380859375,
				0.3798828125,
				0.3896484375,
				0.3876953125,
				0.3857421875,
				0.384765625,
				0.25,
				0.1259765625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				50,
				40
			]
		},
		{
			"id": "Jm42fI1fsG3zjqYQEo1m9",
			"type": "freedraw",
			"x": 556.4301609848487,
			"y": -75.43372042796386,
			"width": 5,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1587300290,
			"version": 16,
			"versionNonce": 2062193858,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					0,
					15
				],
				[
					5,
					25
				],
				[
					5,
					30
				],
				[
					5,
					35
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0,
				0.236328125,
				0.283203125,
				0.302734375,
				0.3076171875,
				0.23046875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				5,
				35
			]
		},
		{
			"id": "AMsUHRFHi9TCdWv_oxoak",
			"type": "freedraw",
			"x": 711.4301609848487,
			"y": -105.43372042796386,
			"width": 10,
			"height": 30,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1391849054,
			"version": 16,
			"versionNonce": 1850183774,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					5,
					10
				],
				[
					5,
					20
				],
				[
					5,
					25
				],
				[
					10,
					30
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0068359375,
				0.2685546875,
				0.330078125,
				0.359375,
				0.3662109375,
				0.3359375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				30
			]
		},
		{
			"id": "IbSYoHpEN-yiCZOXtQsKs",
			"type": "freedraw",
			"x": 786.4301609848487,
			"y": -20.433720427963863,
			"width": 10,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 961076610,
			"version": 16,
			"versionNonce": 671001730,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139040,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					-5,
					5
				],
				[
					-5,
					15
				],
				[
					-10,
					25
				],
				[
					-10,
					35
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0087890625,
				0.232421875,
				0.2861328125,
				0.3505859375,
				0.3779296875,
				0.3623046875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-10,
				35
			]
		},
		{
			"id": "UR5AtE-EXFZEgqnNcnNdq",
			"type": "freedraw",
			"x": 836.4301609848487,
			"y": -15.433720427963863,
			"width": 5,
			"height": 0,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 733050014,
			"version": 13,
			"versionNonce": 1576129694,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					0
				],
				[
					0,
					0
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.033203125,
				0.2734375,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				0.0001,
				0.0001
			]
		},
		{
			"id": "2G1Vs4vkV-GyxyaHpJEgA",
			"type": "freedraw",
			"x": 891.4301609848487,
			"y": -20.433720427963863,
			"width": 30,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1602818398,
			"version": 15,
			"versionNonce": 305777730,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					10,
					0
				],
				[
					15,
					0
				],
				[
					25,
					-5
				],
				[
					30,
					-5
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0390625,
				0.2158203125,
				0.2626953125,
				0.23828125,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				30,
				-5
			]
		},
		{
			"id": "NTtrTKrWzHavVJKaU5kzu",
			"type": "freedraw",
			"x": 931.4301609848487,
			"y": -15.433720427963863,
			"width": 10,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 152990302,
			"version": 13,
			"versionNonce": 541692126,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					0
				],
				[
					10,
					-5
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.02734375,
				0.337890625,
				0.3017578125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				-5
			]
		},
		{
			"id": "giNw4ib-JxgZ_sx66flco",
			"type": "freedraw",
			"x": 846.4301609848487,
			"y": -10.433720427963863,
			"width": 5,
			"height": 10,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1036642078,
			"version": 15,
			"versionNonce": 259716098,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					5,
					-5
				],
				[
					5,
					0
				],
				[
					5,
					5
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0,
				0.3310546875,
				0.3662109375,
				0.4501953125,
				0.248046875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				5,
				5
			]
		},
		{
			"id": "gZOS4T5DWPK98pr8hhiKs",
			"type": "freedraw",
			"x": 1001.4301609848487,
			"y": -35.43372042796386,
			"width": 20,
			"height": 30,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 140929054,
			"version": 16,
			"versionNonce": 1893713182,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					0
				],
				[
					-5,
					10
				],
				[
					-10,
					15
				],
				[
					-15,
					20
				],
				[
					-20,
					30
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0380859375,
				0.271484375,
				0.3427734375,
				0.373046875,
				0.37890625,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-20,
				30
			]
		},
		{
			"id": "XF-C5DpgbAwI00ja57Fq0",
			"type": "freedraw",
			"x": 1016.4301609848487,
			"y": -125.43372042796386,
			"width": 45,
			"height": 100,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1372766146,
			"version": 19,
			"versionNonce": 1640047554,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					5
				],
				[
					10,
					15
				],
				[
					20,
					35
				],
				[
					30,
					50
				],
				[
					35,
					70
				],
				[
					40,
					85
				],
				[
					45,
					90
				],
				[
					45,
					95
				],
				[
					45,
					100
				],
				[
					45,
					100
				]
			],
			"pressures": [
				0.005859375,
				0.1640625,
				0.234375,
				0.27734375,
				0.294921875,
				0.3173828125,
				0.3310546875,
				0.322265625,
				0.28515625,
				0.1240234375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				45,
				100
			]
		},
		{
			"id": "30Ae7_YqrhnsCkVFpvo0M",
			"type": "freedraw",
			"x": 1051.4301609848487,
			"y": -60.43372042796386,
			"width": 30,
			"height": 55,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 897877570,
			"version": 17,
			"versionNonce": 1898279262,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					-5
				],
				[
					-10,
					5
				],
				[
					-20,
					15
				],
				[
					-25,
					30
				],
				[
					-30,
					40
				],
				[
					-30,
					45
				],
				[
					-30,
					50
				],
				[
					-30,
					50
				]
			],
			"pressures": [
				0,
				0.1416015625,
				0.2998046875,
				0.3642578125,
				0.4091796875,
				0.419921875,
				0.3935546875,
				0.2958984375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-30,
				50
			]
		},
		{
			"id": "GBvG0FESc3UUhK7P6Z__9",
			"type": "freedraw",
			"x": 1096.4301609848487,
			"y": -40.43372042796386,
			"width": 35,
			"height": 55,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1279542274,
			"version": 27,
			"versionNonce": 1818989982,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					0,
					20
				],
				[
					0,
					35
				],
				[
					0,
					40
				],
				[
					0,
					45
				],
				[
					0,
					35
				],
				[
					0,
					25
				],
				[
					5,
					15
				],
				[
					10,
					10
				],
				[
					15,
					5
				],
				[
					20,
					10
				],
				[
					25,
					20
				],
				[
					25,
					25
				],
				[
					30,
					40
				],
				[
					35,
					40
				],
				[
					35,
					50
				],
				[
					35,
					50
				]
			],
			"pressures": [
				0.0068359375,
				0.1669921875,
				0.2861328125,
				0.3369140625,
				0.3837890625,
				0.4248046875,
				0.439453125,
				0.4638671875,
				0.478515625,
				0.474609375,
				0.466796875,
				0.4658203125,
				0.4658203125,
				0.47265625,
				0.4765625,
				0.484375,
				0.49609375,
				0.478515625,
				0.3603515625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				35,
				50
			]
		},
		{
			"id": "kXMYwcTPlGZafEPqOZZEM",
			"type": "freedraw",
			"x": 1121.4301609848487,
			"y": -135.43372042796386,
			"width": 25,
			"height": 155,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1790789534,
			"version": 19,
			"versionNonce": 301505346,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					5
				],
				[
					10,
					25
				],
				[
					20,
					50
				],
				[
					25,
					75
				],
				[
					25,
					100
				],
				[
					25,
					120
				],
				[
					25,
					130
				],
				[
					25,
					140
				],
				[
					25,
					150
				],
				[
					25,
					155
				],
				[
					25,
					155
				]
			],
			"pressures": [
				0.0068359375,
				0.279296875,
				0.337890625,
				0.3828125,
				0.4248046875,
				0.453125,
				0.4716796875,
				0.4677734375,
				0.4609375,
				0.3935546875,
				0.2763671875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				25,
				155
			]
		},
		{
			"id": "YdiOTOKHwb72d_Bjupr5n",
			"type": "freedraw",
			"x": 1206.4301609848487,
			"y": -45.43372042796386,
			"width": 45,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 144682946,
			"version": 15,
			"versionNonce": 467874270,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					10,
					-5
				],
				[
					20,
					-5
				],
				[
					30,
					-5
				],
				[
					35,
					-5
				],
				[
					40,
					-5
				],
				[
					45,
					-5
				],
				[
					45,
					-5
				]
			],
			"pressures": [
				0,
				0.328125,
				0.3623046875,
				0.3759765625,
				0.353515625,
				0.2939453125,
				0.1318359375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				45,
				-5
			]
		},
		{
			"id": "V-jb9GXtWt5FerXJpKbIz",
			"type": "freedraw",
			"x": 1201.4301609848487,
			"y": -25.433720427963863,
			"width": 50,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1123092062,
			"version": 17,
			"versionNonce": 1820844802,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					5
				],
				[
					0,
					5
				],
				[
					5,
					5
				],
				[
					15,
					5
				],
				[
					25,
					5
				],
				[
					35,
					5
				],
				[
					40,
					5
				],
				[
					45,
					5
				],
				[
					45,
					5
				]
			],
			"pressures": [
				0,
				0.2607421875,
				0.345703125,
				0.3935546875,
				0.4306640625,
				0.4404296875,
				0.4443359375,
				0.408203125,
				0.31640625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				45,
				5
			]
		},
		{
			"id": "sEjZpgdnmbbFKIxtHeTRW",
			"type": "freedraw",
			"x": 1409.4301609848487,
			"y": -131.4337204279641,
			"width": 144,
			"height": 152,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 225920322,
			"version": 44,
			"versionNonce": 1788691998,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					-4,
					4
				],
				[
					-12,
					8
				],
				[
					-28,
					20
				],
				[
					-44,
					36
				],
				[
					-60,
					48
				],
				[
					-72,
					60
				],
				[
					-76,
					64
				],
				[
					-80,
					68
				],
				[
					-80,
					72
				],
				[
					-64,
					72
				],
				[
					-48,
					72
				],
				[
					-28,
					68
				],
				[
					-4,
					64
				],
				[
					8,
					64
				],
				[
					16,
					60
				],
				[
					0,
					72
				],
				[
					-16,
					80
				],
				[
					-36,
					88
				],
				[
					-64,
					104
				],
				[
					-84,
					116
				],
				[
					-96,
					128
				],
				[
					-100,
					132
				],
				[
					-104,
					136
				],
				[
					-100,
					144
				],
				[
					-92,
					148
				],
				[
					-76,
					148
				],
				[
					-56,
					152
				],
				[
					-32,
					152
				],
				[
					0,
					152
				],
				[
					20,
					152
				],
				[
					32,
					152
				],
				[
					36,
					152
				],
				[
					40,
					152
				],
				[
					40,
					148
				],
				[
					40,
					148
				]
			],
			"pressures": [
				0.02734375,
				0.232421875,
				0.251953125,
				0.267578125,
				0.30078125,
				0.3359375,
				0.365234375,
				0.3876953125,
				0.4052734375,
				0.412109375,
				0.4189453125,
				0.4248046875,
				0.4267578125,
				0.4306640625,
				0.431640625,
				0.4326171875,
				0.4345703125,
				0.4111328125,
				0.39453125,
				0.3818359375,
				0.373046875,
				0.373046875,
				0.3818359375,
				0.384765625,
				0.3857421875,
				0.41796875,
				0.4501953125,
				0.482421875,
				0.5068359375,
				0.53125,
				0.5537109375,
				0.5595703125,
				0.546875,
				0.5009765625,
				0.40625,
				0.1875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				40,
				148
			]
		},
		{
			"id": "j44ETJ02in9eN9IJ8rYYi",
			"type": "freedraw",
			"x": 1345.4301609848487,
			"y": -191.4337204279641,
			"width": 64,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1989488770,
			"version": 33,
			"versionNonce": 223883970,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					0,
					28
				],
				[
					0,
					36
				],
				[
					4,
					40
				],
				[
					4,
					36
				],
				[
					8,
					24
				],
				[
					12,
					16
				],
				[
					16,
					12
				],
				[
					20,
					16
				],
				[
					24,
					20
				],
				[
					28,
					24
				],
				[
					28,
					32
				],
				[
					32,
					36
				],
				[
					32,
					28
				],
				[
					36,
					16
				],
				[
					40,
					12
				],
				[
					40,
					8
				],
				[
					44,
					8
				],
				[
					52,
					16
				],
				[
					56,
					20
				],
				[
					60,
					28
				],
				[
					60,
					32
				],
				[
					64,
					36
				],
				[
					64,
					36
				]
			],
			"pressures": [
				0.005859375,
				0.1220703125,
				0.208984375,
				0.2451171875,
				0.26953125,
				0.3232421875,
				0.3203125,
				0.31640625,
				0.3125,
				0.3173828125,
				0.3310546875,
				0.3369140625,
				0.3447265625,
				0.3525390625,
				0.365234375,
				0.3662109375,
				0.34375,
				0.3388671875,
				0.333984375,
				0.341796875,
				0.3701171875,
				0.390625,
				0.404296875,
				0.396484375,
				0.3125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				64,
				36
			]
		},
		{
			"id": "b8Xw5VkeiWGCY8Np2vkOr",
			"type": "freedraw",
			"x": 1325.4301609848487,
			"y": 100.56627957203591,
			"width": 4,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 712978398,
			"version": 15,
			"versionNonce": 965399134,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					8
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					4,
					36
				],
				[
					4,
					40
				],
				[
					4,
					40
				]
			],
			"pressures": [
				0.0087890625,
				0.2705078125,
				0.31640625,
				0.3798828125,
				0.3955078125,
				0.341796875,
				0.169921875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				4,
				40
			]
		},
		{
			"id": "aL_LaAAQ2pRSSwRmIqqAr",
			"type": "freedraw",
			"x": 1317.4301609848487,
			"y": 84.56627957203591,
			"width": 0,
			"height": 8,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1380922370,
			"version": 12,
			"versionNonce": 386435714,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0234375,
				0.1025390625,
				0.1728515625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				0,
				-8
			]
		},
		{
			"id": "ZrDy0rglQzB3_OVOqANgZ",
			"type": "freedraw",
			"x": 1349.4301609848487,
			"y": 100.56627957203591,
			"width": 32,
			"height": 4,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 2050284354,
			"version": 15,
			"versionNonce": 595383966,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139042,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					0
				],
				[
					16,
					-4
				],
				[
					24,
					-4
				],
				[
					28,
					-4
				],
				[
					32,
					-4
				],
				[
					32,
					-4
				]
			],
			"pressures": [
				0,
				0.3671875,
				0.4287109375,
				0.4521484375,
				0.4619140625,
				0.4248046875,
				0.359375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				32,
				-4
			]
		},
		{
			"id": "VHXiMFPGtVdsXrydBXVXx",
			"type": "freedraw",
			"x": 1353.4301609848487,
			"y": 124.56627957203591,
			"width": 36,
			"height": 8,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1206653662,
			"version": 16,
			"versionNonce": 5761602,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139042,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					8,
					4
				],
				[
					12,
					4
				],
				[
					20,
					0
				],
				[
					28,
					0
				],
				[
					32,
					0
				],
				[
					36,
					-4
				],
				[
					36,
					-4
				]
			],
			"pressures": [
				0,
				0.26171875,
				0.3515625,
				0.3701171875,
				0.3896484375,
				0.3798828125,
				0.2275390625,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				36,
				-4
			]
		},
		{
			"id": "iexibuhLwSxJl9uJcyOUw",
			"type": "freedraw",
			"x": 1413.4301609848487,
			"y": 76.56627957203591,
			"width": 4,
			"height": 56,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 846104606,
			"version": 15,
			"versionNonce": 1092899550,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139042,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					12
				],
				[
					4,
					32
				],
				[
					4,
					44
				],
				[
					4,
					48
				],
				[
					4,
					56
				],
				[
					4,
					56
				]
			],
			"pressures": [
				0.0029296875,
				0.359375,
				0.419921875,
				0.4794921875,
				0.4833984375,
				0.47265625,
				0.3994140625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				4,
				56
			]
		},
		{
			"id": "-VelqhKBE69ajpyEJlxFX",
			"type": "freedraw",
			"x": 1477.4301609848487,
			"y": -103.43372042796409,
			"width": 100,
			"height": 92,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 2146213826,
			"version": 34,
			"versionNonce": 270881282,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139042,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					4
				],
				[
					0,
					24
				],
				[
					4,
					40
				],
				[
					8,
					60
				],
				[
					16,
					76
				],
				[
					24,
					84
				],
				[
					28,
					84
				],
				[
					36,
					80
				],
				[
					44,
					68
				],
				[
					48,
					48
				],
				[
					48,
					20
				],
				[
					48,
					0
				],
				[
					48,
					-8
				],
				[
					52,
					4
				],
				[
					52,
					28
				],
				[
					60,
					52
				],
				[
					72,
					76
				],
				[
					76,
					80
				],
				[
					84,
					80
				],
				[
					92,
					72
				],
				[
					96,
					60
				],
				[
					96,
					40
				],
				[
					96,
					24
				],
				[
					92,
					16
				],
				[
					92,
					12
				],
				[
					92,
					12
				]
			],
			"pressures": [
				0.005859375,
				0.1865234375,
				0.2734375,
				0.32421875,
				0.3701171875,
				0.392578125,
				0.4072265625,
				0.4140625,
				0.419921875,
				0.4189453125,
				0.40234375,
				0.353515625,
				0.314453125,
				0.3134765625,
				0.3271484375,
				0.3359375,
				0.375,
				0.416015625,
				0.4228515625,
				0.458984375,
				0.470703125,
				0.4736328125,
				0.474609375,
				0.4658203125,
				0.4296875,
				0.3876953125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				92,
				12
			]
		},
		{
			"id": "HdqJEhKJ_LQ0tBD22QYKd",
			"type": "freedraw",
			"x": 1601.4301609848487,
			"y": -55.43372042796409,
			"width": 12,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1394246722,
			"version": 16,
			"versionNonce": 1829914398,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139042,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					16
				],
				[
					4,
					24
				],
				[
					8,
					28
				],
				[
					8,
					36
				],
				[
					12,
					40
				],
				[
					12,
					36
				],
				[
					12,
					36
				]
			],
			"pressures": [
				0.0341796875,
				0.3388671875,
				0.4541015625,
				0.4921875,
				0.5126953125,
				0.517578125,
				0.4287109375,
				0.166015625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				12,
				36
			]
		},
		{
			"id": "KhSTRVtHCN0nsSuwBfjMK",
			"type": "freedraw",
			"x": 1605.4301609848487,
			"y": -87.43372042796409,
			"width": 8,
			"height": 16,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1911921410,
			"version": 13,
			"versionNonce": 1500496322,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139042,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-8
				],
				[
					-8,
					-12
				],
				[
					-8,
					-16
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0,
				0.1416015625,
				0.275390625,
				0.3349609375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-8,
				-16
			]
		},
		{
			"id": "pzianXWi1qCPDLTTvKotg",
			"type": "freedraw",
			"x": 1657.4301609848487,
			"y": -147.4337204279641,
			"width": 44,
			"height": 160,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1366884546,
			"version": 20,
			"versionNonce": 928397698,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139043,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					0
				],
				[
					-12,
					4
				],
				[
					-20,
					20
				],
				[
					-24,
					40
				],
				[
					-28,
					76
				],
				[
					-24,
					104
				],
				[
					-16,
					128
				],
				[
					-8,
					144
				],
				[
					0,
					152
				],
				[
					12,
					156
				],
				[
					16,
					152
				],
				[
					16,
					152
				]
			],
			"pressures": [
				0.0224609375,
				0.1474609375,
				0.220703125,
				0.2998046875,
				0.376953125,
				0.4228515625,
				0.48046875,
				0.513671875,
				0.5322265625,
				0.5400390625,
				0.529296875,
				0.4052734375,
				0.1611328125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				16,
				152
			]
		},
		{
			"id": "VFPpf7NufVr2M_jf1kCw1",
			"type": "freedraw",
			"x": 1745.4301609848487,
			"y": -119.43372042796409,
			"width": 28,
			"height": 92,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1226291522,
			"version": 16,
			"versionNonce": 1321048478,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176139970,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					0,
					-8
				],
				[
					-4,
					-12
				],
				[
					-8,
					-12
				],
				[
					-16,
					-12
				],
				[
					-24,
					-4
				],
				[
					-28,
					12
				],
				[
					-28,
					28
				],
				[
					-24,
					44
				],
				[
					-24,
					56
				],
				[
					-20,
					68
				],
				[
					-16,
					76
				],
				[
					-16,
					80
				],
				[
					-16,
					80
				]
			],
			"pressures": [
				0,
				0.1630859375,
				0.2451171875,
				0.32421875,
				0.369140625,
				0.3994140625,
				0.390625,
				0.4111328125,
				0.4296875,
				0.44140625,
				0.4482421875,
				0.4541015625,
				0.423828125,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-16,
				80
			]
		},
		{
			"id": "iaCF_m7odScKHThZEO7rJ",
			"type": "freedraw",
			"x": 1697.4301609848487,
			"y": -67.43372042796409,
			"width": 48,
			"height": 8,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 951637826,
			"version": 10,
			"versionNonce": 1538512606,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176140184,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					-4
				],
				[
					12,
					-4
				],
				[
					24,
					-8
				],
				[
					32,
					-8
				],
				[
					40,
					-8
				],
				[
					44,
					-8
				],
				[
					48,
					-8
				],
				[
					48,
					-8
				]
			],
			"pressures": [
				0,
				0.19921875,
				0.263671875,
				0.306640625,
				0.3212890625,
				0.3125,
				0.287109375,
				0.193359375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				48,
				-8
			]
		},
		{
			"id": "NotaAborxFDTacnsB919v",
			"type": "freedraw",
			"x": 1761.4301609848487,
			"y": -79.43372042796409,
			"width": 12,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1262489090,
			"version": 9,
			"versionNonce": 401603842,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176140388,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					4,
					8
				],
				[
					8,
					20
				],
				[
					8,
					28
				],
				[
					12,
					36
				],
				[
					12,
					40
				],
				[
					12,
					40
				]
			],
			"pressures": [
				0,
				0.12109375,
				0.1845703125,
				0.318359375,
				0.35546875,
				0.35546875,
				0.328125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				12,
				40
			]
		},
		{
			"id": "jhJPhQ0Xj1_DmRFLckkjp",
			"type": "freedraw",
			"x": 1765.4301609848487,
			"y": -79.43372042796409,
			"width": 8,
			"height": 24,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 484166686,
			"version": 10,
			"versionNonce": 512203714,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176140576,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-16
				],
				[
					-4,
					-20
				],
				[
					0,
					-20
				],
				[
					0,
					-24
				],
				[
					4,
					-24
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0,
				0.0419921875,
				0.2119140625,
				0.2578125,
				0.275390625,
				0.287109375,
				0.21875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				4,
				-24
			]
		},
		{
			"id": "Nn0fIRAgvuQ8GZBMDvASB",
			"type": "freedraw",
			"x": 1805.4301609848487,
			"y": -71.43372042796409,
			"width": 48,
			"height": 8,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 606239070,
			"version": 10,
			"versionNonce": 818152066,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176141099,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					12,
					0
				],
				[
					24,
					-4
				],
				[
					32,
					-4
				],
				[
					40,
					-8
				],
				[
					44,
					-8
				],
				[
					48,
					-8
				],
				[
					48,
					-8
				]
			],
			"pressures": [
				0.0126953125,
				0.4169921875,
				0.4814453125,
				0.5087890625,
				0.5146484375,
				0.5068359375,
				0.466796875,
				0.3427734375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				48,
				-8
			]
		},
		{
			"id": "-bejkts1xIJDyUq20-2aZ",
			"type": "freedraw",
			"x": 1877.4301609848487,
			"y": -111.43372042796409,
			"width": 92,
			"height": 20,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 794091166,
			"version": 9,
			"versionNonce": 922328990,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176141598,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					12,
					-8
				],
				[
					28,
					-12
				],
				[
					52,
					-16
				],
				[
					72,
					-16
				],
				[
					88,
					-16
				],
				[
					92,
					-20
				],
				[
					92,
					-20
				]
			],
			"pressures": [
				0.0087890625,
				0.375,
				0.4208984375,
				0.4423828125,
				0.44921875,
				0.3994140625,
				0.3486328125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				92,
				-20
			]
		},
		{
			"id": "ZnYaFQcjHFOTh4dHLYRD9",
			"type": "freedraw",
			"x": 1889.4301609848487,
			"y": -123.43372042796409,
			"width": 8,
			"height": 96,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 111685954,
			"version": 11,
			"versionNonce": 1985423362,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176141859,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					0,
					16
				],
				[
					0,
					36
				],
				[
					4,
					52
				],
				[
					4,
					72
				],
				[
					8,
					88
				],
				[
					8,
					92
				],
				[
					8,
					96
				],
				[
					8,
					96
				]
			],
			"pressures": [
				0.0126953125,
				0.11328125,
				0.298828125,
				0.408203125,
				0.4521484375,
				0.486328125,
				0.45703125,
				0.4072265625,
				0.23046875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				8,
				96
			]
		},
		{
			"id": "slejhsXR2l0h7689vUgVP",
			"type": "freedraw",
			"x": 1869.4301609848487,
			"y": -51.43372042796409,
			"width": 88,
			"height": 40,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 470864158,
			"version": 15,
			"versionNonce": 742055646,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176142182,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					8,
					-12
				],
				[
					24,
					-16
				],
				[
					44,
					-20
				],
				[
					60,
					-24
				],
				[
					72,
					-24
				],
				[
					80,
					-24
				],
				[
					84,
					-16
				],
				[
					84,
					-4
				],
				[
					88,
					4
				],
				[
					88,
					12
				],
				[
					88,
					16
				],
				[
					88,
					16
				]
			],
			"pressures": [
				0,
				0.12109375,
				0.294921875,
				0.3447265625,
				0.365234375,
				0.3720703125,
				0.3603515625,
				0.3466796875,
				0.3720703125,
				0.419921875,
				0.4306640625,
				0.4111328125,
				0.2978515625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				88,
				16
			]
		},
		{
			"id": "QM4VuPJQztLMKyS9Wkmjl",
			"type": "freedraw",
			"x": 1945.4301609848487,
			"y": -79.43372042796409,
			"width": 8,
			"height": 24,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1888323074,
			"version": 9,
			"versionNonce": 1321301250,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176142363,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-8
				],
				[
					0,
					-12
				],
				[
					0,
					-20
				],
				[
					4,
					-20
				],
				[
					8,
					-24
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0,
				0.142578125,
				0.20703125,
				0.3125,
				0.31640625,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				8,
				-24
			]
		},
		{
			"id": "XaMSnbvilnsOWP-tggTf-",
			"type": "freedraw",
			"x": 1957.4301609848487,
			"y": -179.4337204279641,
			"width": 36,
			"height": 164,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 268293150,
			"version": 12,
			"versionNonce": 2042252162,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176142734,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					4
				],
				[
					16,
					28
				],
				[
					28,
					56
				],
				[
					36,
					84
				],
				[
					36,
					108
				],
				[
					36,
					128
				],
				[
					36,
					148
				],
				[
					32,
					160
				],
				[
					28,
					164
				],
				[
					28,
					164
				]
			],
			"pressures": [
				0,
				0.25390625,
				0.41796875,
				0.48828125,
				0.5302734375,
				0.544921875,
				0.541015625,
				0.474609375,
				0.32421875,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				28,
				164
			]
		},
		{
			"id": "1ppAB8VFYkHa57OmDd6va",
			"type": "freedraw",
			"x": 1988.4777800324682,
			"y": -199.51308550732927,
			"width": 44.44444444444434,
			"height": 42.222222222222285,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1317250462,
			"version": 26,
			"versionNonce": 457242690,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176150599,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-2.2222222222222854
				],
				[
					0,
					-4.444444444444457
				],
				[
					2.2222222222221717,
					-6.6666666666667425
				],
				[
					8.888888888888687,
					-11.1111111111112
				],
				[
					15.55555555555543,
					-15.555555555555657
				],
				[
					17.77777777777783,
					-15.555555555555657
				],
				[
					24.444444444444343,
					-13.333333333333371
				],
				[
					26.666666666666515,
					-6.6666666666667425
				],
				[
					24.444444444444343,
					2.2222222222221717
				],
				[
					17.77777777777783,
					8.8888888888888
				],
				[
					11.111111111111086,
					13.333333333333258
				],
				[
					6.666666666666515,
					15.555555555555543
				],
				[
					2.2222222222221717,
					15.555555555555543
				],
				[
					0,
					15.555555555555543
				],
				[
					-2.2222222222221717,
					15.555555555555543
				],
				[
					-2.2222222222221717,
					13.333333333333258
				],
				[
					2.2222222222221717,
					15.555555555555543
				],
				[
					11.111111111111086,
					15.555555555555543
				],
				[
					17.77777777777783,
					17.777777777777715
				],
				[
					26.666666666666515,
					20
				],
				[
					35.55555555555543,
					24.444444444444343
				],
				[
					40,
					26.66666666666663
				],
				[
					42.22222222222217,
					26.66666666666663
				],
				[
					42.22222222222217,
					26.66666666666663
				]
			],
			"pressures": [
				0.0087890625,
				0.28125,
				0.3408203125,
				0.3525390625,
				0.384765625,
				0.3984375,
				0.4091796875,
				0.4208984375,
				0.443359375,
				0.458984375,
				0.462890625,
				0.4619140625,
				0.4462890625,
				0.4326171875,
				0.431640625,
				0.42578125,
				0.4208984375,
				0.4521484375,
				0.4912109375,
				0.51953125,
				0.5556640625,
				0.56640625,
				0.509765625,
				0.2197265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				42.22222222222217,
				26.66666666666663
			]
		},
		{
			"id": "vA3EFJdgzUuzc1PrtCfey",
			"type": "freedraw",
			"x": 2087.1444466991347,
			"y": -125.2908632851072,
			"width": 10,
			"height": 70,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1872438494,
			"version": 10,
			"versionNonce": 261328642,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176156663,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					5
				],
				[
					5,
					20
				],
				[
					5,
					30
				],
				[
					5,
					45
				],
				[
					5,
					55
				],
				[
					10,
					65
				],
				[
					10,
					70
				],
				[
					10,
					70
				]
			],
			"pressures": [
				0,
				0.1103515625,
				0.2177734375,
				0.2578125,
				0.291015625,
				0.3037109375,
				0.3046875,
				0.2578125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				70
			]
		},
		{
			"id": "VKYBe117qzlHgb6M_XiUU",
			"type": "freedraw",
			"x": 2047.1444466991347,
			"y": -80.2908632851072,
			"width": 75,
			"height": 15,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 275929630,
			"version": 10,
			"versionNonce": 1135603138,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176157007,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					0
				],
				[
					25,
					-5
				],
				[
					45,
					-10
				],
				[
					55,
					-10
				],
				[
					65,
					-10
				],
				[
					75,
					-10
				],
				[
					75,
					-15
				],
				[
					75,
					-15
				]
			],
			"pressures": [
				0,
				0.3583984375,
				0.4541015625,
				0.4833984375,
				0.4892578125,
				0.4970703125,
				0.49609375,
				0.4404296875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				75,
				-15
			]
		},
		{
			"id": "156R2i4YPXkBY2KDo0IzD",
			"type": "freedraw",
			"x": 2242.1444466991347,
			"y": -155.2908632851072,
			"width": 105,
			"height": 160,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 31475550,
			"version": 32,
			"versionNonce": 674965954,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176158580,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					0
				],
				[
					0,
					5
				],
				[
					-20,
					20
				],
				[
					-40,
					35
				],
				[
					-55,
					45
				],
				[
					-70,
					60
				],
				[
					-80,
					65
				],
				[
					-80,
					70
				],
				[
					-75,
					75
				],
				[
					-55,
					75
				],
				[
					-35,
					70
				],
				[
					-15,
					70
				],
				[
					0,
					70
				],
				[
					10,
					70
				],
				[
					0,
					80
				],
				[
					-25,
					95
				],
				[
					-45,
					110
				],
				[
					-70,
					125
				],
				[
					-85,
					140
				],
				[
					-95,
					145
				],
				[
					-95,
					150
				],
				[
					-95,
					155
				],
				[
					-85,
					160
				],
				[
					-65,
					160
				],
				[
					-35,
					160
				],
				[
					-15,
					160
				],
				[
					-5,
					160
				],
				[
					5,
					160
				],
				[
					5,
					155
				],
				[
					5,
					155
				]
			],
			"pressures": [
				0,
				0.115234375,
				0.2763671875,
				0.3212890625,
				0.3466796875,
				0.357421875,
				0.36328125,
				0.357421875,
				0.357421875,
				0.3623046875,
				0.375,
				0.369140625,
				0.380859375,
				0.3857421875,
				0.390625,
				0.369140625,
				0.353515625,
				0.345703125,
				0.3447265625,
				0.357421875,
				0.3662109375,
				0.380859375,
				0.404296875,
				0.4560546875,
				0.50390625,
				0.53515625,
				0.546875,
				0.5322265625,
				0.46484375,
				0.3544921875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				5,
				155
			]
		},
		{
			"id": "e1QN77SUM_SqOz3bOx6gd",
			"type": "freedraw",
			"x": 2187.1444466991347,
			"y": -235.2908632851072,
			"width": 65,
			"height": 65,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1807141726,
			"version": 21,
			"versionNonce": 30789086,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176159887,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					5,
					15
				],
				[
					5,
					35
				],
				[
					5,
					40
				],
				[
					5,
					50
				],
				[
					5,
					55
				],
				[
					10,
					55
				],
				[
					10,
					45
				],
				[
					15,
					35
				],
				[
					20,
					20
				],
				[
					20,
					15
				],
				[
					30,
					10
				],
				[
					35,
					15
				],
				[
					45,
					35
				],
				[
					55,
					45
				],
				[
					55,
					50
				],
				[
					60,
					60
				],
				[
					65,
					65
				],
				[
					65,
					65
				]
			],
			"pressures": [
				0.0048828125,
				0.2109375,
				0.2626953125,
				0.3271484375,
				0.33984375,
				0.3505859375,
				0.361328125,
				0.392578125,
				0.4287109375,
				0.42578125,
				0.4248046875,
				0.4208984375,
				0.4169921875,
				0.4267578125,
				0.470703125,
				0.482421875,
				0.486328125,
				0.4853515625,
				0.3876953125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				65,
				65
			]
		},
		{
			"id": "1Wp4Z_ploZrYwNgwnllvC",
			"type": "freedraw",
			"x": 2142.1444466991347,
			"y": 64.7091367148928,
			"width": 35,
			"height": 85,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 161285890,
			"version": 14,
			"versionNonce": 1704965022,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176160809,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					5
				],
				[
					5,
					10
				],
				[
					5,
					25
				],
				[
					5,
					40
				],
				[
					0,
					55
				],
				[
					-5,
					70
				],
				[
					-10,
					75
				],
				[
					-15,
					80
				],
				[
					-20,
					85
				],
				[
					-25,
					80
				],
				[
					-30,
					70
				],
				[
					-30,
					70
				]
			],
			"pressures": [
				0,
				0.3583984375,
				0.443359375,
				0.5068359375,
				0.5771484375,
				0.619140625,
				0.6572265625,
				0.6669921875,
				0.6689453125,
				0.5791015625,
				0.4794921875,
				0.1689453125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-30,
				70
			]
		},
		{
			"id": "niJumBfpUTR51HpJOJdQ2",
			"type": "freedraw",
			"x": 2122.1444466991347,
			"y": 49.70913671489279,
			"width": 10,
			"height": 15,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 203251010,
			"version": 9,
			"versionNonce": 151759938,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176161059,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					5,
					-10
				],
				[
					5,
					-15
				],
				[
					5,
					-10
				],
				[
					10,
					-10
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0,
				0.166015625,
				0.3818359375,
				0.4521484375,
				0.3359375,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				-10
			]
		},
		{
			"id": "bG2r-HYEmJ0gWc5FGFQ3J",
			"type": "freedraw",
			"x": 2177.1444466991347,
			"y": 69.7091367148928,
			"width": 35,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 537243870,
			"version": 11,
			"versionNonce": 1891984926,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176161391,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					5,
					5
				],
				[
					10,
					5
				],
				[
					15,
					5
				],
				[
					25,
					5
				],
				[
					30,
					5
				],
				[
					35,
					5
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0078125,
				0.3212890625,
				0.4287109375,
				0.4541015625,
				0.470703125,
				0.4765625,
				0.4453125,
				0.3359375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				35,
				5
			]
		},
		{
			"id": "A1EZZOHxe9tskxX5jDuPu",
			"type": "freedraw",
			"x": 2182.1444466991347,
			"y": 94.7091367148928,
			"width": 35,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1967264450,
			"version": 10,
			"versionNonce": 281793374,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176161600,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					5
				],
				[
					0,
					5
				],
				[
					5,
					5
				],
				[
					10,
					5
				],
				[
					20,
					0
				],
				[
					30,
					0
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0244140625,
				0.1015625,
				0.3603515625,
				0.3779296875,
				0.388671875,
				0.384765625,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				30,
				0
			]
		},
		{
			"id": "nJb00uRijeSYcKvWJtouC",
			"type": "freedraw",
			"x": 2247.1444466991347,
			"y": 54.70913671489279,
			"width": 15,
			"height": 65,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 286529922,
			"version": 11,
			"versionNonce": 520742978,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176161879,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					5,
					0
				],
				[
					10,
					10
				],
				[
					10,
					25
				],
				[
					10,
					40
				],
				[
					15,
					50
				],
				[
					15,
					55
				],
				[
					15,
					60
				],
				[
					15,
					60
				]
			],
			"pressures": [
				0.021484375,
				0.072265625,
				0.27734375,
				0.4111328125,
				0.4560546875,
				0.48046875,
				0.4921875,
				0.470703125,
				0.40625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				15,
				60
			]
		},
		{
			"id": "nDTBxm5MAeBXP3ZCdXWV3",
			"type": "freedraw",
			"x": 2332.1444466991347,
			"y": -125.2908632851072,
			"width": 60,
			"height": 100,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 488191198,
			"version": 13,
			"versionNonce": 659519070,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176162807,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					10,
					0
				],
				[
					20,
					5
				],
				[
					30,
					20
				],
				[
					45,
					35
				],
				[
					50,
					55
				],
				[
					55,
					70
				],
				[
					60,
					80
				],
				[
					60,
					90
				],
				[
					60,
					95
				],
				[
					60,
					95
				]
			],
			"pressures": [
				0.0078125,
				0.2373046875,
				0.388671875,
				0.4501953125,
				0.509765625,
				0.5458984375,
				0.5634765625,
				0.5712890625,
				0.5673828125,
				0.5166015625,
				0.240234375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				60,
				95
			]
		},
		{
			"id": "4TYCF-EsHdkeZv0ZpS02H",
			"type": "freedraw",
			"x": 2367.1444466991347,
			"y": -80.2908632851072,
			"width": 35,
			"height": 65,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1347430018,
			"version": 11,
			"versionNonce": 907924802,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176163085,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					-10,
					-5
				],
				[
					-20,
					10
				],
				[
					-35,
					40
				],
				[
					-35,
					45
				],
				[
					-35,
					50
				],
				[
					-30,
					55
				],
				[
					-30,
					60
				],
				[
					-30,
					60
				]
			],
			"pressures": [
				0,
				0.1123046875,
				0.2900390625,
				0.4267578125,
				0.5009765625,
				0.50390625,
				0.4755859375,
				0.4228515625,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-30,
				60
			]
		},
		{
			"id": "GDReTr3K9wJzGCqBPEZ2W",
			"type": "freedraw",
			"x": 2437.1444466991347,
			"y": -65.2908632851072,
			"width": 40,
			"height": 75,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 591828958,
			"version": 15,
			"versionNonce": 1035451806,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176164479,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					5
				],
				[
					5,
					10
				],
				[
					10,
					20
				],
				[
					10,
					30
				],
				[
					10,
					45
				],
				[
					5,
					55
				],
				[
					0,
					65
				],
				[
					-5,
					70
				],
				[
					-10,
					75
				],
				[
					-15,
					75
				],
				[
					-25,
					75
				],
				[
					-30,
					65
				],
				[
					-30,
					65
				]
			],
			"pressures": [
				0.0029296875,
				0.201171875,
				0.3017578125,
				0.3583984375,
				0.4130859375,
				0.4638671875,
				0.4951171875,
				0.5302734375,
				0.5478515625,
				0.552734375,
				0.5078125,
				0.41015625,
				0.259765625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-30,
				65
			]
		},
		{
			"id": "M7s-YJO50Yzv52Y0Cd1V2",
			"type": "freedraw",
			"x": 2437.1444466991347,
			"y": -65.2908632851072,
			"width": 10,
			"height": 10,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1759703874,
			"version": 8,
			"versionNonce": 2037710494,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176164723,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					5,
					-5
				],
				[
					5,
					-10
				],
				[
					10,
					-10
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0234375,
				0.12109375,
				0.2392578125,
				0.474609375,
				0.5224609375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				-10
			]
		},
		{
			"id": "7rm6Qtz2LCzwWs1Zcfqa5",
			"type": "freedraw",
			"x": 2422.1444466991347,
			"y": -175.2908632851072,
			"width": 10,
			"height": 55,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1129726530,
			"version": 11,
			"versionNonce": 1327143170,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176165629,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					5,
					10
				],
				[
					5,
					20
				],
				[
					10,
					30
				],
				[
					10,
					40
				],
				[
					10,
					45
				],
				[
					10,
					50
				],
				[
					10,
					55
				],
				[
					10,
					55
				]
			],
			"pressures": [
				0,
				0.3115234375,
				0.4111328125,
				0.482421875,
				0.5244140625,
				0.544921875,
				0.55078125,
				0.513671875,
				0.3779296875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				55
			]
		},
		{
			"id": "kZ5F562o4hESXgGJo0sN1",
			"type": "freedraw",
			"x": 2577.1444466991347,
			"y": -185.2908632851072,
			"width": 95,
			"height": 160,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 943255582,
			"version": 31,
			"versionNonce": 998875102,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176166694,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					-10,
					15
				],
				[
					-20,
					25
				],
				[
					-35,
					40
				],
				[
					-65,
					70
				],
				[
					-70,
					75
				],
				[
					-75,
					75
				],
				[
					-80,
					80
				],
				[
					-80,
					85
				],
				[
					-75,
					85
				],
				[
					-60,
					85
				],
				[
					-40,
					85
				],
				[
					-15,
					85
				],
				[
					-10,
					85
				],
				[
					-20,
					95
				],
				[
					-40,
					110
				],
				[
					-60,
					120
				],
				[
					-75,
					130
				],
				[
					-85,
					140
				],
				[
					-85,
					145
				],
				[
					-85,
					150
				],
				[
					-75,
					155
				],
				[
					-55,
					160
				],
				[
					-30,
					160
				],
				[
					-15,
					160
				],
				[
					-5,
					160
				],
				[
					5,
					155
				],
				[
					10,
					155
				],
				[
					10,
					155
				]
			],
			"pressures": [
				0.015625,
				0.1884765625,
				0.26171875,
				0.291015625,
				0.3388671875,
				0.40234375,
				0.412109375,
				0.4140625,
				0.4208984375,
				0.4267578125,
				0.4296875,
				0.431640625,
				0.4306640625,
				0.4306640625,
				0.43359375,
				0.4345703125,
				0.435546875,
				0.4287109375,
				0.4267578125,
				0.4287109375,
				0.447265625,
				0.4619140625,
				0.47265625,
				0.4951171875,
				0.509765625,
				0.513671875,
				0.5078125,
				0.451171875,
				0.302734375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				155
			]
		},
		{
			"id": "HPWQaFIh6mhRF5yqTZnyt",
			"type": "freedraw",
			"x": 2502.1444466991347,
			"y": -230.2908632851072,
			"width": 85,
			"height": 50,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1397183746,
			"version": 30,
			"versionNonce": 956155806,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176167548,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					0
				],
				[
					5,
					5
				],
				[
					10,
					20
				],
				[
					10,
					35
				],
				[
					10,
					40
				],
				[
					10,
					45
				],
				[
					10,
					35
				],
				[
					10,
					20
				],
				[
					15,
					5
				],
				[
					25,
					0
				],
				[
					30,
					0
				],
				[
					40,
					10
				],
				[
					45,
					20
				],
				[
					45,
					25
				],
				[
					50,
					35
				],
				[
					50,
					40
				],
				[
					50,
					35
				],
				[
					55,
					25
				],
				[
					60,
					10
				],
				[
					65,
					0
				],
				[
					70,
					0
				],
				[
					75,
					10
				],
				[
					80,
					15
				],
				[
					80,
					30
				],
				[
					85,
					35
				],
				[
					85,
					45
				],
				[
					85,
					50
				],
				[
					85,
					50
				]
			],
			"pressures": [
				0.01171875,
				0.193359375,
				0.2265625,
				0.3017578125,
				0.34375,
				0.3798828125,
				0.4228515625,
				0.4541015625,
				0.4501953125,
				0.44921875,
				0.4521484375,
				0.4501953125,
				0.4462890625,
				0.458984375,
				0.466796875,
				0.4794921875,
				0.4912109375,
				0.5380859375,
				0.5244140625,
				0.5087890625,
				0.501953125,
				0.4990234375,
				0.4990234375,
				0.498046875,
				0.49609375,
				0.458984375,
				0.3505859375,
				0.275390625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				85,
				50
			]
		},
		{
			"id": "0yl7AZcKBC3BDRGoz8Wih",
			"type": "freedraw",
			"x": 2492.1444466991347,
			"y": 69.7091367148928,
			"width": 25,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 878348610,
			"version": 11,
			"versionNonce": 294813698,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176168459,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					5
				],
				[
					-5,
					10
				],
				[
					-10,
					25
				],
				[
					-5,
					35
				],
				[
					0,
					50
				],
				[
					0,
					55
				],
				[
					10,
					60
				],
				[
					15,
					60
				],
				[
					15,
					60
				]
			],
			"pressures": [
				0.0263671875,
				0.2744140625,
				0.390625,
				0.4658203125,
				0.501953125,
				0.525390625,
				0.533203125,
				0.5107421875,
				0.2666015625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				15,
				60
			]
		},
		{
			"id": "dip08D24irvP9-icCpYFI",
			"type": "freedraw",
			"x": 2477.1444466991347,
			"y": 49.70913671489279,
			"width": 5,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1725364510,
			"version": 6,
			"versionNonce": 405514050,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176168643,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					5,
					-5
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0439453125,
				0.2578125,
				0.2705078125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				5,
				-5
			]
		},
		{
			"id": "u01EwoTg2Fu1xaNB8ke0Z",
			"type": "freedraw",
			"x": 2527.1444466991347,
			"y": 89.7091367148928,
			"width": 30,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 255256030,
			"version": 8,
			"versionNonce": 1050998338,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176168921,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					0
				],
				[
					15,
					0
				],
				[
					25,
					-5
				],
				[
					30,
					-5
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.021484375,
				0.3916015625,
				0.4296875,
				0.3798828125,
				0.14453125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				30,
				-5
			]
		},
		{
			"id": "JAGhxV1_iT2s4gpSEkH62",
			"type": "freedraw",
			"x": 2527.1444466991347,
			"y": 104.7091367148928,
			"width": 35,
			"height": 5,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 587073246,
			"version": 9,
			"versionNonce": 497854430,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176169107,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					5,
					5
				],
				[
					15,
					5
				],
				[
					25,
					0
				],
				[
					35,
					0
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0166015625,
				0.1357421875,
				0.3515625,
				0.3720703125,
				0.3583984375,
				0.2421875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				35,
				0
			]
		},
		{
			"id": "4rrIcEm44222tbV0C6FcK",
			"type": "freedraw",
			"x": 2587.1444466991347,
			"y": 54.70913671489279,
			"width": 10,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1589169410,
			"version": 11,
			"versionNonce": 2110680002,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176169395,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					5,
					-5
				],
				[
					5,
					0
				],
				[
					5,
					20
				],
				[
					5,
					30
				],
				[
					10,
					40
				],
				[
					10,
					50
				],
				[
					10,
					55
				],
				[
					10,
					55
				]
			],
			"pressures": [
				0,
				0.0966796875,
				0.400390625,
				0.4423828125,
				0.4970703125,
				0.5166015625,
				0.51953125,
				0.4736328125,
				0.3857421875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				55
			]
		},
		{
			"id": "v6IaWhGXPGPrkR4mqwG2d",
			"type": "freedraw",
			"x": 2637.1444466991347,
			"y": -165.2908632851072,
			"width": 70,
			"height": 85,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1567664478,
			"version": 16,
			"versionNonce": 498403778,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176170474,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					15
				],
				[
					10,
					35
				],
				[
					10,
					55
				],
				[
					15,
					70
				],
				[
					15,
					80
				],
				[
					15,
					85
				],
				[
					20,
					85
				],
				[
					25,
					70
				],
				[
					35,
					50
				],
				[
					50,
					35
				],
				[
					60,
					20
				],
				[
					65,
					10
				],
				[
					70,
					5
				],
				[
					70,
					5
				]
			],
			"pressures": [
				0.03515625,
				0.349609375,
				0.4306640625,
				0.45703125,
				0.474609375,
				0.4921875,
				0.498046875,
				0.58984375,
				0.59375,
				0.591796875,
				0.55859375,
				0.494140625,
				0.361328125,
				0.14453125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				70,
				5
			]
		},
		{
			"id": "FcjtXlLIIcILMd0Um3A4o",
			"type": "freedraw",
			"x": 2687.1444466991347,
			"y": -135.2908632851072,
			"width": 35,
			"height": 60,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 189459294,
			"version": 12,
			"versionNonce": 1772572738,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176170675,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					10
				],
				[
					-5,
					20
				],
				[
					-5,
					25
				],
				[
					-5,
					40
				],
				[
					0,
					45
				],
				[
					5,
					55
				],
				[
					15,
					60
				],
				[
					25,
					60
				],
				[
					30,
					60
				],
				[
					30,
					60
				]
			],
			"pressures": [
				0,
				0.1357421875,
				0.2392578125,
				0.2998046875,
				0.3857421875,
				0.4267578125,
				0.44921875,
				0.46484375,
				0.4033203125,
				0.154296875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				30,
				60
			]
		},
		{
			"id": "nANsNaJVELgwA3WUFLlX7",
			"type": "freedraw",
			"x": 2737.1444466991347,
			"y": -120.2908632851072,
			"width": 40,
			"height": 85,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1667648734,
			"version": 14,
			"versionNonce": 496144002,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176171027,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					5
				],
				[
					5,
					10
				],
				[
					5,
					20
				],
				[
					10,
					35
				],
				[
					10,
					45
				],
				[
					5,
					60
				],
				[
					0,
					75
				],
				[
					-5,
					80
				],
				[
					-15,
					85
				],
				[
					-20,
					85
				],
				[
					-30,
					75
				],
				[
					-30,
					75
				]
			],
			"pressures": [
				0.021484375,
				0.27734375,
				0.3759765625,
				0.42578125,
				0.4775390625,
				0.4970703125,
				0.53125,
				0.5439453125,
				0.5419921875,
				0.486328125,
				0.44140625,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-30,
				75
			]
		},
		{
			"id": "9Y3KwB1o2jJGXmH0vUAq3",
			"type": "freedraw",
			"x": 2712.1444466991347,
			"y": -120.2908632851072,
			"width": 20,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 629478046,
			"version": 8,
			"versionNonce": 1992179074,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176171203,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					-5
				],
				[
					10,
					-15
				],
				[
					15,
					-20
				],
				[
					20,
					-25
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0537109375,
				0.1455078125,
				0.2900390625,
				0.3828125,
				0.3984375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				20,
				-25
			]
		},
		{
			"id": "W_UO7xo_MOd8FYF8R7I_S",
			"type": "freedraw",
			"x": 2777.1444466991347,
			"y": -120.2908632851072,
			"width": 10,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 158323614,
			"version": 10,
			"versionNonce": 31296578,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176171551,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					0
				],
				[
					5,
					5
				],
				[
					5,
					15
				],
				[
					5,
					25
				],
				[
					10,
					35
				],
				[
					10,
					40
				],
				[
					10,
					45
				],
				[
					10,
					45
				]
			],
			"pressures": [
				0.01171875,
				0.2841796875,
				0.3779296875,
				0.458984375,
				0.5,
				0.5146484375,
				0.5146484375,
				0.419921875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				10,
				45
			]
		},
		{
			"id": "KrLS5ZndbTylNub8fZtkn",
			"type": "freedraw",
			"x": 2782.1444466991347,
			"y": -135.2908632851072,
			"width": 5,
			"height": 20,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1036112094,
			"version": 9,
			"versionNonce": 456880606,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176171742,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-5
				],
				[
					0,
					-10
				],
				[
					-5,
					-15
				],
				[
					-5,
					-20
				],
				[
					0,
					-20
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0,
				0.0947265625,
				0.1708984375,
				0.3037109375,
				0.357421875,
				0.21484375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				0,
				-20
			]
		},
		{
			"id": "dH8zm5kS0bVDtd6O9Eiqp",
			"type": "freedraw",
			"x": 2822.1444466991347,
			"y": -165.2908632851072,
			"width": 100,
			"height": 10,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1574150914,
			"version": 9,
			"versionNonce": 496046594,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176172319,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					10,
					0
				],
				[
					30,
					-5
				],
				[
					50,
					-5
				],
				[
					75,
					-10
				],
				[
					95,
					-10
				],
				[
					100,
					-10
				],
				[
					100,
					-10
				]
			],
			"pressures": [
				0.0302734375,
				0.4462890625,
				0.48828125,
				0.5087890625,
				0.517578125,
				0.4345703125,
				0.3701171875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				100,
				-10
			]
		},
		{
			"id": "IX6egTKG5MpoHVMcuod83",
			"type": "freedraw",
			"x": 2857.1444466991347,
			"y": -170.2908632851072,
			"width": 10,
			"height": 95,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 222463774,
			"version": 11,
			"versionNonce": 905204830,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176172539,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-5,
					0
				],
				[
					-5,
					10
				],
				[
					-10,
					25
				],
				[
					-10,
					50
				],
				[
					-10,
					65
				],
				[
					-5,
					80
				],
				[
					-5,
					90
				],
				[
					-5,
					95
				],
				[
					-5,
					95
				]
			],
			"pressures": [
				0,
				0.060546875,
				0.216796875,
				0.37109375,
				0.484375,
				0.51953125,
				0.5263671875,
				0.4873046875,
				0.421875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-5,
				95
			]
		},
		{
			"id": "IIRRfGYCBRlV_RUpVUk-N",
			"type": "freedraw",
			"x": 2827.1444466991347,
			"y": -105.2908632851072,
			"width": 80,
			"height": 10,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 292563074,
			"version": 11,
			"versionNonce": 2029819714,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176172759,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					5,
					0
				],
				[
					15,
					-5
				],
				[
					30,
					-10
				],
				[
					45,
					-10
				],
				[
					60,
					-10
				],
				[
					70,
					-10
				],
				[
					75,
					-10
				],
				[
					80,
					-10
				],
				[
					80,
					-10
				]
			],
			"pressures": [
				0,
				0.1728515625,
				0.2978515625,
				0.3828125,
				0.41015625,
				0.4267578125,
				0.34765625,
				0.2734375,
				0.11328125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				80,
				-10
			]
		},
		{
			"id": "nWMOsJr1HvfKZ4vK1yQrS",
			"type": "freedraw",
			"x": 2912.1444466991347,
			"y": -115.2908632851072,
			"width": 0,
			"height": 50,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 338490846,
			"version": 9,
			"versionNonce": 879498974,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176172923,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					0,
					10
				],
				[
					0,
					25
				],
				[
					0,
					30
				],
				[
					0,
					40
				],
				[
					0,
					50
				],
				[
					0,
					50
				]
			],
			"pressures": [
				0.015625,
				0.2216796875,
				0.3203125,
				0.4208984375,
				0.4345703125,
				0.419921875,
				0.2529296875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				0,
				50
			]
		},
		{
			"id": "BCR3TqgJMIJ2D68opqwJ0",
			"type": "freedraw",
			"x": 2917.1444466991347,
			"y": -110.2908632851072,
			"width": 5,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 690736642,
			"version": 9,
			"versionNonce": 1107016962,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176173095,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-10
				],
				[
					0,
					-15
				],
				[
					-5,
					-20
				],
				[
					0,
					-25
				],
				[
					0,
					-20
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0068359375,
				0.1640625,
				0.244140625,
				0.34375,
				0.40625,
				0.17578125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				0,
				-20
			]
		},
		{
			"id": "Bn1Hf1tS",
			"type": "diamond",
			"x": 288.81111336580193,
			"y": 158.32024782600365,
			"width": 829,
			"height": 345,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1411879710,
			"version": 165,
			"versionNonce": 572822146,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "J8za8WoP"
				}
			],
			"updated": 1671176287470,
			"link": "[[Condición de mínimo para la función]]",
			"locked": false
		},
		{
			"id": "J8za8WoP",
			"type": "text",
			"x": 393.31111336580193,
			"y": 308.32024782600365,
			"width": 620,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 2058194782,
			"version": 126,
			"versionNonce": 223689410,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1671176274834,
			"link": null,
			"locked": false,
			"text": "Condición de mínimo para la Función",
			"rawText": "Condición de mínimo para la Función",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 32,
			"containerId": "Bn1Hf1tS",
			"originalText": "Condición de mínimo para la Función"
		},
		{
			"id": "uNp-qEXFqYr9VulvkY18O",
			"type": "freedraw",
			"x": -158.0546875,
			"y": -95.953125,
			"width": 19,
			"height": 20,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1058984258,
			"version": 29,
			"versionNonce": 1299302658,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176139038,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2,
					2
				],
				[
					-3,
					5
				],
				[
					-3,
					8
				],
				[
					-2,
					12
				],
				[
					0,
					16
				],
				[
					3,
					19
				],
				[
					6,
					20
				],
				[
					9,
					19
				],
				[
					12,
					18
				],
				[
					14,
					15
				],
				[
					15,
					11
				],
				[
					14,
					7
				],
				[
					11,
					3
				],
				[
					8,
					0
				],
				[
					4,
					0
				],
				[
					0,
					2
				],
				[
					-3,
					5
				],
				[
					-4,
					8
				],
				[
					-4,
					8
				]
			],
			"pressures": [
				0.0263671875,
				0.3349609375,
				0.4033203125,
				0.4375,
				0.462890625,
				0.466796875,
				0.470703125,
				0.47265625,
				0.4736328125,
				0.4736328125,
				0.4794921875,
				0.4912109375,
				0.4814453125,
				0.4755859375,
				0.4619140625,
				0.45703125,
				0.42578125,
				0.3349609375,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-4,
				8
			]
		},
		{
			"id": "eSbKN6WnnWukVQSRPDyav",
			"type": "freedraw",
			"x": -260.0546875000002,
			"y": -118.19129618553967,
			"width": 29.090909090909122,
			"height": 41.81818181818187,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 20,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1141399170,
			"version": 31,
			"versionNonce": 1378664478,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176139038,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.8181818181818699,
					0
				],
				[
					-3.636363636363626,
					3.636363636363626
				],
				[
					-5.454545454545496,
					9.090909090909122
				],
				[
					-7.272727272727309,
					18.181818181818187
				],
				[
					-5.454545454545496,
					25.454545454545496
				],
				[
					-3.636363636363626,
					32.72727272727275
				],
				[
					3.636363636363626,
					36.36363636363643
				],
				[
					7.272727272727252,
					36.36363636363643
				],
				[
					14.545454545454533,
					34.54545454545456
				],
				[
					18.181818181818187,
					27.27272727272731
				],
				[
					21.818181818181813,
					20.000000000000057
				],
				[
					20,
					9.090909090909122
				],
				[
					14.545454545454533,
					-1.818181818181813
				],
				[
					7.272727272727252,
					-5.454545454545439
				],
				[
					1.818181818181813,
					-5.454545454545439
				],
				[
					-3.636363636363626,
					-1.818181818181813
				],
				[
					-7.272727272727309,
					3.636363636363626
				],
				[
					-7.272727272727309,
					7.272727272727309
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.0419921875,
				0.0927734375,
				0.1826171875,
				0.2919921875,
				0.337890625,
				0.3740234375,
				0.396484375,
				0.4091796875,
				0.4130859375,
				0.4306640625,
				0.4560546875,
				0.4658203125,
				0.462890625,
				0.470703125,
				0.474609375,
				0.4697265625,
				0.4150390625,
				0.3115234375,
				0.0322265625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-7.272727272727309,
				7.272727272727309
			]
		},
		{
			"id": "PG2NazpyCu9Y6Rf4xFwqU",
			"type": "freedraw",
			"x": 1086.4301609848487,
			"y": -65.43372042796386,
			"width": 70,
			"height": 55,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1205755138,
			"version": 34,
			"versionNonce": 858479490,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176139041,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					5
				],
				[
					0,
					10
				],
				[
					0,
					25
				],
				[
					0,
					35
				],
				[
					0,
					40
				],
				[
					0,
					45
				],
				[
					-5,
					40
				],
				[
					0,
					30
				],
				[
					0,
					25
				],
				[
					5,
					20
				],
				[
					15,
					20
				],
				[
					20,
					30
				],
				[
					25,
					35
				],
				[
					25,
					45
				],
				[
					30,
					50
				],
				[
					30,
					45
				],
				[
					30,
					40
				],
				[
					30,
					30
				],
				[
					35,
					20
				],
				[
					45,
					25
				],
				[
					50,
					35
				],
				[
					55,
					45
				],
				[
					60,
					55
				],
				[
					65,
					55
				],
				[
					65,
					55
				]
			],
			"pressures": [
				0.0263671875,
				0.154296875,
				0.2236328125,
				0.2744140625,
				0.3095703125,
				0.341796875,
				0.3642578125,
				0.38671875,
				0.3779296875,
				0.3740234375,
				0.37109375,
				0.3701171875,
				0.3779296875,
				0.396484375,
				0.423828125,
				0.4326171875,
				0.453125,
				0.4453125,
				0.439453125,
				0.4326171875,
				0.4326171875,
				0.4453125,
				0.4208984375,
				0.30859375,
				0.14453125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				65,
				55
			]
		},
		{
			"id": "1hT2Q5quyy0uHWbPcPLhe",
			"type": "freedraw",
			"x": 1689.4301609848487,
			"y": -143.4337204279641,
			"width": 36,
			"height": 120,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1552095966,
			"version": 21,
			"versionNonce": 129479518,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176139043,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-4
				],
				[
					-8,
					-4
				],
				[
					-16,
					-4
				],
				[
					-28,
					8
				],
				[
					-36,
					28
				],
				[
					-36,
					44
				],
				[
					-36,
					72
				],
				[
					-32,
					88
				],
				[
					-24,
					104
				],
				[
					-20,
					108
				],
				[
					-16,
					112
				],
				[
					-16,
					116
				],
				[
					-16,
					116
				]
			],
			"pressures": [
				0.0146484375,
				0.1025390625,
				0.267578125,
				0.349609375,
				0.412109375,
				0.453125,
				0.4716796875,
				0.4912109375,
				0.5,
				0.5029296875,
				0.47265625,
				0.353515625,
				0.158203125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-16,
				116
			]
		},
		{
			"id": "YYTZxjKkU3jAVAD4OyayL",
			"type": "freedraw",
			"x": 1733.4301609848487,
			"y": -115.43372042796409,
			"width": 40,
			"height": 104,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 144841246,
			"version": 16,
			"versionNonce": 996513694,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176139043,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-40,
					20
				],
				[
					-40,
					28
				],
				[
					-40,
					32
				],
				[
					-40,
					72
				],
				[
					-40,
					84
				],
				[
					-36,
					92
				],
				[
					-36,
					100
				],
				[
					-36,
					104
				],
				[
					-36,
					104
				]
			],
			"pressures": [
				0.01953125,
				0.33203125,
				0.34765625,
				0.349609375,
				0.4130859375,
				0.423828125,
				0.4208984375,
				0.3720703125,
				0.298828125,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-36,
				104
			]
		},
		{
			"id": "-_1yXdvBIpKeg5iIro3DA",
			"type": "freedraw",
			"x": 1669.4301609848487,
			"y": -39.43372042796409,
			"width": 52,
			"height": 12,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1622484354,
			"version": 13,
			"versionNonce": 1314515934,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176138663,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4,
					0
				],
				[
					8,
					-4
				],
				[
					24,
					-8
				],
				[
					32,
					-8
				],
				[
					44,
					-8
				],
				[
					52,
					-12
				],
				[
					52,
					-12
				]
			],
			"pressures": [
				0,
				0.1044921875,
				0.2109375,
				0.3095703125,
				0.322265625,
				0.3330078125,
				0.201171875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				52,
				-12
			]
		},
		{
			"id": "ksAdwtMHcOHFRYQTFfOw7",
			"type": "freedraw",
			"x": 1733.4301609848487,
			"y": -55.43372042796409,
			"width": 4,
			"height": 28,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1781640350,
			"version": 11,
			"versionNonce": 821055746,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176138349,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					4
				],
				[
					4,
					12
				],
				[
					4,
					20
				],
				[
					4,
					28
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0,
				0.203125,
				0.2705078125,
				0.3125,
				0.2734375,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				4,
				28
			]
		},
		{
			"id": "2wyAUQkU6MhMJMWALNNq7",
			"type": "freedraw",
			"x": 1733.4301609848487,
			"y": -63.43372042796409,
			"width": 4,
			"height": 12,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1308585374,
			"version": 9,
			"versionNonce": 412014850,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176138037,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					-4
				],
				[
					-4,
					-8
				],
				[
					-4,
					-12
				],
				[
					0,
					0
				]
			],
			"pressures": [
				0.017578125,
				0.0947265625,
				0.19140625,
				0.201171875,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				-4,
				-12
			]
		},
		{
			"id": "ZkQLycvLwxuo8J1KZ8ZOP",
			"type": "freedraw",
			"x": 1769.4301609848487,
			"y": -55.43372042796409,
			"width": 40,
			"height": 8,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1010774658,
			"version": 11,
			"versionNonce": 868275166,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176137738,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4,
					0
				],
				[
					0,
					0
				],
				[
					8,
					0
				],
				[
					20,
					-4
				],
				[
					28,
					-4
				],
				[
					32,
					-8
				],
				[
					36,
					-8
				],
				[
					36,
					-8
				]
			],
			"pressures": [
				0,
				0.1572265625,
				0.423828125,
				0.4521484375,
				0.46484375,
				0.453125,
				0.4189453125,
				0.166015625,
				0
			],
			"simulatePressure": false,
			"lastCommittedPoint": [
				36,
				-8
			]
		},
		{
			"id": "t1q-7ip-C-IqCy8jaPp9d",
			"type": "diamond",
			"x": 175.47778003246896,
			"y": 204.9869144926704,
			"width": 790,
			"height": 305,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 980159518,
			"version": 45,
			"versionNonce": 1870218754,
			"isDeleted": true,
			"boundElements": [],
			"updated": 1671176215518,
			"link": null,
			"locked": false
		},
		{
			"id": "cAwM7ZJu",
			"type": "text",
			"x": 564.4777800324689,
			"y": 344.9869144926704,
			"width": 12,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1269424542,
			"version": 8,
			"versionNonce": 404381250,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176213642,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 18,
			"containerId": "t1q-7ip-C-IqCy8jaPp9d",
			"originalText": ""
		},
		{
			"id": "3JJsX3Pb",
			"type": "text",
			"x": 585.4777800324689,
			"y": 325.9869144926704,
			"width": 12,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1763121282,
			"version": 3,
			"versionNonce": 1835317314,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176223818,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": ""
		},
		{
			"id": "bvnsnFQA",
			"type": "text",
			"x": 511.02465503246896,
			"y": 286.2212894926704,
			"width": 20,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 583997726,
			"version": 6,
			"versionNonce": 2051901250,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176230329,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": ""
		},
		{
			"id": "rlR0fcA3",
			"type": "text",
			"x": 1046.024655032469,
			"y": 484.2212894926704,
			"width": 20,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 15753602,
			"version": 3,
			"versionNonce": 757915970,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176234658,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": ""
		},
		{
			"id": "I3H2DvOK",
			"type": "text",
			"x": 1151.024655032469,
			"y": 414.2212894926704,
			"width": 20,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 298131486,
			"version": 3,
			"versionNonce": 581397598,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176235703,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": ""
		},
		{
			"id": "V8bdL8ZZ",
			"type": "text",
			"x": 1231.024655032469,
			"y": 494.2212894926704,
			"width": 20,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 876163138,
			"version": 3,
			"versionNonce": 65918978,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176236511,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": ""
		},
		{
			"id": "vnTUAn5d",
			"type": "text",
			"x": 1251.024655032469,
			"y": 529.2212894926704,
			"width": 20,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 951536990,
			"version": 3,
			"versionNonce": 492958110,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176237856,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": ""
		},
		{
			"id": "ccZtUxtd",
			"type": "text",
			"x": 1161.024655032469,
			"y": 564.2212894926704,
			"width": 20,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1852360450,
			"version": 3,
			"versionNonce": 1769772738,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176238634,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": ""
		},
		{
			"id": "MI3WaePW",
			"type": "text",
			"x": 1121.024655032469,
			"y": 529.2212894926704,
			"width": 20,
			"height": 45,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 677720734,
			"version": 3,
			"versionNonce": 1084305118,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1671176239352,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": ""
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 36,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 362.3086783008639,
		"scrollY": 751.9141271739963,
		"zoom": {
			"value": 0.3
		},
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%