"Si hay una atmósfera muy viscosa, una fracción de la energía potencial se va a transformar o disipa como calor, fuerza de roce"

"La atmósfera viscosa es producto de cortar el agua que sube el % de sólidos en la pulpa"

[[Zona de limpieza]]