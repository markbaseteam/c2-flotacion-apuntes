Es la razón entre el caudal de aire Qg y el área de la sección transversal de la celda Ac en cm/s

[[Clase flotación 25 Nov - Flotación Columnar]]
