- ¿Porqué al bajar el flujo volumétrico siendo que fue por un alza de porcentaje de sólidos (cortamos agua con un tonelaje constante y densidad de mineral constante, esto hace viscosa la pulpa), el hold up de la pulpa (en la zona de colección) aumenta??? [[Respuesta duda de Hold up]]
- Qué tiene que ver la pérdida de carga con cerrar la válvula de colas???
- Confirmar esta pregunta 
- ##### Pregunta de certamen, ¿Cómo es la recuperación Rf en la zona de limpieza a medida que el colchón de espuma disminuye?
"La ley de concentrado bajaría"
"Si la ley de concentrado baja, entonces la recuperación en la zona de limpieza aumenta"
"Esto, dado que se recupera material que no es valioso, dado que disminuye la resistencia en zona de limpieza."
##### Pregunta sobre el aumento de la ley y recuperación en conjunto
"Partículas liberadas son hidrofóbicas y aumentan la ley" OK
"Partículas liberadas que no flotan, puede darse el caso de que aumente la recuperación y aumente la ley." 
##### En el drenaje ácido, el colector Xantato precipita?? porqué se puede flotar el agua de drenaje ácido?
- De qué manera se recupera el agua, y de qué manera se recupera el cobre? seguramente el cobre se adhiere al colector (en flotación) y al mismo tiempo no se puede precipitar? [[Drenaje ácido de mina]]
##### Qué se demora más al momento de aumentar el hold up de gas en la zona de colección?











