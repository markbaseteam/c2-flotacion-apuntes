### ¿Porqué no varía la frecuencia del motor?
Porque no hay motor que resista cambios bruscos de RPM.

[[Celdas mecánicas]]

[[Variables importantes de celdas mecánicas]]
