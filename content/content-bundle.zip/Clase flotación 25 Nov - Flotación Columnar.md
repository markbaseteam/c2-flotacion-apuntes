---
repeat: spaced every 36 hours
due_at: 2022-12-17T04:44:23.245-03:00
---
### Flotación Columnar 
- Son tipos de celda neumáticas [[Celdas neumáticas]]
- Miden desde 9 a 15 metros de altura y con poco diámetro, 0.5-3.0 metros.
- Las partículas se mueven contracorriente a las burbujas

### ¿Porqué la alimentación está acá abajo? 
![[Pasted image 20221125132007.png]]
Los espesadores contracorriente, agua más lavada tiene menor carga iónica, se logra maximizar el lavado. Si se mete en corriente, entonces, el proceso no optimiza el lavado. [[SX]]
### ¿Las partículas hidrofóbicas están arriba o abajo?
Con las de arriba que son las hidrofóbicas de la columna. Las que no se adhieren y siguen las menos hidrofóbicas, y se van a encontrar con burbujas fresquitas. 
1. Abajo están las burbujas fresquitas, se encuentran con las menos liberadas, menos hidrofóbicas y requieren burbujas fresquitas.
2.  Para una misma ley se pueden lograr buenas leyes de concentrado con recuperaciones aceptables.
Las celdas son en paralelo, entonces el flujo se divide en cada una de las columnas, en todas las etapas de flotación columnar.  

![[Pasted image 20221125133718.png]]
La etapa scavenger se observa que está al ladito de las celdas columnares, procesa colas de cleaner, se observan que son celdas mecánicas que poseen un motor en la parte de arriba que acciona el rotor de abajo. 
- Colchones de espuma de 1 m a 1.5 metros. (colchones profundos que aumetan la recuperación).
[[Sistema de inyección de aire columnas]]

Agua de lavado:
- Lo que hace el agua de lavado, es que agrega agua a la pulpa y evita que las partículas hidrofílicas que a menudo suben por arrastre y son finos o ultrafinos, se terminen arrastrando por la corriente de concentrado. 
- "Esto del agua de lavado va en conjunto con la altura de la espuma."

[[Dilución de la pulpa]]

[[Nivel de celda columnar]]

[[Hold up]]

[[Velocidad superficial de gas Jg]]

[[BIAS Jbias]]

[[Cosas por hacer 24_11]]

[[Clase Flotación 06 Dic]]

