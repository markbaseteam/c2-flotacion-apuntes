- Desarrollo del informe, que debe de tener
- a) Tabla con masa de concentrado acumulada, masa de cu acumulada, ley de cobre acumulada y la %R acumulada para cada tiempo medio.
- b) [[Gráficos %R acumulada y ley de concentrado vs tiempo medio]]
- c) Tabla de tiempo medio y modelo cinético de García - Zúñiga OK, en el excel
- d) Gráfico de modelo cinético de García - Zúñiga v/s tiempo medio. OK, en el excel
- e) Estimación de constante cinética. OK, en el excel.


[[Introducción y objetivos del Lab 4 de Flota]]

[[Procedimiento]]

[[Recuperación acumulada]]

[[Desarrollo de C2 de Flotación 2017]]
