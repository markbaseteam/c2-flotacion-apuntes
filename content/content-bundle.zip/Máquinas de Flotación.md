"En la celda uno ve un casquete arriba dando vuelta"
Hay un agitador y un estator que está arriba,
absorbe la mayor parte de la energía que está en esa zona.
impulsor "agitador"
estabilizador "estator"
[[Objetivos máquina flotación y diseño]]

Celdas de flotación mecánicas : Son las más confiables y conocidas, son generadas por el rompimiento mecánico de la corriente de aire usando impulsores o agitadores. [[Celdas mecánicas]]

Celdas de flotación neumáticas: Las burbujas son generadas por succión cuando se contacta fluidos a alta velocidad, por aereación mecánica de pulpa o inyectando aire a través de un medio poroso.
[[Celdas neumáticas]]

[[Comparación celdas mecánicas vs neumáticas]]

#### ¿Porqué se inyecta aire a través de un medio poroso?
