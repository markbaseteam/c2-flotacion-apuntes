_Las burbujas son generadas por succión cuando se contacta fluidos a alta velocidad  o por medio de la inyección de aire a travpes de un medio poroso._ ¿Qué es un medio poroso?
- Son más nuevas, con menos confianza en ellas.
"Las burbujas no son generadas por la acción del rotor"
Hay 3 mecanismos para generar burbujas:
Tipo A:
- Se succiona el aire dado el gradiente de presión presión externa mayor a la interna.
- Producto del choque se generan burbujas pequeñitas
- No hay ningún agitador o rotor
- Burbujas aún más pequeñas que las mecánicas. Flotan mejor los finos. 
- ### ¿Dónde tenemos granulometria más fina?
==En la etapa Cleaner o Scavenger==
Tipo B:
- Se inyecta el aire 
Tipo C:
[[Celdas columnares]]

[[Máquinas de Flotación]]

[[Comparación celdas mecánicas vs neumáticas]]