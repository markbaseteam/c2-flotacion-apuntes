- Agregamos NaSh y alcanza valores de -400 -600 con Ag/AgCl y el dixantógeno se reduce. Bajamos el potencial y se reduce el compuesto xantato metálico a dixantógeno (CuS+2X-+H+).
- ![[Pasted image 20221206111259.png]]
- El NaSH toma relevancia en la flotación selectiva [[Clase de Flotación 02 Dic]]

- Mecanismos a través del que actúa el NaSH en la flotación selectiva
- Caract de molibdenita como mineral sulfurado.