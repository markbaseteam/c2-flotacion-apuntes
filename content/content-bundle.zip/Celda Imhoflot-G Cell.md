- Lo más pesado son las colas, por ende por las paredes van las tailings, y por el centro van los concentrados.
- Coinciden mucho con los hidrociclones, la alta capacidad de estos es por la fuerza centrífuga.
- Requieren un tiempo de residencia muy bajo, de 30 s a 1 minuto. 

[[Modelo Imhoflot-V Cell TIpo A]]

[[Celdas neumáticas]]
