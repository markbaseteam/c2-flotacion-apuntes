![[Pasted image 20221206114420.png]]

![[Pasted image 20221206114542.png]]