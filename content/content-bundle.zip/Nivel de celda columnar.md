Se refiere al límite físico entre la zona de colección y la zona de limpieza Hc

[[Clase flotación 25 Nov - Flotación Columnar]]