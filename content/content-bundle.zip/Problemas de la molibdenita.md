- Flotabilidad disminuye mucho cuando disminuye el tamaño de partícula, por el tema fluidodinámico. Este efecto es mucho mayor en la molibdenita.
![[Pasted image 20221206111949.png]]
- Al partir partículas se generan nuevos bordes y la razón entre el área disponible de cara por área de borde disminuye. 
- Partículas más hidrofílicas.
- Ultrafinos. partículas bajo 20 micrones.
[[El calcio depresa la molibdenita.]]