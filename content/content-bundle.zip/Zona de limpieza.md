### ¿Si el espesor de la espuma es muy grueso, qué pasa?
Se acuerdan de la resistencia como en electrotecnia; hay dos resistencias, una es la resistencia de que quiero que este agregado suba y salga como concentrado, la resistencia es muy alta al momento de tener mayor espesor, si sale baja ley de concentrado, aumentan el espesor de la zona de limpieza, para que sea la zona más profunda. -

"El control de las zonas es crítico y netamente operacional"
### ¿Cómo modificamos el espesor de una zona de espuma?
"Si se agrega más espumante, podría variar un poquito, pero no es lo escencial"
"Flujo de aire se puede modificar, no es considerable"
### ¿Bernoulli, qué dice la ecuación de bernoulli?
[[Ecuación de bernoulli]]
"Tiene un componente H que se llama pérdida de carga"
"Si ustedes quieren patinar en hielo, se disipa poca energía por el roce" [[Pérdida de carga]]
### Si yo quiero que la interfaz suba, ¿qué debo de hacer con la válvula de las colas, cerrarla o abrirla?
Si la cierro aumenta la pérdida de carga en esta zona, qué pasa si aumenta la pérdida de carga, [[Dudas de flotación C2]]
"Si la cerramos toda, la altura va a desaparecer"
"Si la cerramos de a poquito, la altura va a subir, porque necesitamos una mayor energía potencial para que siga fluyendo"
"Si mueves o modificas la válvula de descarga entonces modificas la altura de la espuma"
### ¿Porqué sube?
Porque aumentaron la pérdida de carga en la descarga, necesitamos más energía potencial para que ese fluido salga.
"Cada una de las zonas tiene una Recuperación"

### Pregunta de certamen, ¿Cómo es la recuperación Rf en la zona de limpieza a medida que el colchón de espuma disminuye?
"La ley de concentrado bajaría"
"Si la ley de concentrado baja, entonces la recuperación en la zona de limpieza aumenta"
"Esto, dado que se recupera material que no es valioso, dado que disminuye la resistencia en zona de limpieza."
### ¿Puede ocurrir que aumenta la recuperación y aumente la ley?
No siempre que aumenta la recuperación la ley baja, existen casos en donde hay partículas liberadas que no están flotando, puede ocurrir a nivel industrial. 95% de los casos pasa lo contrario, cuando eso ocurre es porque faltan burbujas y están haciendo algo mal "Hay partículas que están liberadas y no están flotando".

"Partículas liberadas son hidrofóbicas y aumentan la ley" OK
"Partículas liberadas que no flotan, puede darse el caso de que aumente la recuperación y aumente la ley." 

[[Celdas columnares]]
