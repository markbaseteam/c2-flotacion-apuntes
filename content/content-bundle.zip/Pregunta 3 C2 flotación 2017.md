Se parece a [[Pregunta e-Listado3-de-Flotación]]
