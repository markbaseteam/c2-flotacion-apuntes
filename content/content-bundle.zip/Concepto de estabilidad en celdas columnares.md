- Dado que existe un flujo en contracorriente de pulpa y de burbujas, se da el caso de que aumenta la eficiencia en la generación de agregados partícula-burbuja ya que la posibilidad de unión entre estos es mayor y más estable.

[[Clase flotación 25 Nov - Flotación Columnar]]