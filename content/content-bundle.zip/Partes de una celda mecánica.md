1. Impulsor:
2. Estator: Evitar que el momentum que se imparte en el impulsor, que no se transfiera a la zona superior, necesito zona de quietud. ZONAS TRANQUILAS
3. Fondo falso: Porqué se llama así, es un fondo que permite la instalación del estator en la parte superior, hay una separación entre estanque y fondo falso, _evitar embancamientos_ y que pulpa pudiera circular. [[Transporte de pulpa]] [[Modelos de celda]] evitar embancamientos.
### ¿Qué pasa si choca con la pared?
Choca y cae y la celda se embanca, pierde el momentum, sin el fondo falso.
[[Celdas mecánicas]]
