La del Ferroso férrico.
[[Generación de burbujas en máquinas de flotación]]
