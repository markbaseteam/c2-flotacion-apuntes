---
repeat: spaced every 96 hours
due_at: 2022-12-19T17:04:10.965-03:00
---
1. Calcular el caudal de pulpa de mineral a procesar, se deriva de la siguiente forma:
![[Pasted image 20221202142529.png]]
- Primero se calcula el caudal de pulpa, el
- Nc es el número de celdas necesarias que requiere un tiempo tr con un volumen de celda Vc, si conocemos el tr y Vr con la fracción ocupada por la pulpa, se puede calcular el número de celdas requeridas.
2. ¿Cuántas celdas por línea? entre 6 y 7.
![[Pasted image 20221202142823.png]]
- Si la fracción de volumen de celda ocupada por el aire es de 0.2 entonces la fracción de pulpa es 0.8.
- Número de celdas Nc se aproxima al entero más cercano.

- Fijarse que se necesitarían más de 100 celdas si es que fueran de 50 m^3
![[Pasted image 20221202143202.png]]
A 300 m3 se necesitan aproximadamente 18 celdas considerando 6 celdas cada línea, son 3 líneas de flotación.

![[Pasted image 20221202143304.png]]
- Cuando hay un estanque más grande hay un rotor, la energía debe ser más grande suministrada por el rotor. Cuando se suministra mucha energía por el rotor a los minerales que son alterados, se comporta como un molino y genera mucho ultrafinos. Las arcillas se delaminan producto del cizalle y la pulpa queda viscosa, cuesta sedimentarlo y se acumulan en el sistema. 
- Por temas administrativos y económicos se diseñan celdas muy grandes, tipo de 1000 m^3 y ocurren esos problemas. 
[[Repasar el ejercicio del certamen 1 granulometría- Nacho]]

[[Ejercicio 4 ayudantía final de flota]]

[[Clase Flotación 06 Dic]]

