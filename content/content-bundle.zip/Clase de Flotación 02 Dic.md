Circuito de Minera Esperanza:

- La etapa Rougher tiene dos líneas de 7 celdas cada una. Entonces, hay dos celdas que comparten el mismo nivel, las dos líneas de flotación son la etapa Rougher.
- Usan agua de mar a un pH 8.2, cuesta subir el pH. La Pirita la depresan con el metabisulfito [[Clase Flotación 29 Nov-Depresión de la pirita]]
70-80 % - 325# [[Mallas de metalurgia]]

- ![[Pasted image 20221202140059.png]]
- Hidrociclones.
- Canaletas y colchones de espuma
![[Pasted image 20221202140151.png]]
- Minera Sierra gorda
![[Pasted image 20221202140415.png]]
- Hay una diferencia de nivel, son de aireación forzada Outotec. 
- Lunding Mining, en Copiapó, tienen buena ley, no tienen pirita, la flotación no es problema. 
- "Condoro" con lo del socavón. 
- Chuqui, minerales que levantan mucho polvo en suspensión, minerales arcillosos.
- [[Dimensionamiento de un circuito de Flotación]]
- [[Concepto de banco]]
- En el ejercicio de balance, se tiene que se sabe la recuperación en peso del Rougher, SI SE SABE LA RECUPERACIÓN en peso entonces de inmediato sabes que se conoce la cola y el concentrado. Luego, se conoce la ley de concentrado del Rougher.
- Luego tienes un balance de masa en el nodo que según el profe estaba facilísimo