- Genera alta turbulencia, aumenta la probabilidad de colisión, cantidad de choque con partículas aumenta, _probabilidad de cohesión y adhesión aumenta_, por ende, aumenta la recuperación y el tiempo de residencia, aumentando el volumen útil disponible? 
- El fondo falso es más chico
### ¿Qué pasa si se cierra la válvula de control en el transiente?
- Aumenta la zona de colección, disminuye la altura de la espuma. Esto impacta en la recuperación.
- Los motores SAG son los más grandes del mundo. 
- ==Tanto el METSO Outotec y el Wemco se utilizan en las estapas Rougher==

[[Pérdida de carga]]

[[Modelos de celda]]
