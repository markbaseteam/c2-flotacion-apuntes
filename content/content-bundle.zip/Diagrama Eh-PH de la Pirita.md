- Ag/AgCl con respecto al de Hidrógeno. 200 y algo.

![[Pasted image 20221129103906.png]]
- La clave es llevar el sistema a un pH muy alcalina, con cal. 
$$CaO+H^{+}=Ca^{2+}+H_{2}O $$
$$CaO+H^{+}=Ca(OH)_{2}$$
Dependiendo del pH
CaOH es más activo que tener Ca2+.
[[Teoría Flotación Sulfuros]]
[[Clase Flotación 29 Nov-Depresión de la pirita]]