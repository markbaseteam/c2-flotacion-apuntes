- e) Los resultados operacionales del último mes de operación muestran que la ley de cobre del concentrado final ha disminuido a un 26%. Por otro lado, la recuperación de molibdeno se mantuvo constante en la planta en valores cercanos al 60%. El contenido de pirita en el mineral de cabeza se mantuvo constante en ordenes del 2% durante el mes de operación. Al mismo tiempo la recuperación de cobre se ha visto disminuida en alrededor de 1 punto porcentual, con un aumento leve de la recuperación en peso. Las leyes del mineral de cabeza se han mantenido constantes, sin embargo, los consumos de colectores han aumentado y la [[conductividad del agua de proceso ha mostrado un leve aumento]]. Establecer y fundamentar posibles hipótesis respecto de la baja de las leyes del concentrado final.

Posibles hipótesis:
1. Si la recuperación de molibdeno no ha cambiado en el mes operacional, entonces se descarta la presencia de iones Ca o Mg
2. Se puede deber a la mineralogía (depende de que si ha cambiado la mineralogía)
3. Los colectores no son efectivos o se usan colectores en dosificación errónea.
4. Tiempo de molienda no óptimo, 
5. Presencia de arcillas en la flotación, debido a que generan recubrimientos en las partículas hidrofóbicas haciendo que flotación pierda eficiencia. 
6. El mineral va cambiando a medida que se va cabando, entonces, es imposible que la mineralogía se mantenga constante. 
7. La presencia de py puede estar afectando a la recuperación de la Cpy
8. Algún fallo en la celda Rougher

#### Si es la pirita, cuál es la etapa más importante o crítica en donde podría ocurrir esto?
Fran:
- Si hay un aumento en el consumo del colector se debe a problemas en la flotación selectiva
- En la etapa selectiva, la ganga que es pirita está hidrofobizándose
- Producto de esto, termina flotando y yendo por concentrado
- Esto hace que baje la ley de cobre en el mineral.
- Aumenta la recuperación
- Si no hay partículas hidrofóbicas con tiempo de residencia alto en la celda, eso tiene relación con la ley
- Part. con tiempo de residencia alto hacen que aumente ley y aumente recup.
- La relación ley y recuperación sigue manteniendo inversamente proporcional 
- La flotación de la pirita significa que aumentan las especies contaminantes
- Estas especies contaminantes son el azufre S elemental, el hierro Fe
- Se liberan de la pirita al interactuar con el agua.