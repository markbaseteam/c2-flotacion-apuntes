- Dispersión de gotas en una fase homogénea pero que no se mezclan, inmiscibles.
1. En el caso del diesel, se gana área superficial.