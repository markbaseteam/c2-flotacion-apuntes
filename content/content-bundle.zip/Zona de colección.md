Es una zona muy importante y define gran parte la recuperación, donde se da el contacto y colisión, adhesión, desadhesión ocurren aquí; la ocurrencia de estos fenómenos es un proceso cinético y probabilístico y sigue una cinética de primer orden [[Lab 4 de Flotación]] [[Clase flotación 17 Nov]]. En el lab 5 determinarán la constante cinética de flotación y depende de muchas variables, mineral, tamaño partícula, tamaño de burbuja, celda, etc.

"Se puede modelar con balance poblacional, por especie, por tamaño" Para la caracterización de las burbujas. -

#### ¿Cuáles partículas tienen menos tiempo para flotar, las más liberadas o las menos liberadas, las más hidrofóbicas o menos hidrofóbicas?
Las más hidrofóbicas flotan primero y se demoran menos tiempo, al salir un color más "doradito" y las más liberadas. Aumenta la recuperación y disminuye la ley al pasar el tiempo de residencia. 

### ¿Variables más importantes de la zona de colección?
Tiempo de residencia en la zona de colección: Se calcula como el volumen útil de la celda, que depende de el Área de sección transversal por la altura de la zona de colección. Aparte, el hold up de gas en la zona de colección.
### ¿Porqué se habla de volumen útil y no de volumen total?
Porque hay aire, no todo el volumen está disponible para la pulpa, en la fracción del hold up está ocupada por el aire en fracción volumétrica, volumen útil de la pulpa en la zona de colección, depende del caudal volumétrico de la cola de flotación. 
"Volumen útil; es el área de sección transversal de la celda por la altura", es el volumen geométrico, solo una fracción está ocupada por la pulpa. 

### ¿Qué pasa si el hold up aumenta? ¿Cómo podemos aumentar el flujo de aire en esta zona?
¿Agregamos más burbujas? ¿De qué depende que haya más aire? el tiempo de residencia que demora una burbuja en subir de zona de colección a la zona de limpieza. 
##### ¿Qué pasa si una burbuja es muy fina?
Se demora más y tenemos menos burbujas, debido al principio de arquímedes. [[Dudas de flotación C2]]
##### ¿Si la burbuja es muy chiquitita, cuánto es el volumen de líquido desalojado?
Es bajo y por ende la fuerza de empuje es baja, la fuerza de empuje es lo que hace que las burbujas suban, entonces se demoran.
"Aumento el hold up disminuyendo el tamaño de burbuja" 
"Si el hold up aumenta, el tiempo de residencia disminuye" OK.!!
"Si el tiempo de residencia disminuye, la recuperación es menor" OK!!
### ¿Cómo puedo disminuir el flujo volumétrico sin tener que disminuir las toneladas que entran?
Como es pulpa lo que va entrando, entonces, se debe bajar el agua, tiene las ventajas de que sube el tiempo de residencia, aumentando recuperación, me ahorro agua; pero si le echo menos agua, se hace muy viscosa la pulpa y el hold up aumenta (???) [[Dudas de flotación C2]] y se demoran mucho las burbujas en subir. O al revés "aumentar el porcentaje de sólidos".
### Los minerales muy arcillosos y viscosos hay que echarle más agua
