Las primeras pruebas de laboratorio se hicieron con una mena de hierro, en una columna de 50 mm de diámetro. Luego, en una columna de 0.3 de Diámetro y 8.8 m de alto en la planta Shefferwill en Canadá. 

_Los mayores cambios en la ley de metal en la celda sucedieron en la zona de limpieza y capa de espuma_ [[Zona de limpieza]]
