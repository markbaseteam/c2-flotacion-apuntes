 Las preguntas que no ha hecho el profe: descripción de las 3 etapas de flotación en detalle
- explicar alguna situación de porqué bajó la ley de concentrado en la planta
- hacer una pregunta de las aricllas
- hacer una pregunta del hold up o del flujo de aire
- preguntar las ventajas y desventajas de las celdas mecánicas vs las neumáticas que son las de flotación cleaner. 
- No ha preguntado sobre las mallas 
- detalles sobre fundamentos fisicoquímocs
- depresión de la pirita
- explicación de la cal
- propiedades superficiales de la molibdenita.

Cosas que sí preguntó:
- Drenaje ácido de mina
- Ajuste de balance metalúrgico
- Ejercicio de balance metalúrgico por mallas