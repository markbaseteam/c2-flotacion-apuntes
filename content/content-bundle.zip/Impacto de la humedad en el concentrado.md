- Vender con 13 % de humedad y el barco cobra por peso y por volumen. El barco tambalea, producto que concentrado comporta como fluido.
- Secar: 1 punto porcentual más para secar, ya que el Cp del agua es mayor. Se necesita 1 cal/g°C, Cp del aire es bajísimo. [[porqué cuesta con el agua]]
- El vapor de agua es un gas invernadero, perdiendo agua porque se evapora.
- Que vaya a fundición.

[[Sistema de adición de agua de lavado]]