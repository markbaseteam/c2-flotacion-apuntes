- Potasio ión más grande, que el Na, ok.
- ¿Qué ocurre cuando hay un ion K+ en el agua. 
- El agua rodea los iones debido a una diferencia de carga. 
- El K+ se solvata más debido a un área de superficial mayor
- Densidad de carga +/área de carga. PERO el Na+ queda más atrapado
porque le cuesta moverse con el agua que se solvata más que el potasio. Densidad de carga tiene
menor el k+ y por ende se mueve más ráido el Na+ porque es más chica la partícula. [[Densidad de carga superficial]]